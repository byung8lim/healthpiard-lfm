# Healthpiard 음식 피더

`flutter pub get` 후 `flutter run`으로 실행합니다. 설정에서 `lfm-server` URL과 `ADMIN_TOKEN` 값을 입력합니다. 카메라 촬영뿐 아니라 휴대폰 갤러리 이미지도 선택할 수 있으며, 음식명 검색 결과에서 클래스를 선택한 후 영양정보를 입력해 `/api/v1/feedFoodModel`로 업로드합니다.

인터넷 영양정보 자동 조회는 서버에 USDA FoodData Central 프록시를 추가할 때 API 키가 필요합니다. 현재는 DB에 없는 음식도 앱에서 검색 후 직접 영양정보를 입력하여 안전하게 등록할 수 있습니다.
