import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import 'package:path_provider/path_provider.dart';

void main() => runApp(const FeederApp());

class FeederApp extends StatelessWidget {
  const FeederApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'Healthpiard 음식 피더', theme: ThemeData(colorSchemeSeed: Colors.green, useMaterial3: true),
    home: const FeedPage(),
  );
}

class Api {
  String base = ''; String token = ''; String usdaKey = 'DEMO_KEY';
  Future<void> load() async { final p = await SharedPreferences.getInstance(); base=p.getString('url')??''; token=p.getString('token')??''; usdaKey=p.getString('usdaKey')??'DEMO_KEY'; }
  Map<String,String> get headers => {'Authorization':'Bearer $token'};
  Future<List<Map<String,dynamic>>> classes(String q) async {
    final r=await http.get(Uri.parse('${base.replaceAll(RegExp(r'/$'), '')}/api/v1/foodClasses?q=${Uri.encodeQueryComponent(q)}'),headers:headers);
    if(r.statusCode!=200) throw Exception('${r.statusCode}: ${r.body}');
    return (jsonDecode(r.body) as List).cast<Map<String,dynamic>>();
  }
  Future<Map<String,String>> nutrition(String name) async {
    final u=Uri.https('api.nal.usda.gov','/fdc/v1/foods/search',{'api_key':usdaKey,'query':name,'pageSize':'5'});
    final r=await http.get(u); if(r.statusCode!=200) throw Exception('USDA 조회 실패: ${r.statusCode}');
    final foods=(jsonDecode(r.body)['foods'] as List); if(foods.isEmpty) throw Exception('인터넷 영양정보를 찾지 못했습니다.');
    final f=foods.first as Map<String,dynamic>; final nutrients=(f['foodNutrients'] as List).cast<Map<String,dynamic>>();
    double? val(String id)=>((nutrients.firstWhere((x)=>x['nutrientId'].toString()==id,orElse:()=>{'value':null})['value']) as num?)?.toDouble();
    return {'servingG':'100','caloriesKcal':'${val('1008')??''}','carbohydratesG':'${val('1005')??''}','proteinG':'${val('1003')??''}','fatG':'${val('1004')??''}','sourceName':'USDA FoodData Central'};
  }
  Future<int> downloadImages(String name, int count) async {
    final q=Uri.https('commons.wikimedia.org','/w/api.php',{'action':'query','generator':'search','gsrsearch':'$name filetype:bitmap','gsrnamespace':'6','gsrlimit':'$count','prop':'imageinfo','iiprop':'url','iiurlwidth':'1200','format':'json'});
    final r=await http.get(q,headers:{'User-Agent':'HealthpiardFeeder/1.0'}); if(r.statusCode!=200) throw Exception('이미지 검색 실패: ${r.statusCode}');
    final pages=((jsonDecode(r.body)['query']?['pages']??{}) as Map).values.toList(); if(pages.isEmpty) throw Exception('이미지를 찾지 못했습니다.');
    final root=await getApplicationDocumentsDirectory(), dir=Directory('${root.path}/food_images/$name'); await dir.create(recursive:true); var saved=0;
    for(final p in pages){final info=(p as Map)['imageinfo']?[0]; final url=info?['thumburl']??info?['url']; if(url==null)continue; final b=await http.get(Uri.parse(url as String),headers:{'User-Agent':'HealthpiardFeeder/1.0'}); if(b.statusCode==200){await File('${dir.path}/image_${DateTime.now().microsecondsSinceEpoch}.jpg').writeAsBytes(b.bodyBytes);saved++;}}
    return saved;
  }
  Future<void> feed(File image, Map<String,dynamic> food, Map<String,String> nutrition) async {
    final req=http.MultipartRequest('POST',Uri.parse('${base.replaceAll(RegExp(r'/$'), '')}/api/v1/feedFoodModel'))..headers.addAll(headers);
    req.fields.addAll({'clientId':'flutter-feeder','clientRequestId':const Uuid().v4(),'foodName':food['food_name'].toString(),'classCode':food['class_code'].toString(),'servingG':nutrition['servingG']!,'sourceName':nutrition['sourceName']!});
    for(final k in ['caloriesKcal','carbohydratesG','proteinG','fatG']) if((nutrition[k]??'').isNotEmpty) req.fields[k]=nutrition[k]!;
    req.files.add(await http.MultipartFile.fromPath('image',image.path)); final r=await req.send();
    if(r.statusCode<200||r.statusCode>=300) throw Exception('${r.statusCode}: ${await r.stream.bytesToString()}');
  }
}

class FeedPage extends StatefulWidget { const FeedPage({super.key}); @override State<FeedPage> createState()=>_FeedPageState(); }
class _FeedPageState extends State<FeedPage> {
  final api=Api(), search=TextEditingController(); final picker=ImagePicker(); File? image; List<Map<String,dynamic>> foods=[]; Map<String,dynamic>? selected; bool busy=false; String message='';
  final n={for(final k in ['servingG','caloriesKcal','carbohydratesG','proteinG','fatG','sourceName']) k:TextEditingController()};
  final imageCount=TextEditingController(text:'5');
  @override void initState(){super.initState(); _init();}
  Future<void> _init() async {await api.load(); if(api.base.isNotEmpty) _find();}
  Future<void> _find() async {try{setState(()=>busy=true); foods=await api.classes(search.text); }catch(e){message=e.toString();}finally{setState(()=>busy=false);}}
  Future<void> _pick(ImageSource source) async {final x=await picker.pickImage(source:source,imageQuality:92);if(x!=null)setState(()=>image=File(x.path));}
  Future<void> _settings() async {final u=TextEditingController(text:api.base),t=TextEditingController(text:api.token),k=TextEditingController(text:api.usdaKey); await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('접속 설정'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:u,decoration:const InputDecoration(labelText:'lfm-server URL')),TextField(controller:t,decoration:const InputDecoration(labelText:'admin 토큰'),obscureText:true),TextField(controller:k,decoration:const InputDecoration(labelText:'USDA API 키 (없으면 DEMO_KEY)'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('취소')),FilledButton(onPressed:() async{final p=await SharedPreferences.getInstance();await p.setString('url',u.text.trim());await p.setString('token',t.text.trim());await p.setString('usdaKey',k.text.trim());api.base=u.text.trim();api.token=t.text.trim();api.usdaKey=k.text.trim();if(mounted)Navigator.pop(context);_find();},child:const Text('저장'))]));}
  Future<void> _lookup() async {try{setState(()=>busy=true);final x=await api.nutrition(selected!['food_name'].toString());for(final e in x.entries)n[e.key]?.text=e.value;setState(()=>message='USDA FoodData Central 영양정보를 불러왔습니다. 확인 후 피딩하세요.');}catch(e){setState(()=>message=e.toString());}finally{setState(()=>busy=false);}}
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('음식 사진 피더'),actions:[IconButton(onPressed:_settings,icon:const Icon(Icons.settings))]),body:ListView(padding:const EdgeInsets.all(16),children:[Row(children:[Expanded(child:TextField(controller:search,onSubmitted:(_)=>_find(),decoration:const InputDecoration(labelText:'음식명 검색',prefixIcon:Icon(Icons.search)))),IconButton(onPressed:_find,icon:const Icon(Icons.refresh))]),Row(children:[Expanded(child:TextField(controller:imageCount,decoration:const InputDecoration(labelText:'인터넷 이미지 수'),keyboardType:TextInputType.number)),IconButton(onPressed:busy?null:() async{try{setState(()=>busy=true);final got=await api.downloadImages(search.text,int.tryParse(imageCount.text)??5);setState(()=>message='$got개 이미지를 저장했습니다.');}catch(e){setState(()=>message=e.toString());}finally{setState(()=>busy=false);}},icon:const Icon(Icons.download))]),const SizedBox(height:8),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:()=>_pick(ImageSource.camera),icon:const Icon(Icons.camera_alt),label:const Text('촬영'))),const SizedBox(width:8),Expanded(child:OutlinedButton.icon(onPressed:()=>_pick(ImageSource.gallery),icon:const Icon(Icons.photo_library),label:const Text('휴대폰 사진')))]),if(image!=null)Padding(padding:const EdgeInsets.symmetric(vertical:12),child:Image.file(image!,height:180,fit:BoxFit.cover)),if(busy)const LinearProgressIndicator(),...foods.map((f)=>RadioListTile<Map<String,dynamic>>(value:f,groupValue:selected,onChanged:(v)=>setState(()=>selected=v),title:Text(f['food_name'].toString()),subtitle:Text('${f['class_code']}'))),if(selected!=null)OutlinedButton.icon(onPressed:busy?null:_lookup,icon:const Icon(Icons.public),label:const Text('인터넷에서 영양정보 조회')),if(selected!=null)...n.entries.map((e)=>TextField(controller:e.value,decoration:InputDecoration(labelText:e.key),keyboardType:TextInputType.number)),FilledButton.icon(onPressed:(image==null||selected==null||busy)?null:() async{try{setState(()=>busy=true);await api.feed(image!,selected!,{for(final e in n.entries)e.key:e.value.text});setState(()=>message='서버로 피딩했습니다.');}catch(e){setState(()=>message=e.toString());}finally{setState(()=>busy=false);}},icon:const Icon(Icons.cloud_upload),label:const Text('서버로 피딩')),if(message.isNotEmpty)Padding(padding:const EdgeInsets.only(top:12),child:Text(message))]));
}
