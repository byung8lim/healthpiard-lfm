"""Internal ingestion jobs only; import root read-only; no arbitrary commands or paths."""
import json,os,threading,time,uuid,subprocess,signal,sys,hashlib
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
from collections import Counter
ROOT=Path('/imports').resolve(); STATE=Path('/state'); STATE.mkdir(parents=True,exist_ok=True)
TOKEN=os.environ['IMPORTER_TOKEN']
URL=os.environ.get('LFM_BASE_URL','http://lfm-api:8080')
LOCK=threading.RLock(); running=None; process=None
EXT={'.jpg','.jpeg','.png','.webp'}
IGNORED_CLASS_DIRS={'.locks','sha256','.sha256','locks'}
def files_by_class():
    result={}
    if ROOT.is_dir():
        for p in sorted(ROOT.iterdir()):
            if p.is_dir() and not p.is_symlink() and p.name not in IGNORED_CLASS_DIRS:
                result[p.name]=sum(1 for f in p.rglob('*') if f.is_file() and not f.is_symlink() and f.suffix.lower() in EXT and f.resolve().is_relative_to(ROOT))
    return result
def load_job(id):
    p=STATE / (id+'.json')
    if not p.exists():return None
    return json.loads(p.read_text())
def save(j):
    p=STATE/(j['id']+'.json');tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(j,ensure_ascii=False));tmp.replace(p)
def completed_images():
    """Read successful immutable content identities from prior importer journals.

    Keep ALL successful SHA values per path, not just the last successful value.
    A path reused with changed contents remains eligible; an identical image is skipped.
    """
    done = {}
    for journal in STATE.glob('*.jsonl'):
        with journal.open(encoding='utf-8', errors='replace') as fp:
            for line in fp:
                try:
                    event = json.loads(line)
                    if event.get('ok') is True and event.get('sha256') and event.get('path'):
                        done.setdefault(event['path'], set()).add(event['sha256'])
                except (ValueError, TypeError, KeyError):
                    continue
    return done

def scan_eligibility(count):
    """Choose at most `count` NEW files per class; never hash the entire tree.

    Hash only files that are potential upload candidates.  In particular, after
    a class has reached its requested limit, do not read any later file bytes.
    """
    from feed_food_folders import file_list
    completed = completed_images()
    chosen, counts = [], Counter()
    summary = Counter()
    examples = {'eligible': [], 'alreadyUploaded': []}
    capped_classes = set()
    for food, rel, path in file_list(ROOT):
        if food in capped_classes:
            continue
        limit = count.get(food, 0) if isinstance(count, dict) else count
        if isinstance(limit, int) and counts[food] >= limit:
            capped_classes.add(food)
            continue
        key = rel.as_posix()
        summary['checkedCandidates'] += 1
        try:
            with path.open('rb') as stream:
                digest = hashlib.sha256()
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(block)
                sha = digest.hexdigest()
        except OSError:
            summary['unreadable'] += 1
            continue
        if sha in completed.get(key, set()):
            summary['alreadyUploaded'] += 1
            if len(examples['alreadyUploaded']) < 3:
                examples['alreadyUploaded'].append(key)
            continue
        chosen.append(key)
        counts[food] += 1
        if len(examples['eligible']) < 3:
            examples['eligible'].append(key)
        if isinstance(limit, int) and counts[food] >= limit:
            capped_classes.add(food)
    summary['selected'] = len(chosen)
    summary['foodClassesSelected'] = len(counts)
    summary['inspectionScope'] = 'limited-to-requested-new-images-per-class'
    return chosen, counts, dict(summary), examples

def eligible_files(count):
    chosen, counts, _, _ = scan_eligibility(count)
    return chosen, counts

def select(n,counts):return sum(min(v,n) if isinstance(n,int) else v for v in counts.values())
def details(j):
    done=Counter(); bad=0
    p=STATE/(j['id']+'.jsonl')
    if p.exists():
        for line in p.read_text(errors='replace').splitlines():
            try:
                r=json.loads(line);done['conflict' if r.get('conflict') else 'success' if r.get('ok') and not r.get('response',{}).get('idempotentReplay') else 'replay' if r.get('ok') else 'failed']+=1
            except ValueError:bad+=1
    completed=sum(done.values()); elapsed=max(0,time.time()-j['startedAt'])
    rate=completed/elapsed if elapsed>0 else 0
    remaining=max(0,j['total']-completed)
    eta=round(remaining/rate) if rate>0 and j['status']=='RUNNING' else None
    return {**j,'processed':completed,'succeeded':done['success'],'replayed':done['replay'],'failed':done['failed'],'conflicts':done['conflict'],'breakdown':dict(done),'elapsedSeconds':round(elapsed),
            'etaSeconds':eta,'throughputPerSecond':round(rate,2),'estimatedRemaining':remaining,
            'malformedJournalLines':bad,'missingSourceFiles':j.get('missingSourceFiles',0)}
def start(j):
    global running,process
    cmd=[sys.executable,'-u','/app/feed_food_folders.py','--root',str(ROOT),'--url',URL,'--count',str(j['count']),
         '--journal',str(STATE/(j['id']+'.jsonl')),'--client-id','hp-admin-import',
         '--manifest',str(STATE/(j['id']+'.manifest'))]
    log=None
    try:
        log=(STATE/(j['id']+'.log')).open('ab',buffering=0)
        with LOCK:
            process=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,close_fds=True)
            p=process
        code=p.wait()
        with LOCK:
            j['status']='CANCELLED' if j.get('cancelRequested') else ('SUCCEEDED' if code==0 else 'PARTIAL_FAILED' if code==1 else 'FAILED')
            j['exitCode']=code;j['finishedAt']=time.time();save(j)
    except Exception as ex:
        with LOCK:j['status']='FAILED';j['error']=str(ex);j['finishedAt']=time.time();save(j)
    finally:
        if log is not None:log.close()
        with LOCK:running=None;process=None
class Handler(BaseHTTPRequestHandler):
    def reply(self,code,obj):
        raw=json.dumps(obj,ensure_ascii=False).encode();self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    def auth(self):
        if self.headers.get('Authorization')!='Bearer '+TOKEN:
            self.reply(403,{'error':'Forbidden'});return False
        return True
    def do_GET(self):
        if not self.auth():return
        if self.path=='/scan':
            counts=files_by_class();return self.reply(200,{'root':'/imports','foodClasses':len(counts),'total':sum(counts.values()),'classes':counts,'scanMode':'metadata-only','message':'No image hashes read for preview; selection happens on POST /jobs'})
        if self.path=='/jobs':
            items=[]
            for p in STATE.glob('*.json'):
                try:items.append(details(json.loads(p.read_text())))
                except Exception:pass
            return self.reply(200,sorted(items,key=lambda j:j['startedAt'],reverse=True)[:30])
        parts=self.path.strip('/').split('/')
        if len(parts)==2 and parts[0]=='jobs' and len(parts[1])==32:
            j=load_job(parts[1]);return self.reply(200,details(j)) if j else self.reply(404,{'error':'Not found'})
        return self.reply(404,{'error':'Not found'})
    def do_POST(self):
        global running
        if not self.auth():return
        parts=self.path.strip('/').split('/')
        if self.path=='/jobs':
            try:
                raw_length=self.headers.get('Content-Length')
                if raw_length is None:
                    raise ValueError('Content-Length required (chunked request bodies unsupported)')
                length=int(raw_length)
                if length<2 or length>1000:raise ValueError('Invalid request size')
                obj=json.loads(self.rfile.read(length))
                if not isinstance(obj,dict):raise ValueError('JSON object required')
                n=obj.get('count')
                if n is None:raise ValueError('count is required')
                if isinstance(n,dict):
                    if not n or any(not isinstance(v,int) or not 1<=v<=100000 for v in n.values()):raise ValueError('Bad per-class count')
                elif n!='all':
                    if isinstance(n,bool):raise ValueError('Bad count')
                    n=int(n)
                    if not 1<=n<=100000:raise ValueError('Count must be 1..100000 or all')
                with LOCK:
                    if running:return self.reply(409,{'error':'An import job is already running','jobId':running})
                    selected,counts,diagnostics,examples=scan_eligibility(n)
                    if not selected:return self.reply(200,{'status':'NO_NEW_IMAGES','total':0,'classes':0,'message':'No new images within the requested per-class selection; check diagnostics and /imports mount.','diagnostics':diagnostics,'examples':examples})
                    j={'id':uuid.uuid4().hex,'count':n,'status':'RUNNING',
                      'startedAt':time.time(),'finishedAt':None,'classes':len(counts),'total':len(selected)}
                    manifest=STATE/(j['id']+'.manifest')
                    manifest.write_text(json.dumps(selected,ensure_ascii=False),encoding='utf-8')
                    try:save(j)
                    except Exception:
                        manifest.unlink(missing_ok=True)
                        raise
                    running=j['id']
                    threading.Thread(target=start,args=(j,),daemon=True).start()
                return self.reply(202,details(j))
            except (ValueError,KeyError,TypeError) as e:return self.reply(400,{'error':str(e)})
            except OSError as e:return self.reply(500,{'error':'Importer state or source filesystem unavailable','detail':str(e)})
        if len(parts)==3 and parts[0]=='jobs' and parts[2]=='cancel':
            with LOCK:
                j=load_job(parts[1]);
                if not j:return self.reply(404,{'error':'Not found'})
                if running!=j['id'] or process is None:return self.reply(409,{'error':'Job not active'})
                j['cancelRequested']=True;save(j);process.terminate()
            return self.reply(202,{'status':'CANCELLING','id':j['id']})
        return self.reply(404,{'error':'Not found'})
if __name__=='__main__':
    # Prior process may have been restarted; orphaned jobs cannot be resumed as same process.
    for p in STATE.glob('*.json'):
        try:
            j=json.loads(p.read_text())
            if j['status']=='RUNNING':j['status']='INTERRUPTED';j['finishedAt']=time.time();save(j)
        except Exception:pass
    if not os.access(STATE,os.W_OK):raise SystemExit('FATAL /state is not writable')
    ThreadingHTTPServer(('0.0.0.0',8092),Handler).serve_forever()
