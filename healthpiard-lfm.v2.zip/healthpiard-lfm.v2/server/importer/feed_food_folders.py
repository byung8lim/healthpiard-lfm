#!/usr/bin/env python3
"""Independent Healthpiard-LFM V009.2 folder image feeder (stdlib only)."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import mimetypes
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from datetime import datetime, timezone

EXT = {'.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp'}
IGNORED_CLASS_DIRS = {'.locks','sha256','.sha256','locks'}
NUTRIENTS = ('servingG','caloriesKcal','carbohydratesG','proteinG','fatG','sourceName')

def nutrition_rows(csv_path):
    if not csv_path:
        return {}
    with open(csv_path, newline='', encoding='utf-8-sig') as f:
        r=csv.DictReader(f)
        cols=set(r.fieldnames or [])
        if not {'foodName','servingG'} <= cols:
            raise ValueError('Nutrition CSV requires foodName and servingG headers')
        out={}
        for row in r:
            name=(row.get('foodName') or '').strip()
            if not name or name in out:
                raise ValueError('Missing or duplicated foodName in nutrition CSV: '+name)
            out[name]={k:(row.get(k) or '').strip() for k in NUTRIENTS}
            if not out[name]['servingG']:
                raise ValueError('Missing servingG: '+name)
        return out

def file_list(root):
    if not root.is_dir():
        raise ValueError('Image root does not exist: '+str(root))
    for food_dir in sorted(root.iterdir()):
        if not food_dir.is_dir() or food_dir.is_symlink() or food_dir.name in IGNORED_CLASS_DIRS:
            continue
        for p in sorted(food_dir.rglob('*')):
            if p.is_symlink() or not p.is_file() or p.suffix.lower() not in EXT:
                continue
            rel=p.relative_to(root)
            yield rel.parts[0],rel,p

def payload_for(root, food, rel, p, client_id, nutrition, max_bytes):
    size=p.stat().st_size
    if not 0<size<=max_bytes:
        raise ValueError(f'File size {size} outside 1..{max_bytes} bytes')
    content=p.read_bytes()
    if len(content)!=size:
        raise ValueError('File changed during read')
    sha=hashlib.sha256(content).hexdigest()
    fields={'clientId':client_id, 'foodName':food, 'servingG':'100',
            'sourceName':'folder-feeder'}
    if food in nutrition:
        for k,v in nutrition[food].items():
            if v:
                fields[k]=v
        if not fields.get('sourceName'):
            fields['sourceName']='folder-feeder'
    # Deterministic ID for a given relative path, image bytes and metadata.
    fingerprint=json.dumps({'relativePath':rel.as_posix(),'sha256':sha,'fields':fields},
                           sort_keys=True,ensure_ascii=False,separators=(',',':'))
    fields['clientRequestId']='folder-'+hashlib.sha256(fingerprint.encode()).hexdigest()[:40]
    return fields,content,sha

def form_body(fields,filename,blob,mime):
    boundary='hp'+os.urandom(14).hex()
    segments=[]
    for k,v in fields.items():
        segments.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n').encode('utf-8'))
    safe_filename=filename.replace('"','_').replace('\r','_').replace('\n','_')
    segments.append((f'--{boundary}\r\nContent-Disposition: form-data; name="image"; filename="{safe_filename}"\r\nContent-Type: {mime}\r\n\r\n').encode())
    segments.extend((blob,b'\r\n',(f'--{boundary}--\r\n').encode()))
    return b''.join(segments),f'multipart/form-data; boundary={boundary}'

def upload(url,fields,p,blob,timeout):
    data,content_type=form_body(fields,p.name,blob,EXT[p.suffix.lower()])
    request=urllib.request.Request(url.rstrip('/')+'/api/v1/feedFoodModel',data=data,
           headers={
               'Content-Type':content_type,
               'Authorization':'Bearer '+os.environ['LFM_ADMIN_TOKEN'],
               'User-Agent':'healthpiard-folder-feeder/1.0',
           },method='POST')
    try:
        with urllib.request.urlopen(request,timeout=timeout) as response:
            body=response.read(16384)
            code=response.status
    except urllib.error.HTTPError as e:
        code=e.code
        body=e.read(16384)
    try: result=json.loads(body.decode('utf-8'))
    except (ValueError,UnicodeError): result={'raw':body.decode('utf-8','replace')[:500]}
    return code,result

def main(argv=None):
    parser=argparse.ArgumentParser(description='Feed files in ROOT/음식명/*.jpg/png/webp to LFM V009.2 without changing server')
    parser.add_argument('--count',default='30',help='Maximum images per food class, integer >=1 or all')
    parser.add_argument('--root',required=True,help='Directory containing per-food directories')
    parser.add_argument('--url',default='http://127.0.0.1:8080',help='LFM API base URL')
    parser.add_argument('--nutrition-csv',help='Optional foodName,servingG,caloriesKcal,carbohydratesG,proteinG,fatG,sourceName CSV')
    parser.add_argument('--client-id',default='food-folder-feeder',help='Stable client identifier')
    parser.add_argument('--journal',help='JSONL outcome log path (default ./feeding-results.jsonl)')
    parser.add_argument('--manifest',help='Explicit relative-path JSON array chosen by importer')
    parser.add_argument('--max-consecutive-failures',type=int,default=5)
    parser.add_argument('--dry-run',action='store_true',help='Preview only, never upload')
    parser.add_argument('--retry',type=int,default=2,help='Retries on 429/5xx and network errors')
    parser.add_argument('--timeout',type=int,default=60)
    parser.add_argument('--max-mb',type=int,default=15,help='Max file size, must fit server MAX_UPLOAD_BYTES')
    args=parser.parse_args(argv)
    root=Path(args.root).expanduser().resolve()
    nutrition=nutrition_rows(args.nutrition_csv)
    if len(args.client_id)>128 or not args.client_id.strip():
        parser.error('Invalid --client-id')
    journal=Path(args.journal or 'feeding-results.jsonl').expanduser()
    stats={'success':0,'replay':0,'failed':0,'preview':0,'skipped':0}
    missing_nutrition=set()
    if args.count.lower() != 'all':
        try: cap=int(args.count)
        except ValueError: parser.error('--count must be a positive integer or all')
        if cap < 1: parser.error('--count must be at least 1')
    else: cap=None
    files=[]
    from collections import defaultdict
    per_food=defaultdict(int)
    selected = None
    if args.manifest:
        selected = set(json.loads(Path(args.manifest).read_text(encoding='utf-8')))
    for food,rel,p in file_list(root):
        if selected is not None:
            if rel.as_posix() not in selected:continue
        elif cap is not None and per_food[food] >= cap:
            continue
        files.append((food,rel,p));per_food[food]+=1
    if selected is not None and len(files)!=len(selected):
        missing=selected-{rel.as_posix() for _,rel,_ in files}
        print(f'WARN | manifest missing={len(missing)} (source may have changed during scan); continuing valid files', flush=True)
        for missing_path in sorted(missing):
            print(f'FAIL | MISSING_SOURCE | {missing_path}', flush=True)
        stats['missing']=len(missing)
    print('SELECTED | food_classes=',len(per_food),' | limit_per_class=',args.count,flush=True)
    print(f'SCAN | root={root} | files={len(files)} | url={args.url} | dry_run={args.dry_run}',flush=True)
    if not args.dry_run:
        journal.parent.mkdir(parents=True,exist_ok=True)
    consecutive_failures=0
    stats['conflict']=0
    aborted=False
    for food,rel,p in files:
        if food not in nutrition:
            missing_nutrition.add(food)
        try:
            fields,data,sha=payload_for(root,food,rel,p,args.client_id,nutrition,args.max_mb*1024*1024)
            if args.dry_run:
                print(f'PREVIEW | {rel} | foodName={food} | bytes={len(data)} | req={fields["clientRequestId"]}',flush=True)
                stats['preview']+=1
                continue
            for attempt in range(args.retry+1):
                try:
                    code,result=upload(args.url,fields,p,data,args.timeout)
                except (urllib.error.URLError,TimeoutError,OSError) as e:
                    code=0;result={'error':str(e)}
                if (code==0 or code==429 or 500<=code<=599) and attempt<args.retry:
                    time.sleep(min(2**attempt,8));continue
                break
            success=code in (200,201) and isinstance(result,dict) and isinstance(result.get('imageId'),int)
            replay=success and result.get('idempotentReplay') is True
            conflict=(code==409 and isinstance(result,dict) and 'already assigned to another class' in str(result.get('detail','')).lower())
            category='conflict' if conflict else 'replay' if replay else 'success' if success else 'failed'
            stats[category]+=1
            print(f'{"PASS" if success else "CONFLICT" if conflict else "FAIL"} | HTTP {code} | {rel} | imageId={result.get("imageId")} | replay={bool(replay)} | {result.get("detail","")}',flush=True)
            record={'timestamp':datetime.now(timezone.utc).isoformat(),'path':rel.as_posix(),'foodName':food,'sha256':sha,
                    'requestId':fields['clientRequestId'],'httpStatus':code,'ok':success,'conflict':conflict,'response':result}
        except Exception as e:
            stats['failed']+=1
            print(f'FAIL | {rel} | {e}',flush=True)
            record={'timestamp':datetime.now(timezone.utc).isoformat(),'path':rel.as_posix(),'foodName':food,'ok':False,'error':str(e)}
        if not args.dry_run:
            with journal.open('a',encoding='utf-8') as f:
                f.write(json.dumps(record,ensure_ascii=False)+'\n')
                f.flush()
        # Only repeated transient/infrastructure failures abort the batch.
        # Bad images, validation errors and 409 class conflicts must not stop other foods.
        code=record.get('httpStatus')
        transient=(code is None and not record.get('ok')) or code in (0,429) or (isinstance(code,int) and code>=500)
        consecutive_failures = consecutive_failures+1 if transient else 0
        if consecutive_failures >= args.max_consecutive_failures and not args.dry_run:
            print('ABORT | repeated infrastructure/network failures',flush=True)
            aborted=True
            break
    if missing_nutrition:
        print('NOTE | nutrition not provided for: '+', '.join(sorted(missing_nutrition))+'; servingG defaults to 100, other nutrition fields remain empty.',flush=True)
    print('SUMMARY | '+' | '.join(f'{k}={v}' for k,v in stats.items()),flush=True)
    if not args.dry_run:
        print('JOURNAL | '+str(journal),flush=True)
        print('NOTE | uploaded images remain PENDING quality until approved; this tool does not trigger training.',flush=True)
    # Exit 2 signals premature termination, 1 signals partial failures or unresolved class conflicts.
    return 2 if aborted or stats.get('missing',0) else 1 if stats['failed'] or stats['conflict'] else 0

if __name__=='__main__':
    sys.exit(main())
