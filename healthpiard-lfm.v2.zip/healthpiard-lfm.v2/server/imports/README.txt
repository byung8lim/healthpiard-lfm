Place food-name folders containing jpg/png/webp images here. Each class loads up to count new images per job.
