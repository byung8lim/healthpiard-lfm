Healthpiard v015 Admin bulk UI patch

Apply in the v015 project root:
  unzip -o healthpiard-v015-admin-bulk-ui-patch.zip
  docker compose --env-file config.env -f compose.yml build admin
  docker compose --env-file config.env -f compose.yml up -d --no-deps admin

Changed: image page sizes 10/20/30/50/100, header select-all, bulk PASS/REJECT; class page sizes 10/20/30/50/100, multi-page class selection, single transactional multi-class PASS endpoint.

Note: npm build and Maven compile NOT verified here (dependencies unavailable offline). Existing database and config.env untouched.
