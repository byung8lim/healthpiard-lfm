import unittest, tempfile, json, sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'importer'))
import os
os.environ.setdefault("IMPORTER_TOKEN", "test-token")
import importer_service as svc
class V018Regression(unittest.TestCase):
 def test_conflict_not_completed(self):
  with tempfile.TemporaryDirectory() as d:
   state=Path(d)
   (state/'one.jsonl').write_text('\n'.join(json.dumps(x) for x in [
    {'path':'a.jpg','sha256':'abc','ok':False,'conflict':True},
    {'path':'b.jpg','sha256':'def','ok':True,'conflict':False}]))
   with patch.object(svc,'STATE',state): result=svc.completed_images()
   self.assertNotIn('a.jpg',result)
   self.assertEqual(result['b.jpg'],{'def'})
 def test_conflict_is_partial_failure(self):
  code=(ROOT/'importer/feed_food_folders.py').read_text()
  self.assertIn("stats['failed'] or stats['conflict']",code)
 def test_streaming_sha(self):
  code=(ROOT/'importer/importer_service.py').read_text()
  self.assertNotIn('path.read_bytes()',code)
  self.assertIn('stream.read(1024 * 1024)',code)
 def test_shutdown(self):
  code=(ROOT/'lfm-server/app/worker.py').read_text()
  self.assertIn('signal.SIGTERM',code)
  self.assertIn('if STOP_REQUESTED:',code)
 def test_no_old_deployment(self):
  self.assertFalse((ROOT/'healthpiard-compose-v013-config').exists())
if __name__=='__main__':unittest.main()
