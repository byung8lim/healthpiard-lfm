# Healthpiard Compose v014 — defect matrix and acceptance

Source: user-provided v013 ZIP, 2026-10-20. This is a patched candidate. The authoring environment has no Docker daemon, MySQL or Maven runtime; production end-to-end verification is **not** claimed.

## Precisely defined import semantics
- `count=30`: at most **30 not-yet-successfully-imported images per food class, across all food folders** (e.g. 110 classes -> up to 3,300 files). Classes with fewer remaining files contribute fewer.
- Deterministic sort of food folder and relative path. Success history in persistent `HP_IMPORT_STATE/*.jsonl` marks completed **relative path + SHA-256**. Next run advances to next files; failures are retried; changed files are eligible again. `all` means all remaining, not all including already-successful.
- The MySQL `image_object` table still performs SHA-256 deduplication; this selection journal controls pagination only. Preserve it across redeployments. Multi-process simultaneous import remains unsupported; one Importer service is required.

## Historical production observations and v014 response
| Ref | Observed defect / weakness | v014 response | Verification |
|---|---|---|---|
| BUG-001 | Unescaped DB password broke SQLAlchemy URL | `MYSQL_PASSWORD_URL` separate from raw `MYSQL_PASSWORD` | config inspection; DB test pending |
| BUG-002 | MySQL root 1045 health check waiting | Existing `MYSQL_PWD` health check requires matching initialized password; documented; no DB deletion | live validation pending |
| BUG-003 | MySQL DNS name unavailable and endpoint inconsistency | Compose uses one named private network for all services | live Docker networking pending |
| BUG-004 | Running compose without env file failed | `healthpiard.sh` includes `--env-file config.env`; direct command still needs it | static inspection |
| BUG-005 | `/state` PermissionError | `HP_UID`/`HP_GID` shared, prepare owns bind path, preflight writable check | integration pending |
| BUG-006 | `/data/objects` PermissionError | `HP_UID`/`HP_GID` set API+worker, prepare owns top-level paths | integration pending |
| BUG-007 | Admin POST `/imports/jobs` 400 | JSON bytes and explicit `Content-Length` in `ImportClient` | Java compilation/live test pending |
| BUG-008 | Importer `running` set before journal could be saved -> ghost 409 | persist job before setting `running`; filesystem error returns 500 | static review; integration pending |
| BUG-009 | Failed imports counted as `unknown` | derive `success`, `replay`, `failed` from `ok` and response; UI shows all | Python tests & static review |
| BUG-010 | Continuous HTTP 500 requests | stop after five consecutive failures; explicit unsuccessful exit | integration pending |
| DEF-011 | Ambiguous 30 limit | per-class labels/documentation/manifest | Python test |
| DEF-012 | Re-import same first 30 | journal-based next-batch selection | Python test |
| DEF-013 | All class coverage | `file_list()` traversal over all folders; per-class limits | Python test |
| DEF-014 | Resume after stop | only successful images excluded; interrupted/failed retries in next job (not byte-level checkpoint) | Python test |
| DEF-015 | Dedup and repeated ingestion | SHA-256 comparison for completed entries + API SHA dedup | Python test; API pending |
| DEF-016 | Unclear import progress | new UI columns success/replay/failed; ETA based on processed attempts | static inspection |
| DEF-017 | UID/GID mismatch with host | configurable `HP_UID`/`HP_GID` default 1000 | configuration review; Docker test pending |
| DEF-018 | Missing fresh-install validation | `healthpiard.sh check`, directory preparation; startup permission preflight for importer | partial; full E2E pending |

## Remaining constraints
- `.env` does not load automatically; use `./healthpiard.sh` or `docker compose --env-file config.env ...`.
- MySQL's original password is stored in its data directory. Updating environment variables alone does not change existing MySQL user passwords. Never reset existing DB casually.
- Import result journals are not the canonical DB catalog. If the journal disappears, the same images may be sent again; API idempotency/dedup prevents duplicate object records but can waste processing.
- Import failure behavior and health checks require live verification before marking a production rollout complete.

## Run local-only checks
`python3 tests_v014.py` and `bash -n healthpiard.sh prepare-rocky-dirs.sh`.

## Live acceptance (on deployment host)
1. Check `docker compose --env-file config.env config --quiet` and data directory owner IDs; run `./healthpiard.sh prepare` as account allowed to chown.
2. Rebuild/bring up services; verify five containers and MySQL/LFM health.
3. Login to Admin; POST import 30; validate HTTP 202, success/failure counters, DB rows increasing, no permission exceptions.
4. Run another 30 after completion; confirm next 30 **per class** and no repeated successful `(path,hash)` in journal.
5. Deliberately test 500 error streak on disposable test instance; confirm importer stops and reports failed job.
6. Run snapshot/training/release E2E on a *test* dataset before deployment signoff.
