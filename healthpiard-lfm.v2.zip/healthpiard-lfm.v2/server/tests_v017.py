from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parent
class V017Regression(unittest.TestCase):
 def test_snapshot_minimum_and_preflight(self):
  s=(ROOT/'lfm-server/app/platform.py').read_text()
  self.assertIn('if len(imgs)<3',s)
  self.assertIn('SNAPSHOT_UNASSIGNED_IMAGES',s)
  self.assertNotIn('if len(imgs)<max(min_class',s)
  self.assertIn('nval=max(1,',s)
  self.assertIn('ntest=max(1,',s)
 def test_upstream_error_preservation(self):
  s=(ROOT/'admin-server/backend/src/main/java/com/healthpiard/admin/LfmErrorHandler.java').read_text()
  self.assertIn('body(ex.body())',s)
  self.assertIn('status(ex.status())',s)
 def test_no_host_8080_collision(self):
  s=(ROOT/'compose.yml').read_text()
  self.assertNotIn('"${LFM_PORT:-8080}:8080"',s)
  self.assertIn('expose:',s)
 def test_no_secret_file(self):
  self.assertFalse((ROOT/'config.env').exists())
if __name__=='__main__':unittest.main()
