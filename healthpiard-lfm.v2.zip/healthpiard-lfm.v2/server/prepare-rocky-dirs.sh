#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
CONF="${HP_CONFIG_FILE:-config.env}"
[[ -f "$CONF" ]] || { echo "Missing $CONF"; exit 1; }
set -a; source "./$CONF"; set +a
HP_UID="${HP_UID:-1000}"; HP_GID="${HP_GID:-1000}"
for v in HP_MYSQL_DATA HP_IMAGE_DATA HP_TRAIN_DATA HP_CACHE_DATA HP_RELEASE_DATA HP_LOG_DATA HP_IMPORT_SOURCE HP_IMPORT_STATE; do
 p="${!v}"; [[ "$p" == /* && "$p" != / && "$p" != /var/lib/mysql ]] || { echo "Unsafe $v=$p"; exit 1; }
 mkdir -p -- "$p"
done
# Image/model dirs owned by unprivileged 10001 container user. Never recurse into existing image tree.
for v in HP_IMAGE_DATA HP_TRAIN_DATA HP_CACHE_DATA HP_RELEASE_DATA HP_LOG_DATA; do chown "$HP_UID:$HP_GID" "${!v}"; done
chown "$HP_UID:$HP_GID" "$HP_IMPORT_STATE"
chmod 750 "$HP_IMPORT_STATE"
echo 'Rocky bind paths prepared; existing contents retained.'
