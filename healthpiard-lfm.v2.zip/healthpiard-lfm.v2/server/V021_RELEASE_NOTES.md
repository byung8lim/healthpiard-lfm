# Healthpiard V021 — training correction and audit

## Verified code findings
- Previous `build_model` initialized MobileNetV3Large with `weights=None`. Unless `IMAGENET_WEIGHTS_PATH` was supplied, fresh training started with random features.
- The previous default `fineTuneBackbone=False` froze those random features, so the classification head alone could not learn useful food features.
- Previous NPY cache had no online augmentation. It should remain immutable; augmentation is now done on TRAIN batches only.
- Fixed-rate Adam was replaced with staged AdamW and a cosine schedule.

## V021 changes
1. Initial jobs load official ImageNet MobileNetV3Large weights using Keras (`weights='imagenet'`). A failed download aborts rather than silently training random/frozen layers. `KERAS_HOME=/data/training/.keras` persists downloaded weights.
2. `warmupEpochs` defaults to 3 (or fewer for short jobs). Train only classifier head in warmup, then unfreeze the last 40 non-BN layers with learning rate at most `1e-5`.
3. Apply random flip/rotation/zoom/contrast only to TRAIN batches, never validation/test; preserve original deterministic tensor cache.
4. Train stages use AdamW with CosineDecay. Stage config can be specified via training job `config_json` (`warmupEpochs`, `unfreezeLastLayers`).
5. Preprocessing stays `[-1,1]` and `include_preprocessing=False` for train/holdout/mobile consistency.

## Constraints and warnings
- 90% is NOT guaranteed. Report's stated 65–75% / 90–94% predictions were not derived from this user's verified holdout set, and 1.84% is distinct from the report's 18% assumption.
- The first run needs network access to download weights or an appropriately populated persistent Keras cache. Offline deployments should provide pretrained cache before starting; `IMAGENET_WEIGHTS_PATH` compatibility is retained.
- Resume of already trained scratch checkpoints will not magically acquire pretrained weights. Start a NEW job against the existing immutable snapshot (DO NOT erase images or snapshot). Existing jobs and deployed models are not modified.
- CPU learning may take substantial time. Recommended first experiment: >=15 epochs, imageSize=160/192, batchSize 8, compare HOLDOUT Top1 and Top3 with prior baseline. Check duplicate leakage and label quality independently.
- Model release gates remain independent; `MIN_RELEASE_ACCURACY=0.0` allows experimental release but does not improve prediction.
- On a fine-tuning stage change Keras optimizer state is deliberately reset. Resume restarts the stage schedule; class index hashes protect mapping.

## Deploy
`docker compose --env-file config.env build lfm-worker && docker compose --env-file config.env up -d lfm-worker`

## Verification scope
Static Python compilation and code checks only; no live MySQL/image corpus/CPU training run was possible in this environment. Validate the real holdout before relying on claimed recognition performance.
