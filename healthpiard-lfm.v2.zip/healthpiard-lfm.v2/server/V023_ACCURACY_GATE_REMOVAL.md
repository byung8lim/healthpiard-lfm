# V023 — 정확도 제한 제거 패치

- 릴리스 후보 생성시 Holdout 정확도 기준(50%/90%) 차단 완전 제거
- 학습 결과의 holdoutAccuracy, kerasHoldoutAccuracy, top3Accuracy는 계속 기록
- TFLite 수치적 변환 검증과 Keras/TFLite top-1 일치율 검사는 유지(정확도 제한과 별개)
- 음식 클래스 최소 20개 요건 유지(정확도와 별개)
- SUCCEEDED 상태의 과거 Job도 후보 생성 API를 재호출하면 정확도 미달 때문에 거부되지 않음
- 기존 config.env에 MIN_RELEASE_ACCURACY가 있어도 무시됨
- 적용: docker compose --env-file config.env build lfm-api admin && docker compose --env-file config.env up -d lfm-api admin
- 실제 데이터·DB 연동 테스트는 별도 서버에서 확인 필요
