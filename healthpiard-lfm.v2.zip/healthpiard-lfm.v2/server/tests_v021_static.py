"""Source-level regression guards that do not require TensorFlow or database."""
import ast
from pathlib import Path
p=Path(__file__).parent/'lfm-server/app/trainer/core.py'
s=p.read_text(); ast.parse(s)
assert "weights='imagenet' if pretrained else None" in s
assert "augment_batches(tf,mmap_dataset" in s
assert "phase='warmup' if epoch<warmup else 'finetune'" in s
assert "AdamW" in s and "CosineDecay" in s
assert "tf.clip_by_value" in s
assert "include_preprocessing=False" in s
assert "cached_samples(cache_dir" in (Path(__file__).parent/'lfm-server/app/trainer/run.py').read_text()
print('V021 source-level regression guards: PASS')
