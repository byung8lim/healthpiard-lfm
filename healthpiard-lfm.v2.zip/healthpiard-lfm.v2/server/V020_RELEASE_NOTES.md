# V020 changes

- Release candidate: configurable MIN_RELEASE_ACCURACY=0.50 and MIN_RELEASE_CLASSES=20. Both must pass.
- Existing SUCCEEDED V019 jobs: candidate validation is reevaluated against new policy; no retraining required if valid TFLite artifact and class index still exist.
- Export quality threshold now uses environment configuration; Keras/TFLite divergence still blocks unsafe conversion.
- Full reset: `bash ops/reset_v020.sh --dry-run`; to execute `V020_CONFIRM_RESET=DELETE_ALL_HEALTHPIARD_DATA bash ops/reset_v020.sh --execute`, then type RESET-V020. **Back up data first.** This erases DB and image data, not original import source. Docker must be stopped and no external process may access directories.
- Deploy: copy old config.env, append MIN_RELEASE_ACCURACY=0.50 and MIN_RELEASE_CLASSES=20, then `docker compose --env-file config.env build && docker compose --env-file config.env up -d`.
- Note: no guarantee of 90% recognition; 50% is a deployment gate, not a model-quality improvement. Training model, data split, labeling and augmentation require separate evaluation.
- Not runtime tested against MySQL/Docker/TensorFlow in this environment. Python syntax validated only.
