# Healthpiard 관리자 웹 V010 (Spring Boot 3.5 + React 19)

기존 `/opt/healthpiard-lfm-v009.2`를 변경하지 않는 **독립 관리자 프로젝트**입니다. MySQL 8 `healthpiard`의 기존 테이블을 읽고, LFM의 기존 `/api/v1/admin/*` API를 통해 변경 명령을 전달합니다. 학습은 기존 Python CPU Worker가 실행합니다.

## 구현

- 대시보드: 등록된 음식 클래스·이미지·PASS/PENDING/REJECT·Snapshot·학습·릴리스 건수
- 음식 클래스: 음식명, 코드, 클래스별 이미지와 승인 현황
- 이미지 품질: 상태별 페이지 조회, 개별 PASS/REJECT
- Snapshot: 전체 PASS 이미지 80/10/10 분리 요청, 최근 목록·건수
- CPU 학습: Snapshot으로 Job 생성, 10초 상태 자동 갱신, 상세·취소·재시도
- 모델 릴리스: 검증된 Job 후보 생성, 승인/거부, stable 채널 revision 조건부 활성화
- 기존 LFM `ADMIN_TOKEN`은 **프론트엔드에 전달하지 않음**; 백엔드가 인증 헤더 중계
- 관리자 접속: Spring Security HTTP Basic (반드시 사설망 또는 TLS 역프록시에서 사용)

## 빌드 및 설치 (Rocky 9)

사전 조건: JDK 21, Maven, Node.js 20+, npm, 기존 V009.2 API/Worker/MySQL 운영, 관리자 사용자 `healthpiard`, `/etc/healthpiard/lfm.env`. MySQL 접속 계정에 기존 테이블 SELECT 권한 필요. Maven/npm 패키지 다운로드를 위한 네트워크 필요.

```bash
cd healthpiard-admin-v010
export WEB_ADMIN_PASSWORD='충분히_길고_임의적인_비밀번호'
sudo -E bash ops/install.sh
```

설치 후 웹 주소: `http://<서버 IP>:8090/` (로그인: 환경변수 `WEB_ADMIN_USER`, 기본 admin). 실제 외부 공개는 HTTPS 역프록시와 CSRF 대책 적용 전까지 금지합니다.

개발 실행:

```bash
cd backend && mvn spring-boot:run
cd frontend && npm install && npm run dev
```

## 미완료 / 주의

- 대량 승인(수만 장) 작업, 이미지 썸네일 인증 조회, nutrition 편집, 감사 기록, 운영자 RBAC, TLS/CSRF 보호는 **미구현**입니다.
- LFM V009.2에 없는 `Snapshot LIST`와 집계 API만 관리자 서버에서 기존 테이블을 읽습니다. 모든 변경 동작은 LFM API를 사용합니다.
- V009.2의 API 계약을 기준으로 구현했으며, **실제 Rocky/MySQL/Worker 연동 E2E는 아직 미검증**입니다. 컴파일/빌드가 통과해도 실서버 검증 필요.
- 공개 운영용 배포가 아니라 사설망 내부 운영자를 위한 통합 개발 패키지입니다. 별도 계정 관리, 세분화 권한, 감사 로그, CSRF 보호, HTTPS를 보강해야 합니다.
- `/etc/healthpiard/admin.env` 는 root 전용(0600)이며 서비스는 healthpiard 사용자로 실행합니다. 서비스가 EnvironmentFile을 읽으려면 systemd가 root 권한으로 읽을 수 있어야 합니다.
