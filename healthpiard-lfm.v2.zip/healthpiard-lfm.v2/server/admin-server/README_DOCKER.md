# Healthpiard Admin V010 - Rocky 9.8 Docker

Spring Boot 3.5 + React 19 in a **single Docker image**. Does **not** modify the existing LFM V009.2 API, Worker, or MySQL schema.

## Prerequisites
- Docker Engine on Rocky Linux 9.8
- LFM V009.2 API on host `127.0.0.1:8080`
- MySQL 8 on host `127.0.0.1:3306`, production DB `healthpiard`
- `/etc/healthpiard/lfm.env` containing `DATABASE_URL` and `ADMIN_TOKEN`
- Images can access package registries (first build)

## Quick run
```bash
cd /opt/healthpiard-admin-v010
sudo bash ops/docker-run.sh
```
The script prompts for an Admin web password (minimum 12 characters), securely creates `/etc/healthpiard/admin-docker.env` (mode 0600), builds the React frontend + Spring Boot JAR, and starts a container with host networking. Web UI: `http://<server-ip>:8090/`, username `admin` (or `WEB_ADMIN_USER`). No Node.js or Maven installation is required on Rocky; builds run inside Docker.

## Manual Docker commands
```bash
docker build -t healthpiard-admin:v010 .
docker run -d --name healthpiard-admin --restart unless-stopped \
  --network host --env-file /etc/healthpiard/admin-docker.env \
  --memory 1g --cpus 2 healthpiard-admin:v010

docker logs -f --tail 100 healthpiard-admin
docker ps --filter name=healthpiard-admin
```

**Note**: Since `--network host` uses the host network, `-p 8090:8090` is unnecessary. This is tailored for Docker Engine on Linux / Rocky 9.8. If the host already runs a service on 8090, change `ADMIN_PORT` in `/etc/healthpiard/admin-docker.env` and the access port accordingly.

**Security**: React does not receive the LFM admin token. `WEB_ADMIN_PASSWORD` is for Spring Security HTTP Basic; this app currently has CSRF protection disabled. Use only on an isolated private network or via an HTTPS TLS reverse proxy. Do NOT expose port 8090 openly to the Internet. Docker Engine root users can inspect environment variables; restrict root/Docker group access. For stricter secrets management, adapt to Docker secrets/Kubernetes secrets.

**Verification limits**: Dockerfile stages and shell syntax inspected; an actual Docker build/run against Rocky + LFM + MySQL has NOT been carried out here.
