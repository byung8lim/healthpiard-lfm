package com.healthpiard.admin;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.*;
import java.util.*;
@Service
public class TrainingProgressService {
 private final Path root=Path.of("/data/training");
 private final ObjectMapper mapper=new ObjectMapper();
 public Object read(long snapshotId,long jobId){
  if(snapshotId<1||jobId<1)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid IDs");
  Path p=root.resolve("snapshot-"+snapshotId).resolve("job-"+jobId).resolve("progress.json");
  if(!Files.isRegularFile(p,LinkOption.NOFOLLOW_LINKS))return Map.of("status","NOT_RECORDED","jobId",jobId,
     "message","No progress recorded yet; preparing or waiting for worker");
  try{return mapper.readValue(Files.readString(p),Map.class);}
  catch(Exception ex){throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"Progress file unavailable");}
 }
}
