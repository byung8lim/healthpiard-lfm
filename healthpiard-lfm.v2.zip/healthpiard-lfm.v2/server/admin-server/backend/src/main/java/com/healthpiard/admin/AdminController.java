package com.healthpiard.admin;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.*;
@RestController
@RequestMapping("/admin-api")
public class AdminController {
 private final DbReadService db; private final LfmClient lfm; private final BulkQualityService bulk; private final TrainingLogService logs; private final TrainingProgressService progress; private final ImportClient importer;
 AdminController(DbReadService db,LfmClient lfm,BulkQualityService bulk,TrainingLogService logs,TrainingProgressService progress,ImportClient importer){this.db=db;this.lfm=lfm;this.bulk=bulk;this.logs=logs;this.progress=progress;this.importer=importer;}
 @GetMapping("/overview") public Map<String,Object> overview(){return db.first("overview",Map.of());}
 @GetMapping("/quality-stats") public List<Map<String,Object>> qualityStats(){return db.list("quality_stats",Map.of());}
 @GetMapping("/class-stats") public List<Map<String,Object>> classStats(){return db.list("class_stats",Map.of());}
 @GetMapping("/snapshots") public List<Map<String,Object>> snapshots(){return db.list("snapshots",Map.of());}
 @GetMapping("/releases/channel") public Map<String,Object> channel(){return db.first("release_channel",Map.of());}
 @GetMapping("/images") public Object images(@RequestParam(defaultValue="PENDING") String status,@RequestParam(defaultValue="50") int limit,@RequestParam(defaultValue="0") int offset,@RequestParam(required=false) Long classId){
  if(!List.of("PENDING","PASS","REJECT").contains(status) || limit<1||limit>200||offset<0)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid filters");
  return lfm.get("/api/v1/admin/images?status="+status+"&limit="+limit+"&offset="+offset+(classId==null?"":"&class_id="+classId));
 }
 @GetMapping("/images/{id}/content") public ResponseEntity<byte[]> image(@PathVariable long id){return lfm.getBytes("/api/v1/admin/images/"+id+"/content");}
 @PatchMapping("/images/{id}/quality") public Object quality(@PathVariable long id,@RequestBody Map<String,Object> body){return lfm.patch("/api/v1/admin/images/"+id+"/quality",body);}
 @PostMapping("/images/bulk-quality") public Object bulkQuality(@RequestBody BulkRequest req){return bulk.selected(req.imageIds(),req.source(),req.target());}
 public record ClassBulkMultiRequest(List<BulkQualityService.ClassItem> items,String source,String target){}
 @PostMapping("/classes/bulk-quality") public Object multiClassQuality(@RequestBody ClassBulkMultiRequest req){return bulk.classes(req.items(),req.source(),req.target());}
 @PostMapping("/classes/bulk-delete-images") public Object deleteClassImages(@RequestBody Object body){return lfm.post("/api/v1/admin/classes/bulk-delete-images",body);}
 @PostMapping("/classes/{id}/bulk-quality") public Object classQuality(@PathVariable long id,@RequestBody ClassBulkRequest req){return bulk.foodClass(id,req.source(),req.target(),req.expectedCount());}
 public record BulkRequest(List<Long> imageIds,String source,String target){}
 public record ClassBulkRequest(String source,String target,long expectedCount){}
 @GetMapping("/classes") public Object classes(){return lfm.get("/api/v1/admin/classes");}
 @PostMapping("/snapshots") public Object createSnapshot(@RequestBody Map<String,Object> body){return lfm.post("/api/v1/admin/snapshots",body);}
 @GetMapping("/snapshots/{id}") public Object snapshot(@PathVariable long id){return lfm.get("/api/v1/admin/snapshots/"+id);}
 @GetMapping("/jobs") public Object jobs(){return lfm.get("/api/v1/admin/training-jobs");}
 @GetMapping("/jobs/{id}/progress") public Object jobProgress(@PathVariable long id,@RequestParam long snapshotId){return progress.read(snapshotId,id);}
 @GetMapping("/jobs/{id}/quality-diagnostics") public Object qualityDiagnostics(@PathVariable long id){return lfm.get("/api/v1/admin/training-jobs/"+id+"/quality-diagnostics");}
 @PostMapping("/jobs/{id}/filtered-snapshot") public Object filteredSnapshot(@PathVariable long id,@RequestBody Map<String,Object> body){return lfm.post("/api/v1/admin/training-jobs/"+id+"/filtered-snapshot",body);}
 @GetMapping("/imports/scan") public Object importScan(){return importer.get("/scan");}
 @GetMapping("/imports/jobs") public Object importJobs(){return importer.get("/jobs");}
 @GetMapping("/imports/jobs/{id}") public Object importJob(@PathVariable String id){if(!id.matches("[a-f0-9]{32}"))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid ID");return importer.get("/jobs/"+id);}
 @PostMapping("/imports/jobs") public Object importStart(@RequestBody Map<String,Object> req){return importer.post("/jobs",req);}
 @PostMapping("/imports/jobs/{id}/cancel") public Object importCancel(@PathVariable String id){if(!id.matches("[a-f0-9]{32}"))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid ID");return importer.post("/jobs/"+id+"/cancel",Map.of());}
 @GetMapping("/jobs/{id}/log") public Object jobLog(@PathVariable long id){return logs.log(id);}
 @GetMapping("/jobs/{id}") public Object job(@PathVariable long id){return lfm.get("/api/v1/admin/training-jobs/"+id);}
 @GetMapping("/jobs/{id}/classes") public Object jobClasses(@PathVariable long id){return lfm.get("/api/v1/admin/training-jobs/"+id+"/classes");}
 @PostMapping("/jobs/{id}/quality-report") public Object qualityReport(@PathVariable long id){return lfm.post("/api/v1/admin/training-jobs/"+id+"/quality-report",Map.of());}
 @GetMapping("/jobs/{id}/quality-report") public ResponseEntity<byte[]> qualityReportDownload(@PathVariable long id){return lfm.getBytes("/api/v1/admin/training-jobs/"+id+"/quality-report");}
 @PostMapping(value="/jobs/{id}/local-quality-report",consumes=MediaType.MULTIPART_FORM_DATA_VALUE) public ResponseEntity<byte[]> localQualityReport(@PathVariable long id,@RequestParam("files") List<org.springframework.web.multipart.MultipartFile> files,@RequestParam String class_ids,@RequestParam String relative_paths){return lfm.localQualityReport(id,files,class_ids,relative_paths);}
 @PostMapping("/jobs") public Object createJob(@RequestBody Map<String,Object> body){return lfm.post("/api/v1/admin/training-jobs",body);}
 @PostMapping("/jobs/{id}/cancel") public Object cancel(@PathVariable long id){return lfm.post("/api/v1/admin/training-jobs/"+id+"/cancel",Map.of());}
 @PostMapping("/jobs/{id}/retry") public Object retry(@PathVariable long id){return lfm.post("/api/v1/admin/training-jobs/"+id+"/retry",Map.of());}
 @GetMapping("/releases") public Object releases(){return lfm.get("/api/v1/admin/releases");}
 @PostMapping("/releases/candidates") public Object candidate(@RequestBody Map<String,Object> body){return lfm.post("/api/v1/admin/releases/candidates",body);}
 @PostMapping("/releases/{id}/review") public Object review(@PathVariable long id,@RequestBody Map<String,Object> body){return lfm.post("/api/v1/admin/releases/"+id+"/review",body);}
 @PostMapping("/releases/activate") public Object activate(@RequestBody Map<String,Object> body){return lfm.post("/api/v1/admin/releases/activate",body);}
}
