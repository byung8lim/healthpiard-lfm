package com.healthpiard.admin;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.server.ResponseStatusException;
import java.util.*;
@Service
public class LfmClient {
 private final RestClient client;
 private final String token;
 public LfmClient(@Value("${app.lfm-base}") String base,@Value("${app.lfm-token}") String token){
   if(token.isBlank())throw new IllegalStateException("LFM_ADMIN_TOKEN missing");
   this.token=token;this.client=RestClient.builder().baseUrl(base).build();
 }
 public Object get(String path){return call(HttpMethod.GET,path,null);}
 public ResponseEntity<byte[]> getBytes(String path){
  try{return client.get().uri(path).header(HttpHeaders.AUTHORIZATION,"Bearer "+token).retrieve().toEntity(byte[].class);}
  catch(RestClientResponseException ex){throw new UpstreamLfmException(ex.getStatusCode(),ex.getResponseBodyAsString());}
  catch(ResourceAccessException ex){throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"LFM API unreachable",ex);}
 }
 public ResponseEntity<byte[]> localQualityReport(long id,List<org.springframework.web.multipart.MultipartFile> files,String classIds,String paths){try{var form=new org.springframework.util.LinkedMultiValueMap<String,Object>();for(var f:files)form.add("files",new org.springframework.core.io.ByteArrayResource(f.getBytes()){public String getFilename(){return f.getOriginalFilename();}});form.add("class_ids",classIds);form.add("relative_paths",paths);return client.post().uri("/api/v1/admin/training-jobs/"+id+"/local-quality-report").header(HttpHeaders.AUTHORIZATION,"Bearer "+token).contentType(MediaType.MULTIPART_FORM_DATA).body(form).retrieve().toEntity(byte[].class);}catch(Exception ex){throw new ResponseStatusException(HttpStatus.BAD_GATEWAY,"Local quality report failed",ex);}}
 public Object post(String path,Object json){return call(HttpMethod.POST,path,json);}
 public Object patch(String path,Object json){return call(HttpMethod.PATCH,path,json);}
 private Object call(HttpMethod method,String path,Object payload){
  try{
   var req=client.method(method).uri(path).header(HttpHeaders.AUTHORIZATION,"Bearer "+token).accept(MediaType.APPLICATION_JSON);
   if(payload!=null)req.contentType(MediaType.APPLICATION_JSON).body(payload);
   return req.retrieve().body(Object.class);
  }catch(RestClientResponseException ex){
    throw new UpstreamLfmException(ex.getStatusCode(),ex.getResponseBodyAsString());
  }catch(ResourceAccessException ex){
    throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"LFM API unreachable",ex);
  }
 }
}
