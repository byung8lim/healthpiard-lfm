package com.healthpiard.admin;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
@Service
public class TrainingLogService {
 private final Path root=Path.of("/data/worker-logs");
 public Map<String,Object> log(long jobId){
  if(jobId<=0)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid job ID");
  try{
   if(!Files.isDirectory(root)) return Map.of("jobId",jobId,"log","No worker log directory");
   Path found=null;int maxToken=-1;
   try(var stream=Files.newDirectoryStream(root,"job-"+jobId+"-token-*.log")){
    for(Path p:stream){
     if(!Files.isRegularFile(p,LinkOption.NOFOLLOW_LINKS))continue;
     String n=p.getFileName().toString(); String token=n.substring(("job-"+jobId+"-token-").length(),n.length()-4);
     try{int t=Integer.parseInt(token);if(t>maxToken){maxToken=t;found=p;}}catch(NumberFormatException ignored){}
    }
   }
   if(found==null)return Map.of("jobId",jobId,"log","No log file found");
   long size=Files.size(found),from=Math.max(0,size-32768);byte[] buf;
   try(var in=Files.newInputStream(found)){in.skipNBytes(from);buf=in.readNBytes(32768);}
   return Map.of("jobId",jobId,"token",maxToken,"file",found.getFileName().toString(),"truncated",from>0,"log",new String(buf,StandardCharsets.UTF_8));
  }catch(Exception e){throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,"Worker log unavailable");}
 }
}
