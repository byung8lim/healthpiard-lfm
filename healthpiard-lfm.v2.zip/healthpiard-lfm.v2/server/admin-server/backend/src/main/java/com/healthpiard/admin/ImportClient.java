package com.healthpiard.admin;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.http.*;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.server.ResponseStatusException;
import java.util.*;
@Service
public class ImportClient {
 private final RestClient client;
 ImportClient(@Value("${app.importer-base}") String base,@Value("${app.importer-token}") String token){
  if(token==null||token.isBlank())throw new IllegalStateException("IMPORTER_TOKEN required");
  this.client=RestClient.builder().baseUrl(base).defaultHeader(HttpHeaders.AUTHORIZATION,"Bearer "+token).build();
 }
 public Object get(String path){try{return client.get().uri(path).retrieve().body(Object.class);}catch(RestClientResponseException e){throw new ResponseStatusException(HttpStatus.valueOf(e.getStatusCode().value()),e.getResponseBodyAsString());}}
 public Object post(String path,Object body){
  try {
   byte[] json=new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsBytes(body);
   return client.post().uri(path).contentType(MediaType.APPLICATION_JSON)
       .contentLength(json.length).body(json).retrieve().body(Object.class);
  } catch(com.fasterxml.jackson.core.JsonProcessingException e){
   throw new IllegalStateException("Importer JSON serialization failed",e);
  } catch(RestClientResponseException e){
   throw new ResponseStatusException(HttpStatus.valueOf(e.getStatusCode().value()),e.getResponseBodyAsString());
  }
 }
}
