package com.healthpiard.admin;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import java.util.*;
@Service
public class DbReadService {
  private final NamedParameterJdbcTemplate jdbc;
  private final SqlFiles sql;
  public DbReadService(NamedParameterJdbcTemplate jdbc, SqlFiles sql){this.jdbc=jdbc;this.sql=sql;}
  public List<Map<String,Object>> list(String statement,Map<String,Object> params){return jdbc.queryForList(sql.get(statement),params);}
  public Map<String,Object> first(String statement,Map<String,Object> params){var rows=list(statement,params);return rows.isEmpty()?Map.of():rows.get(0);}
}
