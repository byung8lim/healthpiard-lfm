package com.healthpiard.admin;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.util.*;
@Service
public class BulkQualityService {
 private final NamedParameterJdbcTemplate jdbc; private final SqlFiles sql;
 public BulkQualityService(NamedParameterJdbcTemplate jdbc,SqlFiles sql){this.jdbc=jdbc;this.sql=sql;}
 private void valid(String source,String target){if(!List.of("PENDING","PASS","REJECT").contains(source)|| !List.of("PASS","REJECT","PENDING").contains(target)||source.equals(target)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid transition");}
 @Transactional public Map<String,Object> selected(List<Long> ids,String source,String target){
   valid(source,target);if(ids==null||ids.isEmpty()||ids.size()>1000||ids.stream().anyMatch(i->i==null||i<1))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Select 1..1000 valid image IDs");
   var unique=new LinkedHashSet<>(ids);
   int updated=jdbc.update(sql.get("bulk_quality_ids"),Map.of("ids",unique,"source",source,"target",target));
   return Map.of("requested",unique.size(),"updated",updated,"unchanged",unique.size()-updated,"target",target);
 }
 @Transactional public Map<String,Object> classes(List<ClassItem> items,String source,String target){
   valid(source,target);
   if(items==null||items.isEmpty()||items.size()>500)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Select 1..500 classes");
   Set<Long> seen=new HashSet<>(); long requested=0; int updated=0;
   for(ClassItem item:items){
     if(item==null||item.classId()<=0||item.expectedCount()<0||!seen.add(item.classId()))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid/duplicate class");
     var params=Map.<String,Object>of("classId",item.classId(),"source",source,"target",target);
     // The UI count is advisory: approve only rows still PENDING at execution time.
     // Concurrent ingestion must not roll back approvals of unrelated classes.
     Long count=jdbc.queryForObject(sql.get("class_pending_count"),params,Long.class);
     if(count==null)count=0L;
     if(count>20000)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Class image limit exceeded");
     requested+=count;
     updated+=jdbc.update(sql.get("bulk_quality_class"),params);
   }
   return Map.of("classes",items.size(),"requested",requested,"updated",updated,"target",target);
 }
 public record ClassItem(long classId,long expectedCount){}
 @Transactional public Map<String,Object> foodClass(long classId,String source,String target,long expectedCount){
   valid(source,target);if(classId<=0)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Bad classId");
   var params=Map.<String,Object>of("classId",classId,"source",source,"target",target);
   long count=jdbc.queryForObject(sql.get("class_pending_count"),params,Long.class);
   if(count!=expectedCount)throw new ResponseStatusException(HttpStatus.CONFLICT,"Class image count changed; refresh and confirm again: "+count);
   if(count>20000)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Max 20000 per request");
   int updated=jdbc.update(sql.get("bulk_quality_class"),params);
   return Map.of("classId",classId,"requested",count,"updated",updated,"target",target);
 }
}
