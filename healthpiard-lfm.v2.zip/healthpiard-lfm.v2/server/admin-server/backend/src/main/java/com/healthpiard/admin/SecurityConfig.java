package com.healthpiard.admin;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.web.SecurityFilterChain;
@Configuration
public class SecurityConfig {
 @Bean UserDetailsService users(@Value("${app.admin-user}") String username,@Value("${app.admin-password}") String password) {
   if(password.isBlank() || password.length()<12) throw new IllegalStateException("WEB_ADMIN_PASSWORD must be set and at least 12 characters");
   return new InMemoryUserDetailsManager(User.withUsername(username).password(PasswordEncoderFactories.createDelegatingPasswordEncoder().encode(password)).roles("ADMIN").build());
 }
 @Bean SecurityFilterChain security(HttpSecurity http) throws Exception {
   return http.csrf(c->c.disable())
       .authorizeHttpRequests(a->a.requestMatchers("/assets/**","/favicon.ico").permitAll().anyRequest().authenticated())
       .httpBasic(b->{}).build();
 }
}
