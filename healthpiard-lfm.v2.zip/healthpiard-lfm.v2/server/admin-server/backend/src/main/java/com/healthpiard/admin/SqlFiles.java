package com.healthpiard.admin;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import java.nio.charset.StandardCharsets;
@Component
public class SqlFiles {
  public String get(String name){
    if(!name.matches("[a-z0-9_]+")) throw new IllegalArgumentException("Invalid SQL resource");
    try(var in=new ClassPathResource("sql/"+name+".sql").getInputStream()){
      return new String(in.readAllBytes(),StandardCharsets.UTF_8);
    }catch(Exception e){throw new IllegalStateException("Missing sql/"+name,e);}
  }
}
