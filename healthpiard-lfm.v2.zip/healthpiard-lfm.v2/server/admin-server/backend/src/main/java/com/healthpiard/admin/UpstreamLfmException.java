package com.healthpiard.admin;
import org.springframework.http.HttpStatusCode;
public class UpstreamLfmException extends RuntimeException {
  private final HttpStatusCode status;
  private final String body;
  public UpstreamLfmException(HttpStatusCode status,String body){super("LFM API rejected request");this.status=status;this.body=body;}
  public HttpStatusCode status(){return status;}
  public String body(){return body;}
}
