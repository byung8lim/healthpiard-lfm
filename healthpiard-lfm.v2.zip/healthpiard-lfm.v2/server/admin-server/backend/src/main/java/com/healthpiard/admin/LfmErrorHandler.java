package com.healthpiard.admin;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestControllerAdvice
public class LfmErrorHandler {
  @ExceptionHandler(UpstreamLfmException.class)
  public ResponseEntity<String> upstream(UpstreamLfmException ex){
    return ResponseEntity.status(ex.status()).contentType(MediaType.APPLICATION_JSON).body(ex.body());
  }
}
