UPDATE image_quality SET status=:target, reason_code='ADMIN_BULK_REVIEW', checked_at=UTC_TIMESTAMP(6) WHERE image_id IN (:ids) AND status=:source
