SELECT id,name,status,image_count,train_count,validation_count,test_count,created_by,created_at
 FROM dataset_snapshot ORDER BY id DESC LIMIT 200
