SELECT status,COUNT(*) AS images FROM image_quality GROUP BY status ORDER BY status
