SELECT COUNT(*) AS count FROM image_quality q JOIN class_assignment a ON a.image_id=q.image_id WHERE a.food_class_id=:classId AND q.status=:source
