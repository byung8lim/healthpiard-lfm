SELECT channel_name,active_release_id,revision,updated_by,updated_at FROM release_channel WHERE channel_name='stable'
