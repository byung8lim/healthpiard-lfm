SELECT (SELECT COUNT(*) FROM food_class) AS classes,
 (SELECT COUNT(*) FROM image_object) AS images,
 (SELECT COUNT(*) FROM image_quality WHERE status='PASS') AS approved,
 (SELECT COUNT(*) FROM image_quality WHERE status='PENDING') AS pending,
 (SELECT COUNT(*) FROM image_quality WHERE status='REJECT') AS rejected,
 (SELECT COUNT(*) FROM dataset_snapshot) AS snapshots,
 (SELECT COUNT(*) FROM training_job WHERE status IN ('QUEUED','RUNNING')) AS active_jobs,
 (SELECT COUNT(*) FROM model_release) AS releases
