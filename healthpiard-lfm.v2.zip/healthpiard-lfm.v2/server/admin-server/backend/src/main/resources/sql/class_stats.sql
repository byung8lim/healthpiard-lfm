SELECT f.id, f.class_code, f.food_name, f.status,
 COUNT(DISTINCT a.image_id) AS images,
 COUNT(DISTINCT CASE WHEN q.status='PASS' THEN a.image_id END) AS approved,
 COUNT(DISTINCT CASE WHEN q.status='PENDING' THEN a.image_id END) AS pending,
 COUNT(DISTINCT CASE WHEN q.status='REJECT' THEN a.image_id END) AS rejected
 FROM food_class f LEFT JOIN class_assignment a ON a.food_class_id=f.id
 LEFT JOIN image_quality q ON q.image_id=a.image_id
 GROUP BY f.id,f.class_code,f.food_name,f.status ORDER BY f.food_name
