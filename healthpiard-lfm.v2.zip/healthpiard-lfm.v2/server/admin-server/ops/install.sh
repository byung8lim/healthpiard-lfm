#!/usr/bin/env bash
# Builds and installs the separate Healthpiard admin server. Does not modify LFM source or DB schema.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_USER="${APP_USER:-healthpiard}"
: "${WEB_ADMIN_PASSWORD:?Set WEB_ADMIN_PASSWORD to a unique password of at least 12 characters}"
if [[ ${#WEB_ADMIN_PASSWORD} -lt 12 ]]; then echo 'WEB_ADMIN_PASSWORD is too short' >&2; exit 2; fi
command -v mvn >/dev/null || { echo 'Maven is required (Rocky: dnf install -y maven)' >&2; exit 2; }
command -v npm >/dev/null || { echo 'Node/npm required' >&2; exit 2; }
command -v java >/dev/null || { echo 'Java 21 required' >&2; exit 2; }
cd "$ROOT/frontend"
npm ci --no-audit --no-fund 2>/dev/null || npm install --no-audit --no-fund
npm run build
mkdir -p "$ROOT/backend/src/main/resources/static"
cp -a "$ROOT/frontend/dist/." "$ROOT/backend/src/main/resources/static/"
cd "$ROOT/backend"
mvn -B -q test package
if [[ "$(id -u)" != "0" ]]; then echo 'Build PASS. Run installation as root using sudo -E.'; exit 0; fi
command -v systemctl >/dev/null || { echo 'systemd required' >&2; exit 2; }
getent passwd "$APP_USER" >/dev/null || { echo "Missing user $APP_USER" >&2; exit 2; }
LFM_ENV="${LFM_ENV:-/etc/healthpiard/lfm.env}"
[[ -r "$LFM_ENV" ]] || { echo "Missing env $LFM_ENV" >&2; exit 2; }
# parse DATABASE_URL without emitting credentials to console; create shell-quoted EnvironmentFile.
LFM_ENV="$LFM_ENV" ROOT="$ROOT" python3 - <<'PY'
import os, pathlib, shlex
from urllib.parse import unquote,urlsplit
path=pathlib.Path(os.environ['LFM_ENV'])
settings={}
for line in path.read_text().splitlines():
 line=line.strip()
 if not line or line.startswith('#'):continue
 if line.startswith('export '):line=line[7:]
 if '=' in line:
  k,v=line.split('=',1)
  v=v.strip()
  if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):v=v[1:-1]
  settings[k.strip()]=v
url=urlsplit(settings['DATABASE_URL'])
if not url.scheme.startswith('mysql+'):raise SystemExit('MySQL DATABASE_URL required')
db=unquote(url.path.lstrip('/'))
if db!='healthpiard':raise SystemExit('Refusing admin installer for unexpected database '+db)
vals={
 'ADMIN_JDBC_URL':f'jdbc:mysql://{url.hostname or "127.0.0.1"}:{url.port or 3306}/{db}?useUnicode=true&characterEncoding=utf8&serverTimezone=UTC',
 'ADMIN_DB_USER':unquote(url.username or ''),'ADMIN_DB_PASSWORD':unquote(url.password or ''),
 'LFM_ADMIN_TOKEN':settings.get('ADMIN_TOKEN',''),
 'WEB_ADMIN_USER':os.environ.get('WEB_ADMIN_USER','admin'),
 'WEB_ADMIN_PASSWORD':os.environ['WEB_ADMIN_PASSWORD'],
 'LFM_API_BASE':os.environ.get('LFM_API_BASE','http://127.0.0.1:8080'),
 'ADMIN_PORT':os.environ.get('ADMIN_PORT','8090')}
if not vals['LFM_ADMIN_TOKEN']:raise SystemExit('ADMIN_TOKEN missing in lfm.env')
folder=pathlib.Path('/etc/healthpiard');folder.mkdir(parents=True,exist_ok=True)
out=folder/'admin.env'
out.write_text(''.join(f'{k}={shlex.quote(v)}\n' for k,v in vals.items()))
out.chmod(0o600)
PY
install -d -o "$APP_USER" -g "$APP_USER" /opt/healthpiard-admin
install -m 0644 "$ROOT/backend/target/healthpiard-admin-0.10.0.jar" /opt/healthpiard-admin/admin.jar
cat > /etc/systemd/system/healthpiard-admin.service <<'SERVICE'
[Unit]
Description=Healthpiard Spring Boot React Admin
After=network-online.target mysqld.service healthpiard-lfm-api.service
Wants=network-online.target
[Service]
Type=simple
User=healthpiard
Group=healthpiard
WorkingDirectory=/opt/healthpiard-admin
EnvironmentFile=/etc/healthpiard/admin.env
ExecStart=/usr/bin/java -jar /opt/healthpiard-admin/admin.jar
Restart=on-failure
RestartSec=5
NoNewPrivileges=yes
PrivateTmp=yes
[Install]
WantedBy=multi-user.target
SERVICE
systemctl daemon-reload
systemctl enable --now healthpiard-admin
for i in $(seq 1 40);do code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 2 http://127.0.0.1:${ADMIN_PORT:-8090}/admin-api/overview || true); if [[ "$code" == '401' ]];then break;fi; sleep 1;done
systemctl is-active --quiet healthpiard-admin || { journalctl -u healthpiard-admin -n 30 --no-pager; exit 1; }
echo "ADMIN INSTALLED | http://<server-ip>:${ADMIN_PORT:-8090}/ | Basic authentication required"
