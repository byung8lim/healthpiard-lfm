#!/usr/bin/env bash
# Build/run one container on Rocky Linux 9 with LFM API + MySQL running on host.
# Usage: sudo bash ops/docker-run.sh [image-tag]
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="${1:-healthpiard-admin:v010}"
LFM_ENV="${LFM_ENV:-/etc/healthpiard/lfm.env}"
CONFIG="${ADMIN_DOCKER_ENV:-/etc/healthpiard/admin-docker.env}"
[[ "$(id -u)" -eq 0 ]] || { echo 'ERROR: run with sudo/root' >&2; exit 2; }
[[ -r "$LFM_ENV" ]] || { echo "ERROR: cannot read $LFM_ENV" >&2; exit 2; }
command -v docker >/dev/null || { echo 'ERROR: Docker not installed' >&2; exit 2; }
if [[ -z "${WEB_ADMIN_PASSWORD:-}" ]]; then
  read -rsp 'New web admin password (min 12 characters): ' WEB_ADMIN_PASSWORD
  echo
fi
[[ ${#WEB_ADMIN_PASSWORD} -ge 12 ]] || { echo 'ERROR: password must be at least 12 chars' >&2; exit 2; }
export WEB_ADMIN_PASSWORD
install -d -m 0700 "$(dirname "$CONFIG")"
# Parse LFM env; write root-readable, non-shell Docker env-file without printing secrets.
LFM_ENV="$LFM_ENV" ADMIN_DOCKER_ENV="$CONFIG" WEB_ADMIN_PASSWORD="$WEB_ADMIN_PASSWORD" python3 - <<'PY'
import os, pathlib, shlex
from urllib.parse import urlsplit,unquote
source=pathlib.Path(os.environ['LFM_ENV'])
values={}
for line in source.read_text().splitlines():
    line=line.strip()
    if not line or line.startswith('#'): continue
    if line.startswith('export '): line=line[7:].strip()
    if '=' not in line: continue
    k,v=line.split('=',1)
    v=v.strip()
    if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
        v=v[1:-1]
    values[k.strip()]=v
url=urlsplit(values.get('DATABASE_URL',''))
if not url.scheme.startswith('mysql+') or unquote(url.path.lstrip('/')) != 'healthpiard':
    raise SystemExit('ERROR: Expected production MySQL DB healthpiard')
token=values.get('ADMIN_TOKEN','')
if not token: raise SystemExit('ERROR: ADMIN_TOKEN not set')
config={
    'ADMIN_JDBC_URL': f'jdbc:mysql://127.0.0.1:{url.port or 3306}/healthpiard?useUnicode=true&characterEncoding=utf8&serverTimezone=UTC',
    'ADMIN_DB_USER': unquote(url.username or ''),
    'ADMIN_DB_PASSWORD': unquote(url.password or ''),
    'LFM_API_BASE': 'http://127.0.0.1:8080',
    'LFM_ADMIN_TOKEN': token,
    'WEB_ADMIN_USER': os.getenv('WEB_ADMIN_USER','admin'),
    'WEB_ADMIN_PASSWORD': os.environ['WEB_ADMIN_PASSWORD'],
    'ADMIN_PORT': os.getenv('ADMIN_PORT','8090')
}
for k,v in config.items():
    if '\n' in v or '\r' in v: raise SystemExit(f'ERROR: invalid newline in {k}')
p=pathlib.Path(os.environ['ADMIN_DOCKER_ENV'])
fd=os.open(str(p),os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
with os.fdopen(fd,'w') as f:
    for k,v in config.items(): f.write(f'{k}={v}\n')
p.chmod(0o600)
print('Docker environment file prepared:',p,'(credentials hidden)')
PY
unset WEB_ADMIN_PASSWORD
cd "$ROOT"
docker build -t "$IMAGE" .
if docker container inspect healthpiard-admin >/dev/null 2>&1; then
  echo 'Replacing previous stateless healthpiard-admin container'
  docker rm -f healthpiard-admin >/dev/null
fi
docker run -d --name healthpiard-admin \
  --restart unless-stopped --network host \
  --env-file "$CONFIG" \
  --memory 1g --cpus 2 \
  "$IMAGE"
echo 'Admin URL: http://<Rocky-server-IP>:8090/'
echo 'Check: docker logs --tail 50 healthpiard-admin'
echo 'CAUTION: HTTP Basic over plain HTTP. Use private network / TLS reverse proxy; do not expose publicly.'
