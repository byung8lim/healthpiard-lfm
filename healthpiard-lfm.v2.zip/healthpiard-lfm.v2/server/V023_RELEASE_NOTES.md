# Healthpiard V023 — prevent late TEST image failure

## Confirmed V022 defect

V022 trained from cached TRAIN and VALIDATION tensors but re-read TEST JPEGs after 30 epochs. Any removed/moved/unsafe TEST image caused `Missing/unsafe image <id>` after all CPU training.

## V023 changes

- Preflight all TEST images (path, SHA-256, decoding) **before** training. A missing image stops the job before epoch 1.
- Pack TEST images into snapshot-keyed, disk-backed NPY cache. TFLite verification reads that same cache; no second JPEG read after training.
- Re-running an already completed training job with its job-local checkpoint, matching snapshot and valid worker lease can skip the training loop when `completedEpochs >= epochs`. Do NOT remove its training volumes.
- Publication now preserves best-validation Keras model rather than last-epoch checkpoint.
- Default training epochs 10 (when no job-specific config overrides it). Existing jobs with 30 epochs remain configured for 30.
- Measured prior log: final train accuracy 98.44%, validation 64.73%, peak validation 65.81%. This does **not** meet 90% holdout publication requirement. The 90% release gate is NOT disabled.

## Deploy / safety

Preserve DB, image-object volume, tensor-cache volume, and training-run volume. Upgrade worker and API images with `docker compose --env-file config.env build lfm-worker lfm-api` and `docker compose --env-file config.env up -d lfm-worker lfm-api`. No `down -v`.

If previous TEST images are already missing, V023 cannot recreate their original content. Restore the images, or create a new approved snapshot. Retained training checkpoints may be reused only when their job snapshot, class mapping, lease, and configured epochs match.

This is a source patch, not proof of 90% generalization or successful live release; CPU/TensorFlow integration requires verification on the actual server.
