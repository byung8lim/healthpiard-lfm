# Healthpiard-LFM V008 (source + reinstall + automated verification)

## V007 defect ledger

| Finding | Reproduced effect | V008 corrective change |
|---|---|---|
| D-01 Trainer imports `app.worker.OWNER` in child process | Lease ownership PID mismatch and failed job | Worker propagates `HEALTHPIARD_LEASE_OWNER`; trainer consumes it |
| D-02 Export raises when holdout below 0.90 | Job FAILED even though valid .tflite exists | Keep valid TFLite; `validation.passed=false`; API release gate still rejects |
| D-03 No Snapshot Item INSERT protection | After-completion dataset may be appended to | `dataset_snapshot.status` plus BEFORE INSERT trigger; only CREATING admits items |
| D-04 Runtime fixes missing from install source | Clean reinstall restores bugs | Bundled fresh schema and source changes |
| D-05 Repeated manual smoke checks | Lengthy verification, inconsistent coverage | `ops/verify_v008.sh`, integration `--full` opt-in |

## 1. Clean reinstall (destructive actions only on disposable/dedicated instance)

1. Back up V007 DB, image objects, run artifacts, and `/etc/healthpiard/lfm.env` **outside the target**. Do not drop production or old V007 schema with these scripts.
2. On Rocky Linux 9 with `python3.11`, `mysql` client, accessible MySQL 8, create a **new empty schema and dedicated app DB account** with appropriate CREATE/TRIGGER privileges. Make the DB URL point at this empty schema.
3. Unpack V008 to `/opt/healthpiard/lfm`, set ownership and create `/etc/healthpiard/lfm.env` (mode 0600) with at least DATABASE_URL, ADMIN_TOKEN, OBJECT_ROOT, ARTIFACT_ROOT, TRAIN_ROOT, WORKER_LOG_DIR. Example values in `.env.example`; don't copy placeholder credentials.
4. `set -a; source /etc/healthpiard/lfm.env; set +a; bash ops/install_v008.sh` — requires typing `INSTALL-V008`. Refuses a nonempty schema, does not DROP any table. Installs API and worker Python dependencies and loads *fresh* V008 schema.
5. Provision `healthpiard` user and ownership to project/data directories; copy `ops/healthpiard-lfm-api.service` and `ops/healthpiard-lfm-worker.service` into `/etc/systemd/system`. `systemctl daemon-reload && systemctl enable --now healthpiard-lfm-api healthpiard-lfm-worker`.
6. `set -a; source /etc/healthpiard/lfm.env; set +a; API_URL=http://127.0.0.1:8080 bash ops/verify_v008.sh`.

**Do not point the new installer at the existing V007 schema.** `db/migration/V008__snapshot_immutability.sql` is supplied for controlled preservation/migration of an old V007 database, not for the clean-install route.

## 2. Automated verification levels

- `bash ops/verify_v008.sh`: Python source compilation, pytest regression, MySQL schema and trigger inspection, actual rollback-wrapped UPDATE/INSERT immutability attempts if a completed snapshot exists, OpenAPI and admin authorization check. **No training or feeder writes.** Returns nonzero on FAIL. Requires running API, matching environment, and a reachable MySQL instance.
- `V008_TEST_MODE=YES bash ops/verify_v008.sh --full`: in addition, writes 20 synthetic images across two classes, approves them, builds a snapshot, queues CPU training, waits for Worker, loads 2-class TFLite and tests the quality-based candidate gate. Requires DB name ending `_v008_test`, correct `TRAIN_ROOT`, and running API/Worker pointing **to the same isolated test database**. Does NOT activate a model. **Synthetic data are test-only and must not be used for a real release.** Default training wait maximum is 1800 seconds; override `V008_E2E_TIMEOUT` if needed.
- The automatic verification is designed and syntax-checked, **but has NOT been executed against a real MySQL/Worker server in this authoring environment**. Thus this package is a V008 release candidate, not an operationally certified release.

## 3. Known limitations / quality gates

- Snapshot creation still requires proper DB access separation; administrators with direct ALTER/TRIGGER privileges can bypass triggers. Grant the runtime only minimal privileges after installation.
- Existing seed datasets consisting of 20 test JPEGs don't establish food recognition accuracy; 90% pass/fail is not a meaningful real-world metric at 2 holdout examples.
- Full synthetic E2E may discover integration defects. Don't claim production readiness before passing it on a clean server.
- A FAILED training job caused by OOM/restart and active/rollback mobile model lifecycle require further dedicated fault-injection verification. These are not automatically covered by the default suite.
- Environment dependencies are not fully pinned for offline deterministic rebuild (TensorFlow version is pinned). For strictly reproducible offline installation, additionally archive wheels and lock dependencies.

## Version policy

Do not change the installed runtime files manually. Edit the versioned V008 repository files, run source tests and package them. Keep immutable release artifacts and check SHA-256 of the ZIP when transferring.
