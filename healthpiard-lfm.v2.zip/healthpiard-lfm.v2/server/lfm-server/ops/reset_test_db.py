"""Highly guarded test schema wipe. Never allowed against production schema."""
import os,re,subprocess,sys
from urllib.parse import urlsplit,unquote
u=urlsplit(os.environ['DATABASE_URL'])
db=unquote(u.path.lstrip('/'))
if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*_v008_test',db) or os.getenv('V008_TEST_MODE')!='YES':
    sys.exit('REFUSED: only *_v008_test database with V008_TEST_MODE=YES can be reset')
print('DESTRUCTIVE ACTION: DROP DATABASE',db,flush=True)
if input(f'Type DELETE {db}: ')!=f'DELETE {db}':sys.exit('Cancelled')
env=os.environ.copy();env['MYSQL_PWD']=unquote(u.password or '')
args=['mysql',f'--host={u.hostname}',f'--port={u.port or 3306}',f'--user={unquote(u.username or "")}']
cmd=f'DROP DATABASE `{db}`; CREATE DATABASE `{db}` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;'
subprocess.run(args,input=cmd,text=True,env=env,check=True)
print('RESET OK: Re-run bash ops/install_v008.sh to rebuild schema/dependencies.')
