#!/usr/bin/env bash
set -euo pipefail
: "${API_URL:=http://127.0.0.1:8080}"
python -m compileall -q app ops
python -m pytest -q tests/test_contract.py tests/test_platform_contract.py tests/test_release_code.py tests/test_audit_fixes.py
curl --fail --silent "${API_URL}/openapi.json" >/dev/null
echo 'Static regression and API endpoint passed. Not an E2E training smoke test.'
