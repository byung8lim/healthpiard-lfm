"""V009 regression and DB / API checks; read-only apart from rolled-back probes."""
import os
import json
import urllib.request
import urllib.error
from pathlib import Path
from sqlalchemy import create_engine, text
from sqlalchemy.exc import DBAPIError

root=Path(__file__).resolve().parents[1]

def verify():
    worker=(root/'app/worker.py').read_text()
    lease=(root/'app/trainer/lease.py').read_text()
    core=(root/'app/trainer/core.py').read_text()
    assert "trainer_env['HEALTHPIARD_LEASE_OWNER']=OWNER" in worker
    assert "os.environ.get('HEALTHPIARD_LEASE_OWNER')" in lease
    assert "TRAIN_ROOT = Path(os.getenv('TRAIN_ROOT'" in core
    for k in ('TRAIN_ROOT','TENSOR_CACHE_ROOT','WORKER_LOG_DIR','OBJECT_ROOT','ARTIFACT_ROOT'):
        assert k in os.environ and os.environ[k], f'Missing {k}'
    engine=create_engine(os.environ['DATABASE_URL'])
    with engine.connect() as c:
        db=c.execute(text('SELECT DATABASE()')).scalar_one()
        tables={r[0] for r in c.execute(text('SHOW TABLES'))}
        assert {'food_class','image_object','dataset_snapshot','dataset_snapshot_item','training_job','model_release'} <= tables
        ts={r[0] for r in c.execute(text('SELECT TRIGGER_NAME FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE()'))}
        assert {'trg_snapshot_item_insert_guard','trg_snapshot_no_update','trg_snapshot_no_delete','trg_snapshot_item_no_update','trg_snapshot_item_no_delete'} <= ts
        snapshot=c.execute(text("SELECT id FROM dataset_snapshot WHERE status='COMPLETED' ORDER BY id LIMIT 1")).scalar()
    if snapshot is not None:
        for sql, params in [
            ('UPDATE dataset_snapshot SET name=name WHERE id=:sid', {'sid':snapshot}),
            ("INSERT INTO dataset_snapshot_item(snapshot_id,image_id,food_class_id,split,sha256,storage_key) VALUES (:sid,0,0,'TRAIN',UNHEX(REPEAT('00',32)),'bad')", {'sid':snapshot}),
        ]:
            with engine.connect() as conn:
                tx=conn.begin()
                try:
                    try: conn.execute(text(sql),params)
                    except DBAPIError as e:
                        if '1644' not in str(e.orig) and '45000' not in str(e.orig):raise
                    else:raise AssertionError('Snapshot mutation permitted')
                finally:tx.rollback()
    url=os.environ['API_URL'].rstrip('/')
    with urllib.request.urlopen(url+'/openapi.json',timeout=10) as r:
        paths=json.load(r)['paths']
    assert '/api/v1/feedFoodModel' in paths and '/api/v1/admin/training-jobs' in paths
    req=urllib.request.Request(url+'/api/v1/admin/classes')
    try:urllib.request.urlopen(req,timeout=10)
    except urllib.error.HTTPError as e:assert e.code in (401,403)
    else:raise AssertionError('Admin API has no auth')
    print(f'PASS | DB + TRIGGERS + API | {db} | existing_snapshot={snapshot is not None}',flush=True)

if __name__=='__main__':verify()
