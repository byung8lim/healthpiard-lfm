"""Destructive disposable-schema integration: feeder -> snapshot -> CPU job -> TFLite -> gate."""
import hashlib,io,json,os,random,sys,time,urllib.request,urllib.error,uuid
from urllib.parse import urlsplit
from pathlib import Path
from PIL import Image

url=os.getenv('API_URL','http://127.0.0.1:8080').rstrip('/')
name=urlsplit(os.environ['DATABASE_URL']).path.lstrip('/')
if not (name.endswith('_v009_test') and os.environ.get('V009_TEST_MODE')=='YES'):
    sys.exit('REFUSED: disposable *_v009_test schema and V009_TEST_MODE=YES required')
auth=os.environ['ADMIN_TOKEN']
uid=uuid.uuid4().hex[:12]

def call(method,path,data=None,admin=True,multipart=False):
    headers={'Authorization':'Bearer '+auth} if admin else {}
    if data is not None and not multipart:
        data=json.dumps(data).encode();headers['Content-Type']='application/json'
    if multipart:
        bound='v009'+uid
        payload=b''
        for k,v in data.items():
            if k=='image':
                payload+=('--'+bound+'\r\nContent-Disposition: form-data; name="image"; filename="test.jpg"\r\nContent-Type: image/jpeg\r\n\r\n').encode()+v+b'\r\n'
            else:
                payload+=('--'+bound+f'\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n').encode()
        payload+=('--'+bound+'--\r\n').encode();data=payload;headers['Content-Type']='multipart/form-data; boundary='+bound
    req=urllib.request.Request(url+path,data=data,method=method,headers=headers)
    try:
        with urllib.request.urlopen(req,timeout=60) as r:return r.status,json.load(r)
    except urllib.error.HTTPError as e:
        return e.code,json.loads(e.read().decode())

# Resume a previously completed E2E job after failure in the verifier.
# Never retrain or add more test images when the existing trained model is reusable.
from sqlalchemy import create_engine,text
engine=create_engine(os.environ['DATABASE_URL'])
with engine.connect() as conn:
    previous=conn.execute(text("""SELECT j.id, j.snapshot_id, j.result_json
        FROM training_job j JOIN dataset_snapshot s ON s.id=j.snapshot_id
        WHERE j.requested_by='v009-e2e' AND j.status='SUCCEEDED'
          AND s.created_by='v009-e2e' AND s.status='COMPLETED'
        ORDER BY j.id DESC LIMIT 1""")).mappings().first()
if previous:
    print('RESUME | previous E2E job',previous['id'],flush=True)
    result=previous['result_json']
    if isinstance(result,str):result=json.loads(result)
    model=Path(result['tfliteModel'])
    if not model.is_file():raise RuntimeError(f'Resumed job model missing: {model}')
    import subprocess
    worker=str(Path(__file__).resolve().parents[1]/'.venv-worker'/'bin'/'python')
    check_code='import tensorflow as tf,sys; i=tf.lite.Interpreter(model_path=sys.argv[1]); i.allocate_tensors(); assert list(i.get_output_details()[0]["shape"])==[1,2]'
    subprocess.run([worker,'-c',check_code,str(model)],check=True)
    print('PASS | RESUMED CPU TRAIN + TFLITE |',previous['id'],flush=True)
    validation=result['validation']
    version='v009-e2e-resume-'+str(previous['id'])
    code,out=call('POST','/api/v1/admin/releases/candidates',{'jobId':previous['id'],'versionTag':version})
    if validation['passed']:
        assert code in (201,409),f'Approved model unexpected candidate response: {code} {out}'
        if code==409:
            with engine.connect() as conn:
                count=conn.execute(text('SELECT COUNT(*) FROM model_release WHERE job_id=:jid'),{'jid':previous['id']}).scalar_one()
            assert count>0,'Quality passed but candidate was not created'
        print('PASS | RESUMED QUALITY GATE | candidate exists/created',flush=True)
    else:
        assert code==409,f'Quality failed but candidate accepted: {code} {out}'
        with engine.connect() as conn:
            count=conn.execute(text('SELECT COUNT(*) FROM model_release WHERE job_id=:jid'),{'jid':previous['id']}).scalar_one()
        assert count==0,'Quality-failed model already has release'
        print('PASS | RESUMED QUALITY GATE | rejected HTTP 409; no release',flush=True)
    print('RESULT: PASS | RESUMED FULL E2E',flush=True)
    sys.exit(0)

ids=[]
first_request = None
for c in range(2):
    for i in range(10):
        rng=random.Random(c*100+i)
        im=Image.new('RGB',(160,160))
        pix=im.load()
        for y in range(160):
            for x in range(160):
                v=rng.randrange(16)
                pix[x,y]=((180+v,30+v,25+v) if c==0 else (25+v,50+v,170+v))
        buf=io.BytesIO();im.save(buf,format='JPEG',quality=85)
        payload={'clientId':'v009-e2e-'+uid,'clientRequestId':f'{c}-{i}',
                 'foodName':f'V009_AUTOTEST_{uid}_{c}','classCode':f'V009_AUTOTEST_{uid}_{c}',
                 'servingG':'100','caloriesKcal':'100','image':buf.getvalue()}
        if c == 0 and i == 0:
            first_request = dict(payload)
        code,out=call('POST','/api/v1/feedFoodModel',payload,admin=False,multipart=True)
        assert code in (200,201),f'ingest {code} {out}'
        image_id=out.get('imageId'); assert image_id,f'no imageId {out}'
        code,out=call('PATCH',f'/api/v1/admin/images/{image_id}/quality',{'status':'PASS','reasonCode':'V009_E2E'})
        assert code==200,(code,out)
        ids.append(image_id)
print('PASS | FEEDER AND QUALITY |',len(ids),'images, two classes',flush=True)
# Replaying the same client request must not produce a duplicate record.
code,replay=call('POST','/api/v1/feedFoodModel',first_request,admin=False,multipart=True)
assert code in (200,201) and replay.get('imageId')==ids[0] and replay.get('idempotentReplay') is True, (code,replay)
# Same JPEG and a different request ID must resolve to the same image by SHA256.
same_sha=dict(first_request,clientRequestId='sha-dedup-'+uid)
code,dedup=call('POST','/api/v1/feedFoodModel',same_sha,admin=False,multipart=True)
assert code in (200,201) and dedup.get('imageId')==ids[0], (code,dedup)
print('PASS | FEEDER REPLAY + SHA256 DEDUP',flush=True)
code,out=call('POST','/api/v1/admin/snapshots',{'name':'v009-e2e-'+uid,'splitSeed':42,'trainRatio':.8,'validationRatio':.1,'actor':'v009-e2e'})
assert code==201,(code,out)
sid=out['snapshotId']
print('PASS | SNAPSHOT |',sid,flush=True)
# V009 DB-level immutability must reject mutations after COMPLETED.
from sqlalchemy import create_engine,text
from sqlalchemy.exc import DBAPIError
engine=create_engine(os.environ['DATABASE_URL'])
for sql in [
    'UPDATE dataset_snapshot SET name=name WHERE id=:sid',
    "INSERT INTO dataset_snapshot_item(snapshot_id,image_id,food_class_id,split,sha256,storage_key) VALUES (:sid,0,0,'TRAIN',UNHEX(REPEAT('00',32)),'v009-invalid')"
]:
    with engine.connect() as conn:
        tx=conn.begin()
        try:
            try:conn.execute(text(sql),{'sid':sid})
            except DBAPIError as ex:
                assert '1644' in str(ex.orig) or '45000' in str(ex.orig),str(ex)
            else:raise AssertionError('Immutable snapshot mutation was allowed')
        finally:tx.rollback()
print('PASS | SNAPSHOT UPDATE + INSERT BLOCKED',flush=True)
code,out=call('POST','/api/v1/admin/training-jobs',{'snapshotId':sid,'actor':'v009-e2e','epochs':1,'batchSize':2,'maxAttempts':1})
assert code==201,(code,out)
job=out['jobId'];print('JOB |',job,'| wait for worker',flush=True)
end=time.monotonic()+int(os.getenv('V009_E2E_TIMEOUT','1800'))
while time.monotonic()<end:
    code,out=call('GET',f'/api/v1/admin/training-jobs/{job}')
    assert code==200,(code,out)
    if out['status'] in ('SUCCEEDED','FAILED','CANCELLED'):break
    time.sleep(5)
else:sys.exit('FAIL | TRAINING | timeout waiting for worker')
assert out['status']=='SUCCEEDED',f'job {job} failed: {out.get("error_message")}'
result=out['result_json'];assert result['trained']
model=Path(result['tfliteModel']);assert model.is_file()
# Worker creates MobileNetV3 TFLite; verify output using TensorFlow worker environment.
import subprocess
worker=str(Path(__file__).resolve().parents[1] / '.venv-worker' / 'bin' / 'python')
assert Path(worker).is_file(), f'Missing TensorFlow worker interpreter: {worker}'
code='import tensorflow as tf,sys; i=tf.lite.Interpreter(model_path=sys.argv[1]);i.allocate_tensors();assert list(i.get_output_details()[0]["shape"])==[1,2]'
subprocess.run([worker,'-c',code,str(model)],check=True)
print('PASS | CPU TRAIN + TWO-CLASS TFLITE |',job,flush=True)
validation=result['validation'];passed=validation['passed']
code,out=call('POST','/api/v1/admin/releases/candidates',{'jobId':job,'versionTag':'v009-e2e-'+uid})
if passed:
    assert code==201,f'quality passed but candidate failed: {code} {out}'
    print('PASS | RELEASE CANDIDATE | quality passed, candidate created (NOT ACTIVATED)',flush=True)
else:
    assert code==409,f'quality failed yet candidate not rejected: {code} {out}'
    print('PASS | QUALITY RELEASE GATE | quality failed, HTTP 409, no candidate',flush=True)
print('RESULT: PASS | FULL E2E (test database only)')
