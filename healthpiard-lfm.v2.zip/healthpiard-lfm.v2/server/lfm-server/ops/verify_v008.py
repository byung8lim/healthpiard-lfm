"""Read-only V008 verification. --full requires a dedicated throwaway test DB.
Does NOT enqueue training or mutate production data by default.
"""
import os,sys,json,urllib.request,urllib.error
from sqlalchemy import create_engine,text

failures=[]
def check(name,fn):
    try:
        detail=fn()
        print(f'PASS | {name} | {detail or "OK"}')
    except Exception as ex:
        failures.append((name,str(ex)))
        print(f'FAIL | {name} | {ex}')

def db_checks():
    engine=create_engine(os.environ['DATABASE_URL'])
    with engine.connect() as c:
        schema=c.execute(text('SELECT DATABASE()')).scalar_one()
        tables={r[0] for r in c.execute(text('SHOW TABLES')).all()}
        required={'food_class','image_object','ingestion_request','dataset_snapshot','dataset_snapshot_item','training_job','model_release','release_channel'}
        assert required <= tables,f'Missing tables: {required-tables}'
        cols={r[0] for r in c.execute(text('SHOW COLUMNS FROM dataset_snapshot')).all()}
        assert 'status' in cols,'V008 dataset_snapshot.status missing'
        ts={r[0] for r in c.execute(text("SELECT TRIGGER_NAME FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE()"))}
        required_triggers={'trg_snapshot_no_update','trg_snapshot_no_delete','trg_snapshot_item_no_update','trg_snapshot_item_no_delete','trg_snapshot_item_insert_guard'}
        assert required_triggers<=ts,f'Missing triggers: {required_triggers-ts}'
        assert c.execute(text("SELECT COUNT(*) FROM dataset_snapshot WHERE status <> 'COMPLETED'")).scalar_one()==0,'Incomplete snapshots found'
        # Regression in transaction: existing completed snapshot must reject UPDATE and INSERT.
        row=c.execute(text("SELECT id FROM dataset_snapshot WHERE status='COMPLETED' LIMIT 1")).first()
        if row:
            sid=row[0]
            from sqlalchemy.exc import DBAPIError
            for sql,params in [
                ('UPDATE dataset_snapshot SET name=name WHERE id=:sid',{'sid':sid}),
                ("INSERT INTO dataset_snapshot_item (snapshot_id,image_id,food_class_id,split,sha256,storage_key) VALUES (:sid,0,0,'TRAIN',UNHEX(REPEAT('00',32)),'invalid-test')",{'sid':sid})]:
                with engine.connect() as chk:
                    tr=chk.begin()
                    try:
                        try:chk.execute(text(sql),params)
                        except DBAPIError as e:
                            assert '1644' in str(e.orig) or '45000' in str(e.orig),f'Unexpected DB failure: {e}'
                        else:raise AssertionError('Immutable snapshot mutation was ALLOWED')
                    finally:tr.rollback()
        return f'schema={schema}, triggers={len(ts)}, snapshot mutation blocked' if row else f'schema={schema}, triggers={len(ts)}; no snapshot to challenge'

def api_checks():
    url=os.getenv('API_URL','http://127.0.0.1:8080').rstrip('/')
    with urllib.request.urlopen(url+'/openapi.json',timeout=8) as r:
        d=json.load(r)
    paths=d['paths']
    expected={'/api/v1/feedFoodModel','/api/v1/admin/snapshots','/api/v1/admin/training-jobs','/api/v1/admin/releases/candidates','/api/v1/releases/latest'}
    assert expected <= set(paths),f'Missing endpoints: {expected-set(paths)}'
    # Explicit auth rejection: no DB changes.
    req=urllib.request.Request(url+'/api/v1/admin/classes')
    try:urllib.request.urlopen(req,timeout=8)
    except urllib.error.HTTPError as e:assert e.code in (401,403),f'Expected 401/403, got {e.code}'
    else:raise AssertionError('Admin API accessible without bearer token')
    return f'OpenAPI + auth OK: {url}'

def static_checks():
    from pathlib import Path
    root=Path(__file__).resolve().parents[1]
    worker=(root/'app/worker.py').read_text()
    lease=(root/'app/trainer/lease.py').read_text()
    export=(root/'app/trainer/export.py').read_text()
    api=(root/'app/platform.py').read_text()
    assert "trainer_env['HEALTHPIARD_LEASE_OWNER']=OWNER" in worker
    assert 'env=trainer_env' in worker
    assert "os.environ.get('HEALTHPIARD_LEASE_OWNER')" in lease
    assert "'passed':accuracy >= min_accuracy" in export
    assert "SET status='COMPLETED'" in api
    assert "result.get('validation',{}).get('passed')" in api
    return 'lease propagation, quality gate, snapshot close, release gate'

check('SOURCE CONTRACT',static_checks)
check('MYSQL V008 STRUCTURE AND IMMUTABILITY',db_checks)
check('HTTP API AND AUTH',api_checks)
if '--full' in sys.argv:
    # Separate destructive end-to-end workflow intentionally requires explicit opt-in and a dedicated schema.
    from urllib.parse import urlsplit
    db=urlsplit(os.environ['DATABASE_URL']).path.lstrip('/')
    assert db.endswith('_v008_test') and os.getenv('V008_TEST_MODE')=='YES', \
        '--full requires disposable *_v008_test database and V008_TEST_MODE=YES'
    import subprocess
    p=subprocess.run([sys.executable,'ops/e2e_v008.py'])
    if p.returncode:failures.append(('FULL CPU TRAINING',f'exit={p.returncode}'))
print(f'RESULT: {"FAIL" if failures else "PASS"} ({len(failures)} failures)')
sys.exit(1 if failures else 0)
