#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
: "${DATABASE_URL:?Missing DATABASE_URL}"
: "${ADMIN_TOKEN:?Missing ADMIN_TOKEN}"
: "${API_URL:=http://127.0.0.1:8080}"
PYTHON="${PYTHON:-.venv-api/bin/python}"
"$PYTHON" -m compileall -q app ops
"$PYTHON" -m pytest -q tests
"$PYTHON" ops/verify_v008.py "$@"
