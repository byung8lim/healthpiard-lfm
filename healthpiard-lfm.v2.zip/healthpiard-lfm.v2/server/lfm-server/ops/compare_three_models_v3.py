"""CPU-side acceptance check using identical files and preprocessing.
Usage: python ops/compare_three_models_v3.py --keras /path/model.keras --job-tflite /path/job/model.tflite --release /path/release --images /path/images --output report.csv
"""
import argparse, csv, hashlib, json, sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.inference_contract import class_entries, predict_keras, predict_tflite

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    a=argparse.ArgumentParser();a.add_argument('--keras',required=True);a.add_argument('--job-tflite',required=True);a.add_argument('--release',required=True);a.add_argument('--images',required=True);a.add_argument('--output',required=True);a.add_argument('--max-error',type=float,default=0.02); args=a.parse_args()
    import tensorflow as tf
    release=Path(args.release);job=Path(args.job_tflite);kp=Path(args.keras)
    manifest=json.loads((release/'manifest.json').read_text())
    for filename,entry in manifest['files'].items():
        if sha(release/filename)!=entry['sha256']:raise RuntimeError('Release SHA mismatch: '+filename)
    idx1=class_entries(job.parent/'class_index.json');idx2=class_entries(release/'class_index.json')
    if [(x['foodClassId'],x['index']) for x in idx1]!=[(x['foodClassId'],x['index']) for x in idx2]:raise RuntimeError('Class index mismatch')
    if sha(job)!=sha(release/'model.tflite'):raise RuntimeError('Job and release TFLite bytes differ')
    model=tf.keras.models.load_model(kp,compile=False)
    def interp(path):
        i=tf.lite.Interpreter(model_path=str(path));i.allocate_tensors();return i
    j=interp(job);r=interp(release/'model.tflite')
    images=sorted(p for p in Path(args.images).rglob('*') if p.suffix.lower() in ('.jpg','.jpeg','.png','.webp'))
    if not images:raise RuntimeError('No test images found')
    rows=[];fail=0;maxdiff=0
    for f in images:
        k=predict_keras(model,f,len(idx1)); t=predict_tflite(j,f,len(idx1)); v=predict_tflite(r,f,len(idx1))
        d=float(np.max(np.abs(k-t)));dr=float(np.max(np.abs(t-v)));maxdiff=max(maxdiff,d,dr)
        ok=int(np.argmax(k))==int(np.argmax(t))==int(np.argmax(v)) and d<=args.max_error and dr<=args.max_error
        fail+=not ok
        rows.append([str(f),int(np.argmax(k)),int(np.argmax(t)),int(np.argmax(v)),float(max(k)),float(max(t)),float(max(v)),d,dr,'PASS' if ok else 'FAIL'])
    output=Path(args.output);output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('w',encoding='utf-8-sig',newline='') as out:
        w=csv.writer(out);w.writerow(['image','keras_index','job_index','release_index','keras_confidence','job_confidence','release_confidence','keras_job_max_abs_error','job_release_max_abs_error','result']);w.writerows(rows)
    print(json.dumps({'images':len(rows),'failures':fail,'maxAbsoluteError':maxdiff,'report':str(output)},ensure_ascii=False))
    if fail:sys.exit(1)
if __name__=='__main__':main()
