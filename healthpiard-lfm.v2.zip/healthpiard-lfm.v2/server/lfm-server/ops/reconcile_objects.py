"""Report old orphan objects; deliberately NEVER auto-delete."""
import argparse, time
from pathlib import Path
from sqlalchemy import text
from app.main import OBJECT_ROOT, engine

def report(grace_seconds=86400):
    with engine.connect() as c:
        keys={r[0] for r in c.execute(text("SELECT storage_key FROM image_object"))}
    old=[]
    for path in (OBJECT_ROOT/'sha256').glob('*/*/*'):
        if not path.is_file():continue
        key=str(path.relative_to(OBJECT_ROOT))
        if key not in keys and time.time()-path.stat().st_mtime > grace_seconds:
            old.append(key)
    return old

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--grace-seconds',type=int,default=86400);a=p.parse_args()
    for orphan in report(a.grace_seconds):print('ORPHAN_REVIEW',orphan)
