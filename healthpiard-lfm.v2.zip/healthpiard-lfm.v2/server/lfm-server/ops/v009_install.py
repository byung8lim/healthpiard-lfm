"""Healthpiard V009 clean-install coordinator. Python 3.11 stdlib only.

Run through install.sh as root. Never delete an existing database automatically.
ROOT_PASSWORD is used only in mysql subprocess environment; never printed.
"""
import os, sys, json, pwd, grp, secrets, subprocess, time, signal, shutil, stat, urllib.request
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit, quote, unquote

ROOT = Path(__file__).resolve().parents[1]
ENV_FILE=Path(os.getenv('HEALTHPIARD_ENV_FILE','/etc/healthpiard/lfm.env'))
REPORT=ROOT/'v009-install-report.json'
TEST_BASE=Path('/var/lib/healthpiard/v009-e2e-isolated')
DB_TEST_SUFFIX='_v009_test'
TEST_PORT=18081
RUN_USER='healthpiard'

def log(message):print(message,flush=True)
def run(args, *, env=None, input=None, cwd=ROOT, check=True, stdout=None):
    return subprocess.run(args, cwd=cwd, env=env, input=input, text=True, check=check, stdout=stdout)

def mysql(sql, *, root_pass, database=None, capture=False):
    env=os.environ.copy();env['MYSQL_PWD']=root_pass
    args=['mysql','--protocol=socket','-u','root','--batch','--skip-column-names']
    if database:args.append(database)
    p=subprocess.run(args,input=sql,env=env,text=True,capture_output=True)
    if p.returncode:
        raise RuntimeError('MySQL root action failed: '+p.stderr.strip())
    return p.stdout.strip() if capture else None

def mysql_ident(name):
    if not name or not all(ch.isascii() and (ch.isalnum() or ch=='_') for ch in name):
        raise ValueError('Unsafe MySQL schema/account name')
    return '`'+name+'`'

def sql_literal(s):
    # mysql client SQL literals: strict no escape sequences for injected values.
    if any(ch in s for ch in "'\\\x00\n\r"):
        raise ValueError('Unsupported SQL identity/secret character: use URL-safe password')
    return "'"+s+"'"

def create_or_read_env():
    if ENV_FILE.exists():
        raw=ENV_FILE.read_text()
        values={}
        for line in raw.splitlines():
            line=line.strip()
            if not line or line.startswith('#') or '=' not in line:continue
            k,v=line.split('=',1)
            values[k.strip()]=v.strip().strip('"').strip("'")
        if not values.get('DATABASE_URL') or not values.get('ADMIN_TOKEN'):
            raise RuntimeError(f'Existing {ENV_FILE} lacks DATABASE_URL/ADMIN_TOKEN; fix before installing')
        log(f'CONFIG | existing {ENV_FILE} reused (secrets hidden)')
        return values
    db_user=os.getenv('DB_USER','healthpiard_lfm')
    db_password=os.getenv('DB_PASSWORD') or secrets.token_urlsafe(24)
    if not db_user.isidentifier() or not db_user.isascii():raise RuntimeError('Invalid DB_USER')
    values={
      'DATABASE_URL': f'mysql+pymysql://{quote(db_user,safe="")}:{quote(db_password,safe="")}@127.0.0.1:3306/healthpiard?charset=utf8mb4',
      'ADMIN_TOKEN': secrets.token_urlsafe(36),
      'OBJECT_ROOT':'/var/lib/healthpiard/food-images',
      'ARTIFACT_ROOT':'/var/lib/healthpiard/release-artifacts',
      'TRAIN_ROOT':'/var/lib/healthpiard/training-runs',
      'TENSOR_CACHE_ROOT':'/var/lib/healthpiard/tensor-cache',
      'WORKER_LOG_DIR':'/var/lib/healthpiard/worker-logs',
      'API_URL':'http://127.0.0.1:8080'
    }
    ENV_FILE.parent.mkdir(parents=True,exist_ok=True)
    fd=os.open(str(ENV_FILE),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    with os.fdopen(fd,'w') as f:
        for k,v in values.items():f.write(f'{k}={v}\n')
    log(f'CONFIG | new credentials saved to {ENV_FILE} (mode 0600)')
    return values

def make_test_env(base, root=str(TEST_BASE)):
    env=dict(base)
    u=urlsplit(env['DATABASE_URL'])
    schema=unquote(u.path.lstrip('/'))
    assert schema and not schema.endswith(DB_TEST_SUFFIX)
    env['DATABASE_URL']=urlunsplit((u.scheme,u.netloc,'/'+schema+DB_TEST_SUFFIX,u.query,u.fragment))
    for k,d in [('OBJECT_ROOT','images'),('ARTIFACT_ROOT','artifacts'),('TRAIN_ROOT','training-runs'),('TENSOR_CACHE_ROOT','tensor-cache'),('WORKER_LOG_DIR','worker-logs')]:
        env[k]=str(Path(root)/d)
    env['API_URL']='http://127.0.0.1:'+str(TEST_PORT)
    env['V009_TEST_MODE']='YES'
    env['V009_E2E_TIMEOUT']=os.getenv('V009_E2E_TIMEOUT','1800')
    return env

def account_and_schema(base,root_pass):
    u=urlsplit(base['DATABASE_URL']);name=unquote(u.path.lstrip('/'))
    if name.endswith(DB_TEST_SUFFIX) or not name.startswith('healthpiard'):
        raise RuntimeError('V009 installer expects a dedicated healthpiard production schema')
    db_user=unquote(u.username or ''); password=unquote(u.password or '')
    if not db_user or not password:raise RuntimeError('Database URL must have username and password')
    # Resume is allowed when both schemas match the expected V009 structure.
    # A partial / foreign schema is rejected; never DROP or overwrite user data.
    existing_schema_states={}
    for schema in (name,name+DB_TEST_SUFFIX):
        tables=mysql(f"SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA={sql_literal(schema)} AND TABLE_TYPE='BASE TABLE';",root_pass=root_pass,capture=True)
        triggers=mysql(f"SELECT COUNT(*) FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA={sql_literal(schema)};",root_pass=root_pass,capture=True)
        if tables=='0' and triggers=='0':existing_schema_states[schema]='EMPTY'
        else:
            required_tables=['food_class','image_object','ingestion_request','dataset_snapshot','dataset_snapshot_item','training_job','model_release','release_channel']
            required_triggers=['trg_snapshot_no_update','trg_snapshot_no_delete','trg_snapshot_item_insert_guard','trg_snapshot_item_no_update','trg_snapshot_item_no_delete']
            t=mysql(f"SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA={sql_literal(schema)};",root_pass=root_pass,capture=True).splitlines()
            tr=mysql(f"SELECT TRIGGER_NAME FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA={sql_literal(schema)};",root_pass=root_pass,capture=True).splitlines()
            if set(required_tables)<=set(t) and set(required_triggers)<=set(tr):
                status=mysql(f"SELECT COUNT(*) FROM {mysql_ident(schema)}.dataset_snapshot WHERE status <> 'COMPLETED';",root_pass=root_pass,capture=True)
                if status!='0':raise RuntimeError(f'Incomplete snapshots in {schema}: refusing unsafe resume')
                existing_schema_states[schema]='READY'
                log(f'RESUME | validated existing V009 schema {schema}: tables={len(t)}, triggers={len(tr)}')
            else:
                raise RuntimeError(f'REFUSED: unrecognized/partial schema {schema}; no automatic deletion')
    existing=mysql(f"SELECT COUNT(*) FROM mysql.user WHERE User={sql_literal(db_user)} AND Host='%';",root_pass=root_pass,capture=True)
    if existing=='0':
        mysql(f"CREATE USER {sql_literal(db_user)}@'%' IDENTIFIED BY {sql_literal(password)};",root_pass=root_pass)
        log('MYSQL | dedicated app user created')
    else:log('MYSQL | existing app user reused (password not changed)')
    for schema in (name,name+DB_TEST_SUFFIX):
        mysql(f'CREATE DATABASE IF NOT EXISTS {mysql_ident(schema)} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;',root_pass=root_pass)
        mysql(f"GRANT ALL PRIVILEGES ON {mysql_ident(schema)}.* TO {sql_literal(db_user)}@'%';",root_pass=root_pass)
    return name, existing_schema_states

def ensure_user():
    try:user=pwd.getpwnam(RUN_USER)
    except KeyError:
        run(['useradd','--system','--home-dir','/var/lib/healthpiard','--shell','/sbin/nologin',RUN_USER])
        user=pwd.getpwnam(RUN_USER)
    # Directories only: avoid recursively taking ownership of potential preexisting operational data.
    return user

def ensure_paths(env,user):
    for key in ('OBJECT_ROOT','ARTIFACT_ROOT','TRAIN_ROOT','TENSOR_CACHE_ROOT','WORKER_LOG_DIR'):
        p=Path(env[key]);p.mkdir(parents=True,exist_ok=True)
        os.chown(p,user.pw_uid,user.pw_gid)

def install_deps():
    for name,req in [('api','requirements.txt'),('worker','requirements-training.txt')]:
        venv=ROOT/f'.venv-{name}'
        if not (venv/'bin/python').exists():run(['python3.11','-m','venv',str(venv)])
        run([str(venv/'bin/python'),'-m','pip','install','-r',req]+(['pytest'] if name=='api' else []))

def drop_privileges(user):
    def inner():
        os.setgroups([])
        os.setgid(user.pw_gid)
        os.setuid(user.pw_uid)
    return inner

def proc_start(args,env,user,logfile):
    f=open(logfile,'w')
    p=subprocess.Popen(args,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,
                       start_new_session=True,preexec_fn=drop_privileges(user))
    f.close()
    return p

def stop_group(p):
    if p.poll() is not None:return
    try:os.killpg(p.pid,signal.SIGTERM)
    except ProcessLookupError:return
    try:p.wait(timeout=12)
    except subprocess.TimeoutExpired:
        try:os.killpg(p.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        p.wait()

def wait_http(process,url, log_file):
    for i in range(45):
        if process.poll() is not None:break
        try:
            with urllib.request.urlopen(url+'/openapi.json',timeout=2) as r:
                if r.status==200:return
        except Exception:pass
        time.sleep(1)
    raise RuntimeError(f'Test API failed; inspect {log_file}')

def verify_e2e(base,user):
    test_env=make_test_env(base)
    ensure_paths(test_env,user)
    # All paths must be disjoint from operating paths.
    for k in ('OBJECT_ROOT','ARTIFACT_ROOT','TRAIN_ROOT','TENSOR_CACHE_ROOT','WORKER_LOG_DIR'):
        a=Path(base[k]).resolve();b=Path(test_env[k]).resolve()
        if a==b or a in b.parents or b in a.parents:raise RuntimeError(f'Shared path detected: {k}')
    u1=urlsplit(base['DATABASE_URL']);u2=urlsplit(test_env['DATABASE_URL'])
    assert u1.path!=u2.path
    os_env=os.environ.copy();os_env.update(test_env)
    log('VERIFY | static tests and isolated database check')
    run([str(ROOT/'.venv-api/bin/python'),'-m','pytest','-q','tests','ops/test_v009_isolation.py'],env=os_env)
    # Never attach to an unrelated listener on the test port.
    import socket
    with socket.socket() as sock:
        sock.settimeout(0.5)
        if sock.connect_ex(('127.0.0.1',TEST_PORT))==0:
            raise RuntimeError(f'Test port {TEST_PORT} already in use; refusing to verify against an unrelated API')
    # process-specific output and process groups ensure cleanup even on error
    api_log=ROOT/'v009-test-api.log';worker_log=ROOT/'v009-test-worker.log'
    api=None;worker=None
    try:
        api=proc_start([str(ROOT/'.venv-api/bin/python'),'-m','uvicorn','app.main:app','--host','127.0.0.1','--port',str(TEST_PORT)],os_env,user,api_log)
        wait_http(api,'http://127.0.0.1:'+str(TEST_PORT),api_log)
        worker=proc_start([str(ROOT/'.venv-worker/bin/python'),'-m','app.worker'],os_env,user,worker_log)
        time.sleep(2)
        if worker.poll() is not None:raise RuntimeError(f'Test Worker crashed; inspect {worker_log}')
        run([str(ROOT/'.venv-api/bin/python'),'ops/v009_check.py'],env=os_env)
        run([str(ROOT/'.venv-api/bin/python'),'ops/e2e_v009.py'],env=os_env)
        run([str(ROOT/'.venv-api/bin/python'),'ops/v009_check.py'],env=os_env)
    finally:
        if worker:stop_group(worker)
        if api:stop_group(api)

def make_unit(service, venv, command, desc):
    return f'''[Unit]\nDescription=Healthpiard LFM V009 {desc}\nAfter=network-online.target mysqld.service\nWants=network-online.target\n[Service]\nType=simple\nUser={RUN_USER}\nGroup={RUN_USER}\nWorkingDirectory={ROOT}\nEnvironmentFile={ENV_FILE}\nExecStart={ROOT}/.venv-{venv}/bin/python {command}\nRestart=on-failure\nRestartSec=5\nNoNewPrivileges=true\n[Install]\nWantedBy=multi-user.target\n'''

def activate(base,user):
    # Earlier units may remain after a failed clean-install attempt.
    # main() verifies neither service is active. Back them up, then atomically replace.
    for service in ('healthpiard-lfm-api','healthpiard-lfm-worker'):
        unit=Path(f'/etc/systemd/system/{service}.service')
        if unit.exists() and str(ROOT) not in unit.read_text():
            backup=unit.with_suffix(unit.suffix+'.pre-v0092.bak')
            if not backup.exists():shutil.copy2(unit,backup)
            log('SERVICE | backed up stopped legacy unit to '+str(backup))
    files={
       'healthpiard-lfm-api':make_unit('api','api','-m uvicorn app.main:app --host 0.0.0.0 --port 8080','API'),
       'healthpiard-lfm-worker':make_unit('worker','worker','-m app.worker','CPU Worker')
    }
    for service,content in files.items():
        Path(f'/etc/systemd/system/{service}.service').write_text(content)
    run(['systemctl','daemon-reload'])
    run(['systemctl','enable','--now','healthpiard-lfm-api','healthpiard-lfm-worker'])
    time.sleep(3)
    for service in files:
        p=run(['systemctl','is-active',service],check=False,stdout=subprocess.PIPE)
        if p.returncode:raise RuntimeError('Production service inactive: '+service)
    log('PASS | production API and worker started via systemd')

def main():
    if os.geteuid()!=0:raise RuntimeError('Run sudo -E ./install.sh as root')
    root_password=os.getenv('ROOT_PASSWORD')
    if root_password is None:raise RuntimeError('ROOT_PASSWORD environment variable required (may be empty)')
    if shutil.which('mysql') is None:raise RuntimeError('mysql CLI required')
    if shutil.which('python3.11') is None:raise RuntimeError('python3.11 required')
    # Fail before costly installation if production ports occupied by legacy stack.
    for service in ('healthpiard-lfm-api','healthpiard-lfm-worker'):
        p=subprocess.run(['systemctl','is-active','--quiet',service])
        if p.returncode==0:raise RuntimeError(f'REFUSED: stop legacy {service} before V009 clean install')
    report={'version':'V009.2','result':'FAIL','stages':[]}
    old_setting=None
    try:
        base=create_or_read_env()
        for k,v in list(os.environ.items()):
            if k in base and v:base[k]=v
        for key,default in [('TRAIN_ROOT','/var/lib/healthpiard/training-runs'),('TENSOR_CACHE_ROOT','/var/lib/healthpiard/tensor-cache'),('WORKER_LOG_DIR','/var/lib/healthpiard/worker-logs')]:
            base.setdefault(key,default)
        schema,schema_states=account_and_schema(base,root_password)
        report['stages'].append('MYSQL_SETUP')
        user=ensure_user()
        ensure_paths(base,user)
        install_deps()
        report['stages'].append('PYTHON_DEPENDENCIES')
        old_setting=mysql('SELECT @@GLOBAL.log_bin_trust_function_creators;',root_pass=root_password,capture=True)
        if old_setting not in ('0','1'):raise RuntimeError('Cannot determine MySQL trigger setting')
        if old_setting=='0':mysql('SET GLOBAL log_bin_trust_function_creators=1;',root_pass=root_password)
        try:
            for env in (base,make_test_env(base)):
                target=unquote(urlsplit(env['DATABASE_URL']).path.lstrip('/'))
                if schema_states[target]=='READY':
                    log('RESUME | schema already valid: '+target)
                    continue
                p_env=os.environ.copy();p_env.update(env)
                run([str(ROOT/'.venv-api/bin/python'),'ops/bootstrap_schema.py'],env=p_env)
        finally:
            if old_setting=='0':mysql('SET GLOBAL log_bin_trust_function_creators=0;',root_pass=root_password)
        report['stages'].append('BOTH_DB_SCHEMAS')
        log('PASS | clean production + isolated test schemas')
        verify_e2e(base,user)
        report['stages'].append('AUTOMATED_FULL_E2E')
        activate(base,user)
        report['stages'].append('PRODUCTION_SERVICES')
        report['result']='PASS'
        log('RESULT: ALL PASS | V009.2 installed and full E2E verified')
    except Exception as e:
        report['error']=str(e)
        log('RESULT: FAIL | '+str(e))
        log('STOP | no automatic database deletion; inspect and repair before retry')
        raise
    finally:
        REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2))
        log(f'REPORT: {REPORT}')

if __name__=='__main__':main()
