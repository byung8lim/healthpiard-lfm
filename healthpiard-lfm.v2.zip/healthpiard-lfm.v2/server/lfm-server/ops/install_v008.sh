#!/usr/bin/env bash
# Install into an EMPTY, dedicated database. Never drops existing data.
set -Eeuo pipefail
cd "$(dirname "$0")/.."
: "${DATABASE_URL:?Set DATABASE_URL with an empty V008 database in an environment file}"
: "${ADMIN_TOKEN:?Set ADMIN_TOKEN}"
: "${OBJECT_ROOT:?Set OBJECT_ROOT}"
: "${ARTIFACT_ROOT:?Set ARTIFACT_ROOT}"
command -v mysql >/dev/null || { echo 'mysql CLI required' >&2; exit 2; }
command -v python3.11 >/dev/null || { echo 'python3.11 required' >&2; exit 2; }
# Safely parse DATABASE_URL and ensure we are not pointing to system / default schema.
python3.11 - <<'PY'
import os
from urllib.parse import urlsplit,unquote
u=urlsplit(os.environ['DATABASE_URL'])
db=unquote(u.path.lstrip('/'))
if not u.scheme.startswith('mysql+') or not db or db in ('mysql','sys','information_schema','performance_schema'):
    raise SystemExit('INVALID DATABASE_URL: dedicated MySQL schema required')
print('Target schema:',db)
PY
read -r -p "Type INSTALL-V008 to initialize the EMPTY schema: " answer
[[ "$answer" == INSTALL-V008 ]] || { echo 'Cancelled'; exit 2; }
python3.11 -m venv .venv-api
.venv-api/bin/pip install -r requirements.txt pytest
.venv-api/bin/python ops/bootstrap_schema.py
python3.11 -m venv .venv-worker
.venv-worker/bin/pip install -r requirements-training.txt
mkdir -p "$OBJECT_ROOT" "$ARTIFACT_ROOT"
echo 'V008 schema/dependencies installed. Configure/start API + Worker service with ops/healthpiard-lfm-*.service.'
echo 'Run ops/verify_v008.sh for automatic checks.'
