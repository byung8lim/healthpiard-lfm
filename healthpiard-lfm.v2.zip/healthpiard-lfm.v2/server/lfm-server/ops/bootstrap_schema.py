"""Install bundled mysql CLI schema; refuse any nonempty target schema."""
import os,subprocess,sys
from pathlib import Path
from urllib.parse import urlsplit,unquote
from sqlalchemy import create_engine,text
url=os.environ['DATABASE_URL'];engine=create_engine(url)
with engine.connect() as c:
    t=c.execute(text("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()" )).scalar_one()
    if t:sys.exit(f'REFUSED: database has {t} tables. Fresh V009 install requires an EMPTY schema.')
u=urlsplit(url)
if not u.hostname:sys.exit('Host required in DATABASE_URL')
# no credentials on process command line: MYSQL_PWD is inherited as env
args=['mysql','--default-character-set=utf8mb4','--binary-mode',f'--host={u.hostname}',f'--port={u.port or 3306}',f'--user={unquote(u.username or "")}',unquote(u.path.lstrip('/'))]
env=os.environ.copy();env['MYSQL_PWD']=unquote(u.password or '')
with Path('db/schema.mysql8.sql').open('rb') as f:
    r=subprocess.run(args,stdin=f,env=env)
if r.returncode:sys.exit(r.returncode)
print('SCHEMA CREATED: V009 fresh install')
