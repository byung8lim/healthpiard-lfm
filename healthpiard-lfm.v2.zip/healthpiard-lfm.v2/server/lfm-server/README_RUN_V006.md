# Healthpiard LFM 1~5 통합 실행 후보 V006

## 구현 포함
1. MySQL 8 신규 설치용 단일 `db/schema.mysql8.sql` (V001~V003를 하나의 파일에 포함). **기존 DB에는 실행 금지**. 이미 생성된 테이블에는 기존 순차 마이그레이션 비교가 필요.
2. Feeder `POST /api/v1/feedFoodModel`, image SHA-256, 요청 멱등성, 클래스/영양 버전/품질 기록.
3. 승인 이미지만 Snapshot으로 고정; class-aware split, manifest hash 및 불변 트리거.
4. 관리자가 요청한 Job만 MySQL lease/fencing worker가 처리, CPU MobileNetV3Large 학습 및 checkpoint 복구.
5. 전체 TEST 이미지 TFLite 정확도 >=90% **및** Keras/TFLite 일치 검증을 통과한 모델만 릴리스 후보; 승인 및 stable 활성화 후 파일 다운로드.

## Rocky Linux 테스트 배포 (신규 테스트 DB만)
- Python 3.11 권장. `python3.11 -m venv .venv && source .venv/bin/activate`
- `pip install -r requirements-training.txt` (CPU TensorFlow 설치는 플랫폼 호환성 확인)
- MySQL 8에서 새 빈 스키마 `healthpiard` 생성 후 `mysql -u ... -p healthpiard < db/schema.mysql8.sql` **한 번만** 실행.
- `.env.example` 참고해 DATABASE_URL, OBJECT_ROOT, ARTIFACT_ROOT, TRAIN_ROOT, ADMIN_TOKEN 지정. `.env`는 자동 로드되지 않으므로 환경 변수로 export.
- `uvicorn app.main:app --host 0.0.0.0 --port 8080`
- 별도 터미널에서 `python -m app.worker`
- `curl -s http://127.0.0.1:8080/openapi.json`
- 운영자: 이미지 검수 PASS -> Snapshot 생성 -> Job 요청 -> Worker 실행 -> /admin/releases/candidates -> /admin/releases/{id}/review -> /admin/releases/activate -> /releases/latest. Admin 요청에 Authorization: Bearer $ADMIN_TOKEN.

## 중요한 한계 / 배포 게이트
- GitHub 실제 리포지터리 코드 및 Feeder 기존 계약은 확인되지 않았고 GitHub push도 하지 않았습니다.
- 통합 테스트용 MySQL 8, TensorFlow 실제 학습, 모바일 기기 테스트는 **미수행**; 운영 배포 가능 판정이 아닙니다.
- pretrained weights 가 없으면 초기 모델은 random initialization: 90% 정확도 달성이 보장되지 않습니다.
- 50/100/150 threshold는 알림 수준이지 자동 학습 트리거가 아닙니다.
- 파일 저장/DB 커밋 사이 강제종료 고아 객체는 `python -m ops.reconcile_objects` (검토 목록만 출력)로 식별합니다.
- Worker가 실패한 작업을 retry하려면 /admin/training-jobs/{id}/retry를 호출해야 합니다.
- 품질 90%는 테스트 집합의 top-1 정확도를 의미하며, 데이터 양과 품질에 따라 달성 불가할 수 있습니다.
- Admin 기능은 API 중심이며 HTML 시안은 정식 React Admin Web이 아닙니다(6단계 범위 밖).
