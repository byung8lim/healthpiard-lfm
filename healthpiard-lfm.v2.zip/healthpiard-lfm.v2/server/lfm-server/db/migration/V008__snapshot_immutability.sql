-- V008 UPGRADE FROM V007 ONLY. Execute with mysql CLI (DELIMITER syntax).
-- Backup before applying. Do not run against a fresh V008 installation.
ALTER TABLE dataset_snapshot ADD COLUMN status ENUM('CREATING','COMPLETED') NOT NULL DEFAULT 'COMPLETED';
DROP TRIGGER IF EXISTS trg_snapshot_no_update;
DELIMITER $$
CREATE TRIGGER trg_snapshot_no_update BEFORE UPDATE ON dataset_snapshot FOR EACH ROW
BEGIN
 IF NOT (OLD.status='CREATING' AND NEW.status='COMPLETED'
    AND NEW.id <=> OLD.id AND NEW.name <=> OLD.name
    AND NEW.split_seed <=> OLD.split_seed
    AND NEW.manifest_sha256 <=> OLD.manifest_sha256
    AND NEW.manifest_json <=> OLD.manifest_json
    AND NEW.image_count <=> OLD.image_count
    AND NEW.train_count <=> OLD.train_count
    AND NEW.validation_count <=> OLD.validation_count
    AND NEW.test_count <=> OLD.test_count
    AND NEW.created_by <=> OLD.created_by
    AND NEW.created_at <=> OLD.created_at) THEN
   SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Immutable dataset snapshot';
 END IF;
END$$
CREATE TRIGGER trg_snapshot_item_insert_guard BEFORE INSERT ON dataset_snapshot_item FOR EACH ROW
BEGIN
 DECLARE current_status VARCHAR(16);
 SELECT status INTO current_status FROM dataset_snapshot WHERE id=NEW.snapshot_id;
 IF current_status IS NULL OR current_status <> 'CREATING' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Snapshot item INSERT requires CREATING snapshot';
 END IF;
END$$
DELIMITER ;
