-- MySQL 8.0+ / additive migration only. Run with a migration tool, once.
CREATE TABLE food_class (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 class_code VARCHAR(100) NOT NULL,
 food_name VARCHAR(255) NOT NULL,
 status ENUM('DRAFT','ACTIVE','ARCHIVED') NOT NULL DEFAULT 'DRAFT',
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
 UNIQUE KEY uk_food_class_code (class_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE nutrition (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 food_class_id BIGINT UNSIGNED NOT NULL,
 serving_g DECIMAL(10,2) NOT NULL,
 calories_kcal DECIMAL(12,3) NULL,
 carbohydrates_g DECIMAL(12,3) NULL,
 protein_g DECIMAL(12,3) NULL,
 fat_g DECIMAL(12,3) NULL,
 source_name VARCHAR(255) NULL,
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 CONSTRAINT fk_nutrition_class FOREIGN KEY (food_class_id) REFERENCES food_class(id),
 CONSTRAINT ck_nutrition_serving CHECK (serving_g > 0),
 CONSTRAINT ck_nutrition_calories CHECK (calories_kcal IS NULL OR calories_kcal >= 0),
 INDEX ix_nutrition_class (food_class_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE image_object (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 sha256 BINARY(32) NOT NULL,
 storage_key VARCHAR(700) NOT NULL,
 mime_type VARCHAR(100) NOT NULL,
 width_px INT UNSIGNED NOT NULL,
 height_px INT UNSIGNED NOT NULL,
 byte_size BIGINT UNSIGNED NOT NULL,
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 UNIQUE KEY uk_image_sha256 (sha256),
 UNIQUE KEY uk_image_storage (storage_key),
 CONSTRAINT ck_image_dimensions CHECK (width_px > 0 AND height_px > 0 AND byte_size > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE class_assignment (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 image_id BIGINT UNSIGNED NOT NULL,
 food_class_id BIGINT UNSIGNED NOT NULL,
 assignment_source ENUM('FEEDER','ADMIN','MODEL') NOT NULL DEFAULT 'FEEDER',
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 UNIQUE KEY uk_assignment_pair (image_id, food_class_id),
 KEY ix_assignment_class (food_class_id),
 CONSTRAINT fk_assignment_image FOREIGN KEY (image_id) REFERENCES image_object(id),
 CONSTRAINT fk_assignment_class FOREIGN KEY (food_class_id) REFERENCES food_class(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE image_quality (
 image_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
 status ENUM('PENDING','PASS','REJECT') NOT NULL DEFAULT 'PENDING',
 score DECIMAL(6,5) NULL,
 reason_code VARCHAR(100) NULL,
 checked_at DATETIME(6) NULL,
 CONSTRAINT fk_quality_image FOREIGN KEY (image_id) REFERENCES image_object(id),
 CONSTRAINT ck_quality_score CHECK (score IS NULL OR (score >= 0 AND score <= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dedicated durable idempotency ledger: request identity is scoped to a client.
CREATE TABLE ingestion_request (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 client_id VARCHAR(128) NOT NULL,
 client_request_id VARCHAR(128) NOT NULL,
 request_sha256 BINARY(32) NOT NULL,
 status ENUM('PROCESSING','COMPLETED','FAILED') NOT NULL DEFAULT 'PROCESSING',
 image_id BIGINT UNSIGNED NULL,
 response_json JSON NULL,
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
 UNIQUE KEY uk_client_request (client_id, client_request_id),
 KEY ix_ingestion_status_updated (status, updated_at),
 CONSTRAINT fk_request_image FOREIGN KEY (image_id) REFERENCES image_object(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
