-- Run after V001. Only touches new Healthpiard tables.
ALTER TABLE nutrition
  ADD COLUMN version_no INT UNSIGNED NOT NULL DEFAULT 1,
  ADD COLUMN request_id BIGINT UNSIGNED NULL,
  ADD CONSTRAINT fk_nutrition_ingestion FOREIGN KEY (request_id) REFERENCES ingestion_request(id),
  ADD UNIQUE KEY uk_nutrition_class_version (food_class_id, version_no),
  ADD CONSTRAINT ck_nutrition_version CHECK (version_no >= 1);
-- Serialize creation of each class's next nutrition version by locking food_class row.
