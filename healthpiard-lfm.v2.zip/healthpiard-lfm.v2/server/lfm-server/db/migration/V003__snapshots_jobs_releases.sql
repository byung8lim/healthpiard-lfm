-- ADDITIVE migration; never delete/alter operational tables.
CREATE TABLE dataset_snapshot (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(160) NOT NULL, split_seed BIGINT NOT NULL,
 manifest_sha256 BINARY(32) NOT NULL, manifest_json JSON NOT NULL,
 image_count INT UNSIGNED NOT NULL, train_count INT UNSIGNED NOT NULL,
 validation_count INT UNSIGNED NOT NULL, test_count INT UNSIGNED NOT NULL,
 created_by VARCHAR(128) NOT NULL, created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 UNIQUE KEY uk_snapshot_manifest (manifest_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
CREATE TABLE dataset_snapshot_item (
 snapshot_id BIGINT UNSIGNED NOT NULL, image_id BIGINT UNSIGNED NOT NULL,
 food_class_id BIGINT UNSIGNED NOT NULL,
 split ENUM('TRAIN','VALIDATION','TEST') NOT NULL,
 sha256 BINARY(32) NOT NULL, storage_key VARCHAR(700) NOT NULL,
 PRIMARY KEY(snapshot_id,image_id), KEY ix_snapshot_split(snapshot_id,split),
 CONSTRAINT fk_dsi_snapshot FOREIGN KEY(snapshot_id) REFERENCES dataset_snapshot(id),
 CONSTRAINT fk_dsi_image FOREIGN KEY(image_id) REFERENCES image_object(id),
 CONSTRAINT fk_dsi_class FOREIGN KEY(food_class_id) REFERENCES food_class(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
-- Snapshot header/items immutable at DB level, not only via API.
DELIMITER $$
CREATE TRIGGER trg_snapshot_no_update BEFORE UPDATE ON dataset_snapshot FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Immutable dataset snapshot'; END$$
CREATE TRIGGER trg_snapshot_no_delete BEFORE DELETE ON dataset_snapshot FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Immutable dataset snapshot'; END$$
CREATE TRIGGER trg_snapshot_item_no_update BEFORE UPDATE ON dataset_snapshot_item FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Immutable snapshot item'; END$$
CREATE TRIGGER trg_snapshot_item_no_delete BEFORE DELETE ON dataset_snapshot_item FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Immutable snapshot item'; END$$
DELIMITER ;
CREATE TABLE training_job (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 snapshot_id BIGINT UNSIGNED NOT NULL,
 model_family VARCHAR(64) NOT NULL DEFAULT 'mobilenet_v3_large',
 base_release_id BIGINT UNSIGNED NULL,
 config_json JSON NOT NULL,
 status ENUM('QUEUED','RUNNING','SUCCEEDED','FAILED','CANCELLED') NOT NULL DEFAULT 'QUEUED',
 requested_by VARCHAR(128) NOT NULL,
 lease_owner VARCHAR(128) NULL, lease_until DATETIME(6) NULL,
 heartbeat_at DATETIME(6) NULL, fencing_token BIGINT UNSIGNED NOT NULL DEFAULT 0,
 attempt INT UNSIGNED NOT NULL DEFAULT 0, max_attempts INT UNSIGNED NOT NULL DEFAULT 3,
 cancel_requested BOOLEAN NOT NULL DEFAULT FALSE,
 checkpoint_key VARCHAR(700) NULL, result_json JSON NULL, error_message TEXT NULL,
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
 CONSTRAINT fk_job_snapshot FOREIGN KEY(snapshot_id) REFERENCES dataset_snapshot(id),
 INDEX ix_job_claim(status,lease_until,id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
CREATE TABLE model_release (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL, version_tag VARCHAR(100) NOT NULL,
 status ENUM('CANDIDATE','APPROVED','REJECTED') NOT NULL DEFAULT 'CANDIDATE',
 manifest_sha256 BINARY(32) NOT NULL, manifest_json JSON NOT NULL,
 validation_json JSON NOT NULL, approved_by VARCHAR(128) NULL,
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 UNIQUE KEY uk_release_tag(version_tag),
 CONSTRAINT fk_release_job FOREIGN KEY(job_id) REFERENCES training_job(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
CREATE TABLE release_channel (
 channel_name VARCHAR(60) NOT NULL PRIMARY KEY,
 active_release_id BIGINT UNSIGNED NULL, revision BIGINT UNSIGNED NOT NULL DEFAULT 0,
 updated_by VARCHAR(128) NULL, updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 CONSTRAINT fk_channel_release FOREIGN KEY(active_release_id) REFERENCES model_release(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO release_channel(channel_name) VALUES ('stable');
CREATE TABLE release_activation_event (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, channel_name VARCHAR(60) NOT NULL,
 from_release_id BIGINT UNSIGNED NULL, to_release_id BIGINT UNSIGNED NOT NULL,
 actor VARCHAR(128) NOT NULL, created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 CONSTRAINT fk_event_channel FOREIGN KEY(channel_name) REFERENCES release_channel(channel_name),
 CONSTRAINT fk_event_release FOREIGN KEY(to_release_id) REFERENCES model_release(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
