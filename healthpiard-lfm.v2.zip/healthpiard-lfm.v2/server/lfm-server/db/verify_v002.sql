SELECT VERSION() AS mysql_version;
SELECT TABLE_NAME FROM information_schema.TABLES
 WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME IN ('food_class','nutrition','image_object','class_assignment','image_quality','ingestion_request');
SELECT COLUMN_NAME,COLUMN_TYPE FROM information_schema.COLUMNS
 WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='nutrition' AND COLUMN_NAME IN ('version_no','request_id');
SELECT TABLE_NAME, INDEX_NAME, NON_UNIQUE FROM information_schema.STATISTICS
 WHERE TABLE_SCHEMA=DATABASE() AND INDEX_NAME IN ('uk_client_request','uk_image_sha256','uk_nutrition_class_version');
