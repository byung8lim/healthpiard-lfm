-- NEW DATABASE INSTALL ONLY; MySQL 8.0.16+. Do not run on an existing database.
-- All statements are in one file; no DROP statements.

-- SOURCE V001__create_food_core.sql
-- MySQL 8.0+ / additive migration only. Run with a migration tool, once.
CREATE TABLE food_class (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 class_code VARCHAR(100) NOT NULL,
 food_name VARCHAR(255) NOT NULL,
 status ENUM('DRAFT','ACTIVE','ARCHIVED') NOT NULL DEFAULT 'DRAFT',
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
 UNIQUE KEY uk_food_class_code (class_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE nutrition (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 food_class_id BIGINT UNSIGNED NOT NULL,
 serving_g DECIMAL(10,2) NOT NULL,
 calories_kcal DECIMAL(12,3) NULL,
 carbohydrates_g DECIMAL(12,3) NULL,
 protein_g DECIMAL(12,3) NULL,
 fat_g DECIMAL(12,3) NULL,
 source_name VARCHAR(255) NULL,
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 CONSTRAINT fk_nutrition_class FOREIGN KEY (food_class_id) REFERENCES food_class(id),
 CONSTRAINT ck_nutrition_serving CHECK (serving_g > 0),
 CONSTRAINT ck_nutrition_calories CHECK (calories_kcal IS NULL OR calories_kcal >= 0),
 INDEX ix_nutrition_class (food_class_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE image_object (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 sha256 BINARY(32) NOT NULL,
 storage_key VARCHAR(700) NOT NULL,
 mime_type VARCHAR(100) NOT NULL,
 width_px INT UNSIGNED NOT NULL,
 height_px INT UNSIGNED NOT NULL,
 byte_size BIGINT UNSIGNED NOT NULL,
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 UNIQUE KEY uk_image_sha256 (sha256),
 UNIQUE KEY uk_image_storage (storage_key),
 CONSTRAINT ck_image_dimensions CHECK (width_px > 0 AND height_px > 0 AND byte_size > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE class_assignment (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 image_id BIGINT UNSIGNED NOT NULL,
 food_class_id BIGINT UNSIGNED NOT NULL,
 assignment_source ENUM('FEEDER','ADMIN','MODEL') NOT NULL DEFAULT 'FEEDER',
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 UNIQUE KEY uk_assignment_pair (image_id, food_class_id),
 KEY ix_assignment_class (food_class_id),
 CONSTRAINT fk_assignment_image FOREIGN KEY (image_id) REFERENCES image_object(id),
 CONSTRAINT fk_assignment_class FOREIGN KEY (food_class_id) REFERENCES food_class(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE image_quality (
 image_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
 status ENUM('PENDING','PASS','REJECT') NOT NULL DEFAULT 'PENDING',
 score DECIMAL(6,5) NULL,
 reason_code VARCHAR(100) NULL,
 checked_at DATETIME(6) NULL,
 CONSTRAINT fk_quality_image FOREIGN KEY (image_id) REFERENCES image_object(id),
 CONSTRAINT ck_quality_score CHECK (score IS NULL OR (score >= 0 AND score <= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dedicated durable idempotency ledger: request identity is scoped to a client.
CREATE TABLE ingestion_request (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 client_id VARCHAR(128) NOT NULL,
 client_request_id VARCHAR(128) NOT NULL,
 request_sha256 BINARY(32) NOT NULL,
 status ENUM('PROCESSING','COMPLETED','FAILED') NOT NULL DEFAULT 'PROCESSING',
 image_id BIGINT UNSIGNED NULL,
 response_json JSON NULL,
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
 UNIQUE KEY uk_client_request (client_id, client_request_id),
 KEY ix_ingestion_status_updated (status, updated_at),
 CONSTRAINT fk_request_image FOREIGN KEY (image_id) REFERENCES image_object(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- SOURCE V002__nutrition_versions.sql
-- Run after V001. Only touches new Healthpiard tables.
ALTER TABLE nutrition
  ADD COLUMN version_no INT UNSIGNED NOT NULL DEFAULT 1,
  ADD COLUMN request_id BIGINT UNSIGNED NULL,
  ADD CONSTRAINT fk_nutrition_ingestion FOREIGN KEY (request_id) REFERENCES ingestion_request(id),
  ADD UNIQUE KEY uk_nutrition_class_version (food_class_id, version_no),
  ADD CONSTRAINT ck_nutrition_version CHECK (version_no >= 1);
-- Serialize creation of each class's next nutrition version by locking food_class row.


-- SOURCE V003__snapshots_jobs_releases.sql
-- ADDITIVE migration; never delete/alter operational tables.
CREATE TABLE dataset_snapshot (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(160) NOT NULL, split_seed BIGINT NOT NULL,
 manifest_sha256 BINARY(32) NOT NULL, manifest_json JSON NOT NULL,
 image_count INT UNSIGNED NOT NULL, train_count INT UNSIGNED NOT NULL,
 validation_count INT UNSIGNED NOT NULL, test_count INT UNSIGNED NOT NULL,
 created_by VARCHAR(128) NOT NULL,
 status ENUM('CREATING','COMPLETED') NOT NULL DEFAULT 'CREATING',
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 UNIQUE KEY uk_snapshot_manifest (manifest_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
CREATE TABLE dataset_snapshot_item (
 snapshot_id BIGINT UNSIGNED NOT NULL, image_id BIGINT UNSIGNED NOT NULL,
 food_class_id BIGINT UNSIGNED NOT NULL,
 split ENUM('TRAIN','VALIDATION','TEST') NOT NULL,
 sha256 BINARY(32) NOT NULL, storage_key VARCHAR(700) NOT NULL,
 PRIMARY KEY(snapshot_id,image_id), KEY ix_snapshot_split(snapshot_id,split),
 CONSTRAINT fk_dsi_snapshot FOREIGN KEY(snapshot_id) REFERENCES dataset_snapshot(id),
 CONSTRAINT fk_dsi_image FOREIGN KEY(image_id) REFERENCES image_object(id),
 CONSTRAINT fk_dsi_class FOREIGN KEY(food_class_id) REFERENCES food_class(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
-- Snapshot header/items immutable at DB level, not only via API.
DELIMITER $$
CREATE TRIGGER trg_snapshot_no_update BEFORE UPDATE ON dataset_snapshot FOR EACH ROW
BEGIN
 IF NOT (OLD.status='CREATING' AND NEW.status='COMPLETED'
    AND NEW.id <=> OLD.id AND NEW.name <=> OLD.name
    AND NEW.split_seed <=> OLD.split_seed
    AND NEW.manifest_sha256 <=> OLD.manifest_sha256
    AND NEW.manifest_json <=> OLD.manifest_json
    AND NEW.image_count <=> OLD.image_count
    AND NEW.train_count <=> OLD.train_count
    AND NEW.validation_count <=> OLD.validation_count
    AND NEW.test_count <=> OLD.test_count
    AND NEW.created_by <=> OLD.created_by
    AND NEW.created_at <=> OLD.created_at) THEN
   SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Immutable dataset snapshot';
 END IF;
END$$
CREATE TRIGGER trg_snapshot_no_delete BEFORE DELETE ON dataset_snapshot FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Immutable dataset snapshot'; END$$
CREATE TRIGGER trg_snapshot_item_insert_guard BEFORE INSERT ON dataset_snapshot_item FOR EACH ROW
BEGIN
 DECLARE current_status VARCHAR(16);
 SELECT status INTO current_status FROM dataset_snapshot WHERE id=NEW.snapshot_id;
 IF current_status IS NULL OR current_status <> 'CREATING' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Snapshot item INSERT requires CREATING snapshot';
 END IF;
END$$
CREATE TRIGGER trg_snapshot_item_no_update BEFORE UPDATE ON dataset_snapshot_item FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Immutable snapshot item'; END$$
CREATE TRIGGER trg_snapshot_item_no_delete BEFORE DELETE ON dataset_snapshot_item FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Immutable snapshot item'; END$$
DELIMITER ;
CREATE TABLE training_job (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 snapshot_id BIGINT UNSIGNED NOT NULL,
 model_family VARCHAR(64) NOT NULL DEFAULT 'efficientnet_lite0',
 base_release_id BIGINT UNSIGNED NULL,
 config_json JSON NOT NULL,
 status ENUM('QUEUED','RUNNING','SUCCEEDED','FAILED','CANCELLED') NOT NULL DEFAULT 'QUEUED',
 requested_by VARCHAR(128) NOT NULL,
 lease_owner VARCHAR(128) NULL, lease_until DATETIME(6) NULL,
 heartbeat_at DATETIME(6) NULL, fencing_token BIGINT UNSIGNED NOT NULL DEFAULT 0,
 attempt INT UNSIGNED NOT NULL DEFAULT 0, max_attempts INT UNSIGNED NOT NULL DEFAULT 3,
 cancel_requested BOOLEAN NOT NULL DEFAULT FALSE,
 checkpoint_key VARCHAR(700) NULL, result_json JSON NULL, error_message TEXT NULL,
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
 CONSTRAINT fk_job_snapshot FOREIGN KEY(snapshot_id) REFERENCES dataset_snapshot(id),
 INDEX ix_job_claim(status,lease_until,id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
CREATE TABLE model_release (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL, version_tag VARCHAR(100) NOT NULL,
 status ENUM('CANDIDATE','APPROVED','REJECTED') NOT NULL DEFAULT 'CANDIDATE',
 manifest_sha256 BINARY(32) NOT NULL, manifest_json JSON NOT NULL,
 validation_json JSON NOT NULL, approved_by VARCHAR(128) NULL,
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 UNIQUE KEY uk_release_tag(version_tag),
 CONSTRAINT fk_release_job FOREIGN KEY(job_id) REFERENCES training_job(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
CREATE TABLE release_channel (
 channel_name VARCHAR(60) NOT NULL PRIMARY KEY,
 active_release_id BIGINT UNSIGNED NULL, revision BIGINT UNSIGNED NOT NULL DEFAULT 0,
 updated_by VARCHAR(128) NULL, updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 CONSTRAINT fk_channel_release FOREIGN KEY(active_release_id) REFERENCES model_release(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO release_channel(channel_name) VALUES ('stable');
CREATE TABLE release_activation_event (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, channel_name VARCHAR(60) NOT NULL,
 from_release_id BIGINT UNSIGNED NULL, to_release_id BIGINT UNSIGNED NOT NULL,
 actor VARCHAR(128) NOT NULL, created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 CONSTRAINT fk_event_channel FOREIGN KEY(channel_name) REFERENCES release_channel(channel_name),
 CONSTRAINT fk_event_release FOREIGN KEY(to_release_id) REFERENCES model_release(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


