# Healthpiard LFM — Feeder API V002 (MySQL 8)

## Scope and limitations
This package implements a **FastAPI (Python)** feeder ingestion route with the path `/api/v1/feedFoodModel`, MySQL 8 additive schemas, nutritional revision numbers, file compensation, SHA-256 duplicate detection, request idempotency, and quality-approved image counts at 50/100/150. It does **not** enqueue, trigger, or invoke training. No operations were performed on a live database.

**Important:** Existing repository source and original request/response field contracts could not be read. The URL path is preserved, but multipart field and response compatibility **must be compared with the real Feeder app** before integration. The code is a standalone module, not a claimed commit to the repository.

## Deploy on an isolated MySQL 8 database
1. Backup and snapshot the current database. Compare target table names against `information_schema.tables`. Abort on collision; MySQL DDL migrations are not multi-statement atomic.
2. Apply `db/migration/V001__create_food_core.sql`, then `V002__nutrition_versions.sql`, **once each** through a properly configured migration runner (e.g., Flyway). If V001 is already applied, apply only V002. Do not reapply V001. Both files are additive to the existing application schema; V002 alters only the new `nutrition` table from V001.
3. Provision MySQL user with least privileges; set `DATABASE_URL` securely, set `OBJECT_ROOT` on an owned durable POSIX filesystem (not `/tmp`), and ensure application is deployed **on a single server with a shared local filesystem**. `flock` does not provide multi-node lock guarantees on all network filesystems.
4. `python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt`; `uvicorn app.main:app --host 0.0.0.0 --port 8080`.
5. Run `db/verify_v002.sql` in a test DB. Exercise the same-request retry / changed-body reuse / same-image reuse / forced DB rollback / concurrent requests scenarios before production rollout.

## Multipart request
`POST /api/v1/feedFoodModel` (`multipart/form-data`)

Required: `image` (JPEG/PNG/WebP), `clientId`, `clientRequestId`, `foodName`, `servingG` (> 0).
Optional: `classCode`, `caloriesKcal`, `carbohydratesG`, `proteinG`, `fatG`, `sourceName`.

```
curl -X POST http://localhost:8080/api/v1/feedFoodModel \
 -F 'image=@sample.jpg' -F 'clientId=feeder-1' -F 'clientRequestId=sample-uuid-0001' \
 -F 'foodName=김치찌개' -F 'classCode=kimchi-stew' -F 'servingG=200' \
 -F 'caloriesKcal=175' -F 'proteinG=12'
```

A successful response contains `foodClassId`, `imageId`, `imageSha256`, `nutritionVersion`, `qualityStatus: PENDING`, `trainingReadiness` and `autoTrainingTriggered: false`. Repeating identical request + client returns previously stored result with `idempotentReplay: true`; reuse with different content returns HTTP 409.

## Persistence and compensation
- Input bytes are validated, SHA-256 hashed, and written to a temporary file with `fsync`.
- A per-SHA POSIX `flock` is acquired; metadata updates occur in one MySQL transaction. The published object path is content-addressable (`sha256/aa/bb/<hash>.jpg`). File publication uses `os.replace` for atomic rename on the same filesystem.
- If the DB transaction rolls back, this call removes a freshly published object only when no committed `image_object` row references the hash. `finally` removes uncommitted staging files.
- Duplicate image hash is unique at DB level. Already-assigned image must not be silently relabeled to another food class.
- `clientId` + `clientRequestId` is a DB unique key, with canonical payload hash and saved response; concurrent claims serialize through DB's unique constraint. MySQL lock timeout/deadlock may require client retry; a failed transaction will not commit a PROCESSING row.
- Nutrition revision increments only when nutrient values or source differ from last recorded version. Locking `food_class` row serializes version creation per class.
- A new image starts as `image_quality.PENDING`. **Only quality PASS** items increment milestone count (50/100/150). This endpoint does not auto-approve photos or auto-train.

## Required production hardening / integration
- A process crash between file publication and DB commit **can** leave a content-addressed orphan. Transactional compensation catches ordinary exceptions, not SIGKILL or power outage. Add a scheduled reconciliation sweep: compare on-disk objects to committed `image_object.storage_key` rows, quarantine unreferenced objects beyond a safe grace period, and delete after verification; never delete recent in-flight writes. Integrate this with your operations procedure.
- Synchronous SQLAlchemy ingestion executes via `run_in_threadpool` to avoid blocking the FastAPI event loop. Size the worker/thread and DB connection pools together.
- There is no authentication in this standalone module: place behind existing Feeder authentication and trusted TLS reverse proxy prior to deployment.
- Set independent request body and disk quotas, restrict file permissions, and monitor filesystem/DB space.
- The code keeps originals, does not resize to 2000×1500 or JPEG-normalize, and does not yet implement the previous mobile feeder's exact schema/aliases. Confirm product requirements before replacing any existing endpoint.
- Integration MySQL tests, race/load tests and crash-injection tests have not been executed in this environment.
