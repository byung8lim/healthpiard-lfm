# V007 감리 지적 보완 및 검증 범위

## 기술 스택 정정
보고서는 PyTorch/ai-edge-torch 누락을 배포 차단 사유로 적었으나 V006 실제 트레이너는 TensorFlow/Keras이며 `tf.lite.TFLiteConverter`를 사용합니다. `ai-edge-torch`는 이 코드 경로에 불필요하므로 추가하지 않았습니다. TensorFlow CPU 전용 환경과 API 환경을 별도 venv로 설치하세요.

## 반영
- Feeder 응답 및 재전송 응답에 `trainingJobId: 0` 제공. 기존 앱 파서의 실제 계약은 확인 필요.
- `tensor_cache.py`: 스냅샷별 TRAIN/VALIDATION 데이터를 NPY mmap 파일로 사전 패킹. 각 원본은 한 차례 SHA-256 검증하고 JPEG 디코딩합니다. 재시작 시 캐시 재사용. TensorFlow Generator는 배치별 메모리 복사를 사용하므로 **엄밀히 제로 카피 아님**.
- Worker: lease 만료 + max_attempts 도달 시 FAILED와 `QUARANTINED` 사유 기록, 재획득 불가. 만료된 RUNNING 잡 재획득 전 지수 백오프. 강제 SIGKILL/137은 lease가 만료되어야 회수 가능.
- Worker 구문 호환 수정, 테스트 코드 추가.

## 주의 / 잔여 배포 차단
1. 25,000장 224px float32 텐서는 약 14 GiB 저장 공간 필요. 초기 텐서 구축·디스크 용량 확인 필요.
2. 로컬 파일시스템의 `fcntl.flock`으로 동일 키 중복 패킹을 방지합니다. 다중 서버 공유 스토리지에서는 동일한 락 의미가 제공되는지 확인이 필요합니다.
3. `updated_at` 기반 백오프는 충분한 하한은 아니며, DB 재시작·시계·lock contention에 따라 실제 재시도 간격이 달라질 수 있습니다.
4. 서비스 DB/실제 이미지/실학습/TFLite 변환을 통한 E2E 테스트 **미실시**. 따라서 프로덕션 배포 승인은 불가.
5. 기존 앱의 JSON 필드/타입/응답코드를 실물 샘플로 확인해야 하위호환성을 최종 승인할 수 있습니다.

## 실행 환경 분리
```bash
python3.11 -m venv .venv-api
.venv-api/bin/pip install -r requirements.txt
python3.11 -m venv .venv-worker
.venv-worker/bin/pip install -r requirements-training.txt
.venv-api/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8080
.venv-worker/bin/python -m app.worker
```

`schema.mysql8.sql`은 신규 DB에만 적용하세요. 기존 운영 DB 변경은 수행하지 않았습니다.
