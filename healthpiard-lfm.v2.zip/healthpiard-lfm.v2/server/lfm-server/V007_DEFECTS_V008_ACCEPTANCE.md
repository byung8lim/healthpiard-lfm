# V007 findings and V008 acceptance matrix

Evidence: October 19, 2026 on-prem Rocky 9 / MySQL 8.0.46 runtime reports (user-supplied). Runtime V007 patches are included in the V008 source ZIP; no assumption that the V007 ZIP already contained those runtime edits.

| ID | Evidence | Root cause | V008 implementation | Verification |
|---|---|---|---|---|
| D-01 | Job 1 Lease expired/fenced; post-patch Job 2 and 4 succeeded | Child trainer recomputed `OWNER` from different PID | Env propagation, lease read from env | Static tests + full E2E training |
| D-02 | Job 3 failed due to 0.50 accuracy; patched Job 4 SUCCEEDED, passed=false and .tflite exists | Quality gate raised exception in exporter | Preserve TFLite, return validation result | Regression test + full E2E |
| D-03 | Existing four snapshot triggers; no BEFORE INSERT; UPDATE returns SQLSTATE 45000 | Only UPDATE/DELETE protected | Snapshot `CREATING/COMPLETED`, header transition and item insert guard | MySQL trigger inventory, negative INSERT test after snapshot, full E2E creation |
| D-04 | V007 source package differed from manually modified live process | Manual patches not reproducible | Unified fresh schema + source + scripted setup | Fresh install on isolated empty schema (not tested here) |
| D-05 | Manual ingestion/snapshot/training/release checks spread over many user turns | No one-command acceptance suite | `verify_v008.sh` and guarded `--full` E2E | Default suite and test-only full suite |

Known unproven: actual CPU training throughput/scaling to 500 classes; OOM Kill crash recovery; model drift detection; real mobile inference; production rolling upgrade; automated rollback; concurrent Snapshot insert attempts from DB admin account.

**Release quality:** current artifact is an implementation/release candidate. Authoring environment verified Python syntax and nine isolated static tests; there was no external MySQL+systemd+TensorFlow execution, so **production-ready pass is NOT claimed**.
