# V009.1 fix: TensorFlow verifier virtualenv symlink

V009 full-E2E failed after training because `Path('.venv-worker/bin/python').resolve()` resolves the virtual environment symlink to `/usr/bin/python3.11`, bypassing installed TensorFlow. The verifier now invokes the **unresolved virtualenv path**, and a regression test prevents recurrence. This has not been re-tested on the target Rocky server.

V009.1 is a corrected clean-install candidate. Like V009, re-running `install.sh` against nonempty databases is deliberately refused. Do not delete an existing DB without separately confirming it is disposable.

# Healthpiard-LFM V009 — clean installation and isolated E2E

## Status and limitations

V009 deployment *candidate*. Local syntax and regression checks completed, but this package has **NOT** passed full Rocky Linux + MySQL + TensorFlow E2E in its author's environment. Full E2E is performed on the target server before production services start. A failure leaves services stopped and writes `v009-install-report.json`.

### Why V008 failed

The V008 test API/Worker used a disposable MySQL schema, but `TRAIN_ROOT` remained shared with old V007/V008 runs. A test training job assigned ID 1 encountered an earlier `training-runs/1/class_index.json`, causing `Checkpoint class mapping differs from immutable snapshot`. The V008 test runners did not enforce isolation of all five filesystem roots or a test-specific worker and API.

V009 additionally fixes: wrong systemd source paths, manual MySQL `log_bin_trust_function_creators` configuration, lack of end-to-end one-command provisioning, missing E2E idempotency/SHA256 and post-creation snapshot immutability probes.

## Preflight — **read before running**

- Rocky Linux 9, Python 3.11 and python3.11 venv, `mysql` CLI, MySQL 8 server, Internet access for Python packages.
- Stop and disable previous Healthpiard API and Worker services. Ensure TCP 8080 and 18081 are free.
- **This script never drops databases.** Both the main `healthpiard` schema (or schema named by `DATABASE_URL`) and `<schema>_v009_test` must have zero tables. If either is nonempty, installation refuses to proceed.
- Existing `/etc/healthpiard/lfm.env` is reused. Confirm it refers to the intended *clean* MySQL DB and existing app account/password. If it points to an obsolete DB account/password, repair or move it before installation. A new file is generated with mode 0600 if absent.
- Verify production OBJECT_ROOT, ARTIFACT_ROOT, TRAIN_ROOT, TENSOR_CACHE_ROOT, and WORKER_LOG_DIR do not overlap the generated test paths under `/var/lib/healthpiard/v009-e2e-isolated`.
- The MySQL root account must be able to authenticate locally over Unix socket with the supplied `ROOT_PASSWORD`; empty passwords are supported when local socket root access is configured.
- `ROOT_PASSWORD` is used only for setup, not stored in `/etc/healthpiard/lfm.env` or reports. Avoid shell history and publicly logged commands containing passwords.

## One-shot install and verification

Unzip and enter the `healthpiard-lfm-v009` folder; then, as root:

```bash
export ROOT_PASSWORD=''
./install.sh
```

Or with sudo preserving the environment:

```bash
export ROOT_PASSWORD=''
sudo -E ./install.sh
```

The installer creates/grants the two empty MySQL schemas, installs API/CPU Worker virtualenvs, temporarily permits MySQL trigger creation if necessary, bootstraps both schemas, runs local tests, starts a loopback-only test API on port 18081 and a **dedicated test worker**, ingests synthetic test images, checks replay/dedup/Snapshot immutability, performs one CPU training job, loads the resulting 2-class TFLite, tests release quality gate, then stops the test processes and enables production services. It writes `v009-install-report.json` with stages and PASS/FAIL.

If any step fails, **production services are not activated**. The database and logs remain for diagnosis; the installer does not silently delete or reset them. Fix the root issue and use fresh schemas for a clean retry; do not run against partially populated schemas.

## Files and logs

- `install.sh`: one-shot coordinator
- `ops/v009_install.py`: provisioning, isolation, cleanup, and report
- `ops/e2e_v009.py`: real feeder → snapshot → train → TFLite → gate
- `ops/v009_check.py`: DB / API / trigger probes
- `ops/test_v009_isolation.py`: isolation regression checks
- `v009-install-report.json`: summary output after execution
- `v009-test-api.log`, `v009-test-worker.log`: isolated process logs
- `/var/lib/healthpiard/v009-e2e-isolated`: test files and CPU training artifacts

## Security note

For convenience the local database user uses MySQL Host `%` if newly created; restrict network access via local firewall or narrow grants before production exposure. `log_bin_trust_function_creators` is returned to its prior value following schema initialization (assuming installer can execute cleanup). Test images are synthetic and must never be published to mobile users.
