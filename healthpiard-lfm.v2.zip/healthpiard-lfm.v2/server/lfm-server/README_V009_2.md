# Healthpiard-LFM V009.2 — One-command resumable installer

Run as root from unpacked project root:

```bash
ROOT_PASSWORD='YOUR_MYSQL_ROOT_PASSWORD' ./install.sh
```

For socket-auth MySQL root, use `ROOT_PASSWORD='' ./install.sh`.

On retry, a pre-existing production/test schema is **reused only** if V009 core tables and immutability triggers are present. Unknown or partial schemas fail closed (no DROP).

If a preceding isolated E2E job has already succeeded, the installer verifies its existing TFLite artifact and checks the release quality gate without retraining. This covers a previous failure during TFLite verification.

Production services are enabled only after successful E2E. Already-running legacy API/Worker units are refused; stopped legacy unit files are backed up before replacement.

Report: `v009-install-report.json`. Never pass MySQL password as a positional argument. ROOT_PASSWORD in an environment variable can be visible to privileged local processes; clear it after installation.

**Limitations:** The resume path does not recover a partially trained job; unknown/partial schemas are not repaired; the full Rocky/MySQL/systemd E2E has not been run in this artifact-building environment. Treat as a candidate until it passes on the deployment server.
