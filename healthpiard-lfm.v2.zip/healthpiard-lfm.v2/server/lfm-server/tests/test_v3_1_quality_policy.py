"""Regression: inspect executable source invariants, no database/TensorFlow needed."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]/'app'

def test_export_gate_is_runtime_enforced():
    src=(ROOT/'trainer/export.py').read_text()
    assert 'accuracy>=min_accuracy and top3_accuracy>=min_top3 and class_gate' in src
    assert "'accuracyGateEnabled':True" in src
    assert "'accuracyGateEnabled':False" not in src
    assert "temp.unlink(missing_ok=True)" in src

def test_per_class_10_image_90pct_gate():
    src=(ROOT/'trainer/export.py').read_text()
    assert "MIN_HOLDOUT_PER_CLASS','10'" in src
    assert "MIN_CLASS_HOLDOUT_ACCURACY','0.90'" in src
    assert "len(per_class)==expected_classes" in src

def test_finetune_lr_is_configurable_without_old_cap():
    src=(ROOT/'trainer/core.py').read_text()
    assert "config.get('finetuneLearningRate',1e-4)" in src
    assert "min(lr,2e-5)" not in src

def test_worker_refuses_failed_export():
    src=(ROOT/'trainer/run.py').read_text()
    assert "if not validated['passed']" in src
    assert 'HOLDOUT_QUALITY_GATE_FAILED' in src
