from app.platform import canon,sha
from app.worker import OWNER

def test_canonical_manifest():
    assert canon({'b':1,'a':2})==canon({'a':2,'b':1})
    assert sha({'a':2})==sha({'a':2})
def test_owner_identity():
    assert ':' in OWNER
