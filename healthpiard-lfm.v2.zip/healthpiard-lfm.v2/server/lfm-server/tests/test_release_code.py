from pathlib import Path

def test_bootstrap_no_destructive_statements():
    sql=(Path(__file__).resolve().parents[1]/'db/schema.mysql8.sql').read_text()
    assert 'DROP TABLE' not in sql.upper()
    for table in ('food_class','nutrition','image_object','class_assignment','image_quality',
                  'dataset_snapshot','training_job','model_release','release_channel'):
        assert f'CREATE TABLE {table}' in sql

def test_no_automatic_training_from_ingestion():
    feeder=(Path(__file__).resolve().parents[1]/'app/main.py').read_text()
    assert 'subprocess.Popen' not in feeder
    assert 'autoTrainingTriggered": False' in feeder
