from pathlib import Path
r=Path(__file__).resolve().parents[1]
def test_lease_inherited():
    w=(r/'app/worker.py').read_text()
    assert "trainer_env['HEALTHPIARD_LEASE_OWNER']=OWNER" in w and 'env=trainer_env' in w
    assert 'from app.worker import OWNER' not in (r/'app/trainer/lease.py').read_text()
def test_quality_gate_separate():
    t=(r/'app/trainer/export.py').read_text()
    assert "'passed':accuracy >= min_accuracy" in t
    assert 'if accuracy < min_accuracy:' not in t
    assert "get('passed')" in (r/'app/release_builder.py').read_text()
def test_snapshot_closed_and_guarded():
    assert "SET status='COMPLETED'" in (r/'app/platform.py').read_text()
    sql=(r/'db/schema.mysql8.sql').read_text()
    assert 'trg_snapshot_item_insert_guard' in sql
    assert "status ENUM('CREATING','COMPLETED')" in sql
