"""Standalone CPU preprocessor tests; no database or TensorFlow runtime required."""
import sys
import types
from pathlib import Path
import numpy as np

from app.trainer import tensor_cache as tc


def test_parallel_cache_and_repeat(monkeypatch, tmp_path):
    # Stub core. This tests ordered, bounded cache writing and reuse; live SHA/PIL is checked separately.
    stub=types.ModuleType('app.trainer.core')
    def verified(rows, labels, size):
        for r in rows:
            yield np.full((size,size,3),r['image_id']/100,dtype=np.float32), labels[r['food_class_id']]
    stub.verified_images=verified
    monkeypatch.setitem(sys.modules,'app.trainer.core',stub)
    monkeypatch.setenv('CACHE_PREPROCESS_WORKERS','3')
    rows=[{'image_id':i,'food_class_id':1,'hash':format(i,'064x')} for i in range(1,40)]
    root=tmp_path/'cache'
    cache=tc.build_tensor(10,'TRAIN',rows,{1:0},8,root)
    assert (cache/'ready.json').is_file()
    assert np.load(cache/'images.npy',mmap_mode='r').shape==(39,8,8,3)
    assert np.allclose(np.load(cache/'images.npy',mmap_mode='r')[0],0.01)
    assert tc.build_tensor(10,'TRAIN',rows,{1:0},8,root)==cache
    assert len(list(root.glob('.packing-*')))==0


def test_cache_key_changes_with_content():
    a=[{'image_id':1,'food_class_id':7,'hash':'a'*64}]
    b=[{'image_id':1,'food_class_id':7,'hash':'b'*64}]
    assert tc.key_for(1,'TRAIN',a,160)!=tc.key_for(1,'TRAIN',b,160)


def test_split_policy_and_cpu_config_in_source():
    core=(Path(__file__).resolve().parents[1]/'app/trainer/core.py').read_text()
    platform=(Path(__file__).resolve().parents[1]/'app/platform.py').read_text()
    assert 'LFM_CPU_CORES' in core
    assert 'MIN_SNAPSHOT_IMAGES_PER_CLASS' in platform
    assert 'MIN_SNAPSHOT_HOLDOUT_PER_CLASS' in platform
