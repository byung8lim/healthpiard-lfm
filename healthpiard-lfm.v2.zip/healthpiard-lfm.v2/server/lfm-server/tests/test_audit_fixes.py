from pathlib import Path
import ast

ROOT=Path(__file__).resolve().parents[1]
def test_all_python_syntax():
    for f in ROOT.rglob('*.py'):
        if '.venv' not in f.parts: ast.parse(f.read_text(),filename=str(f))

def test_feeder_backward_compatibility():
    text=(ROOT/'app/main.py').read_text()
    assert '"trainingJobId": 0' in text
    assert '"idempotentReplay": True' in text

def test_tensor_cache_and_recovery_guards():
    assert 'open_memmap' in (ROOT/'app/trainer/tensor_cache.py').read_text()
    worker=(ROOT/'app/worker.py').read_text()
    assert 'QUARANTINED:' in worker
    assert 'attempt >= max_attempts' in worker
    assert 'POW(2,attempt)' in worker

def test_tensorflow_export_not_torch():
    assert 'tensorflow-cpu' in (ROOT/'requirements-training.txt').read_text()
    assert 'tf.lite.TFLiteConverter' in (ROOT/'app/trainer/export.py').read_text()
