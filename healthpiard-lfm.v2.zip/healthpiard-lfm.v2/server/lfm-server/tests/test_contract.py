"""Lightweight validation tests: run python -m unittest discover -s tests."""
import hashlib
import io
import unittest

from fastapi import HTTPException
from PIL import Image
from app.main import clean_string, parse_number, read_image, valid_code

class ContractTests(unittest.TestCase):
    def test_request_ids_required(self):
        with self.assertRaises(HTTPException):
            clean_string("   ", "clientRequestId", 128)

    def test_nonnegative_nutrition(self):
        with self.assertRaises(HTTPException):
            parse_number("-2", "proteinG")

    def test_invalid_image(self):
        with self.assertRaises(HTTPException):
            read_image(b"not an image")

    def test_jpeg_dimensions(self):
        b = io.BytesIO()
        Image.new("RGB", (10, 11)).save(b, format="JPEG")
        self.assertEqual(read_image(b.getvalue()), (10, 11, "image/jpeg"))

    def test_code_stable(self):
        self.assertEqual(valid_code("김치찌개", None), valid_code("김치찌개", None))

if __name__ == '__main__':
    unittest.main()
