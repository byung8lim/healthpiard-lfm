import hashlib
import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.trainer.data_integrity import validate_snapshot_splits

def row(i, c=1, sha=None):
    return {'image_id':i,'food_class_id':c,'hash':sha or hashlib.sha256(str(i).encode()).hexdigest()}

def test_valid_split():
    result=validate_snapshot_splits([row(1)],[row(2)],[row(3)],[{'foodClassId':1}])
    assert result['TEST']=={'1':1}

@pytest.mark.parametrize('train,val,test',[
    ([row(1)],[row(1)],[row(3)]),
    ([row(1)],[row(2,sha=row(1)['hash'])],[row(3)]),
    ([row(1)],[],[row(3)]),
    ([row(1)],[row(2)],[row(3,c=2)]),
])
def test_reject_invalid_splits(train,val,test):
    with pytest.raises(ValueError):validate_snapshot_splits(train,val,test,[{'foodClassId':1}])

def test_export_top3_gate_present():
    source=(Path(__file__).resolve().parents[1]/'app/trainer/export.py').read_text()
    assert 'top3_accuracy>=min_top3' in source
    assert "'MIN_RELEASE_TOP3_ACCURACY','0.98'" in source
