from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'app'
def test_release_accuracy_gate_not_disabled():
    text=(ROOT/'platform.py').read_text()
    assert 'accuracyGateEnabled=False' not in text
    assert "MIN_RELEASE_HOLDOUT_ACCURACY','0.90'" in text
    assert "'LOW_HOLDOUT_ACCURACY'" in text
def test_quality_report_per_image_and_explicit_truth():
    text=(ROOT/'quality_report.py').read_text()
    assert "'top1_correct'" in text
    assert 'for path in item[\'images\']' in text
    assert 'independentHoldoutVerified' in text
def test_failed_local_inference_fails_closed():
    text=(ROOT/'platform.py').read_text()
    assert 'LOCAL_INFERENCE_FAILED' in text
    assert "raise HTTPException(422" in text
