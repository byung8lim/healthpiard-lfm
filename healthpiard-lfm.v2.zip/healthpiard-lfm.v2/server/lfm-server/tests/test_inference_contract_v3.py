import io, sys
from pathlib import Path
import numpy as np
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.inference_contract import preprocess_image, output_probabilities, batch_for_interpreter, class_entries

def test_center_black_padding_and_signed_range():
    im=Image.new('RGB',(80,40),(255,0,0)); b=io.BytesIO(); im.save(b,format='PNG')
    x=preprocess_image(b.getvalue(),32)
    assert x.shape==(32,32,3) and x.dtype==np.float32
    assert np.allclose(x[0,0],[-1,-1,-1])
    assert np.allclose(x[16,16],[1,-1,-1])

def test_no_upscale():
    im=Image.new('RGB',(2,2),(255,255,255)); b=io.BytesIO();im.save(b,format='PNG')
    x=preprocess_image(b.getvalue(),32)
    assert np.allclose(x[0,0],[-1,-1,-1])
    assert np.allclose(x[15,15],[1,1,1])

def test_probabilities_are_not_softmaxed_twice():
    v=output_probabilities([0.9,0.1])
    assert np.allclose(v,[0.9,0.1])

def test_invalid_logits_rejected():
    import pytest
    with pytest.raises(ValueError):output_probabilities([3.0,-1.0])

def test_class_index_invalid_order(tmp_path):
    import json,pytest
    f=tmp_path/'class_index.json';f.write_text(json.dumps([{'index':1,'foodClassId':3}]))
    with pytest.raises(ValueError):class_entries(f)

def test_batch_matches_canonical():
    im=Image.new('RGB',(80,40),(255,0,0));b=io.BytesIO();im.save(b,format='PNG')
    info={'shape':[1,32,32,3],'dtype':np.float32}
    assert np.array_equal(batch_for_interpreter(b.getvalue(),info)[0],preprocess_image(b.getvalue(),32))
