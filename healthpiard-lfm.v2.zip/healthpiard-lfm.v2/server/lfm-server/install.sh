#!/usr/bin/env bash
# V009 one-shot CLEAN install and FULL isolated E2E verification.
set -Eeuo pipefail
cd "$(dirname "$(readlink -f "$0")")"
: "${ROOT_PASSWORD+x}" || { echo 'ERROR: export ROOT_PASSWORD (empty string is allowed)' >&2; exit 2; }
exec python3.11 ops/v009_install.py
