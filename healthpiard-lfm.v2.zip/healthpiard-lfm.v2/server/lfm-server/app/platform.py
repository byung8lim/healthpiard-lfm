"""Admin/data control plane. No training is launched by ingestion or snapshot creation."""
from __future__ import annotations
import hashlib, json, os, random, time
from pathlib import Path
from fastapi import APIRouter, Header, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy import text, bindparam
from app.main import engine, OBJECT_ROOT, one, snapshot, MAX_UPLOAD_BYTES
from PIL import Image
from app.quality_report import create_report

router=APIRouter(prefix='/api/v1')
ARTIFACT_ROOT=Path(os.getenv('ARTIFACT_ROOT','./release-artifacts')).resolve()
ADMIN_TOKEN=os.getenv('ADMIN_TOKEN','')
def authorize(token):
    if not ADMIN_TOKEN or token != 'Bearer '+ADMIN_TOKEN:
        raise HTTPException(401,'Admin bearer token required')
def canon(obj):return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(obj):return hashlib.sha256(canon(obj).encode()).digest()
def err(message,code=409):raise HTTPException(code,message)

class SnapshotCreate(BaseModel):
    name:str=Field(min_length=1,max_length=160)
    splitSeed:int=42
    trainRatio:float=Field(default=.8,gt=0,lt=1)
    validationRatio:float=Field(default=.1,gt=0,lt=1)
    actor:str=Field(min_length=1,max_length=128)

class FilteredSnapshotCreate(BaseModel):
    name:str=Field(min_length=1,max_length=160)
    threshold:float=Field(default=.90,gt=0,le=1)
    actor:str=Field(min_length=1,max_length=128)

class ClassDeleteRequest(BaseModel):
    classIds:list[int]=Field(default_factory=list)
    class_ids:list[int]=Field(default_factory=list)

@router.post('/admin/snapshots',status_code=201)
def create_snapshot(req:SnapshotCreate, authorization:str|None=Header(None)):
    authorize(authorization)
    if req.trainRatio+req.validationRatio>=1:err('Train + validation must be < 1',422)
    with engine.begin() as c:
        # Consistent image/quality/assignment view under REPEATABLE READ.
        rows=c.execute(text("""SELECT i.id image_id,a.food_class_id,i.sha256,i.storage_key
           FROM image_object i JOIN class_assignment a ON a.image_id=i.id
           JOIN image_quality q ON q.image_id=i.id
           WHERE q.status='PASS' ORDER BY a.food_class_id,i.id""")).mappings().all()
        unassigned=c.execute(text("""SELECT COUNT(*) FROM image_object i
            JOIN image_quality q ON q.image_id=i.id
            LEFT JOIN class_assignment a ON a.image_id=i.id
            WHERE q.status='PASS' AND a.image_id IS NULL""")).scalar_one()
        if unassigned:
            err({'code':'SNAPSHOT_UNASSIGNED_IMAGES','count':unassigned,
                 'message':'Approved images missing class assignment'},422)
        if not rows:err({'code':'SNAPSHOT_NO_APPROVED_IMAGES','message':'No PASS images with class assignments'},422)
        seen=set(); classes={}
        for r in rows:
            if r['image_id'] in seen:err('Ambiguous class assignment; correct labels first')
            seen.add(r['image_id']);classes.setdefault(r['food_class_id'],[]).append(r)
        # V017: Never reject a valid dataset merely because a global 30-image
        # training-readiness threshold was reused as a snapshot constraint.
        # Every represented class must still have disjoint TRAIN/VAL/TEST items.
        # Preflight all classes before inserting anything (immutable snapshot).
        insufficient={cid:len(imgs) for cid,imgs in classes.items() if len(imgs)<3}
        if insufficient:
            err({'code':'SNAPSHOT_CLASS_TOO_SMALL',
                 'message':'At least 3 approved images per class are required for TRAIN/VALIDATION/TEST',
                 'classes':insufficient},422)
        items=[]
        for cid,images in sorted(classes.items()):
            # Stable per-class shuffle; class-balanced splits.
            rand=random.Random(f'{req.splitSeed}:{cid}')
            images=list(images);rand.shuffle(images)
            n=len(images);nval=max(1,int(n*req.validationRatio));ntest=max(1,int(n*(1-req.trainRatio-req.validationRatio)));ntrain=n-nval-ntest
            if ntrain<1:err({'code':'SNAPSHOT_SPLIT_INVALID','classId':cid,'imageCount':n},422)
            for idx,r in enumerate(images):
                split='TRAIN' if idx<ntrain else ('VALIDATION' if idx<ntrain+nval else 'TEST')
                items.append(dict(imageId=r['image_id'],classId=cid,split=split,
                                  sha256=bytes(r['sha256']).hex(),storageKey=r['storage_key']))
        items.sort(key=lambda x:x['imageId'])
        manifest={'schemaVersion':1,'splitSeed':req.splitSeed,
                  'trainRatio':req.trainRatio,'validationRatio':req.validationRatio,'items':items}
        digest=sha(manifest)
        existing=one(c,'SELECT id FROM dataset_snapshot WHERE manifest_sha256=:h',{'h':digest})
        if existing:err(f'Identical snapshot already exists: {existing["id"]}')
        counts={s:sum(i['split']==s for i in items) for s in ('TRAIN','VALIDATION','TEST')}
        res=c.execute(text("""INSERT INTO dataset_snapshot
        (name,split_seed,manifest_sha256,manifest_json,image_count,train_count,validation_count,test_count,created_by)
        VALUES (:n,:seed,:hash,:manifest,:total,:tr,:val,:te,:actor)"""),
          dict(n=req.name,seed=req.splitSeed,hash=digest,manifest=canon(manifest),
               total=len(items),tr=counts['TRAIN'],val=counts['VALIDATION'],te=counts['TEST'],actor=req.actor))
        sid=res.lastrowid
        c.execute(text("""INSERT INTO dataset_snapshot_item
          (snapshot_id,image_id,food_class_id,split,sha256,storage_key)
          VALUES (:sid,:imageId,:classId,:split,UNHEX(:sha256),:storageKey)"""),
          [dict(sid=sid,**i) for i in items])
        c.execute(text("UPDATE dataset_snapshot SET status='COMPLETED' WHERE id=:sid AND status='CREATING'"),{'sid':sid})
        return {'snapshotId':sid,'manifestSha256':digest.hex(),'counts':counts,'immutable':True}

@router.get('/admin/snapshots/{sid}')
def read_snapshot(sid:int, authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.connect() as c:
        r=one(c,'SELECT manifest_json,HEX(manifest_sha256) hash FROM dataset_snapshot WHERE id=:id',{'id':sid})
    if not r:err('Snapshot not found',404)
    return {'snapshotId':sid,'manifestSha256':r['hash'].lower(),'manifest':json.loads(r['manifest_json']) if isinstance(r['manifest_json'],str) else r['manifest_json']}

@router.get('/admin/training-jobs/{job_id}/quality-diagnostics')
def quality_diagnostics(job_id:int, authorization:str|None=Header(None)):
    """Return the per-class holdout diagnostics even when the quality gate failed."""
    authorize(authorization)
    with engine.connect() as c:
        job=one(c,'SELECT snapshot_id FROM training_job WHERE id=:id',{'id':job_id})
    if not job:err('Training job not found',404)
    path=Path(os.getenv('TRAIN_ROOT','./training-runs')).resolve()/f"snapshot-{job['snapshot_id']}"/f"job-{job_id}"/'export_diagnostics.json'
    if not path.is_file():err({'code':'QUALITY_DIAGNOSTICS_NOT_FOUND','path':str(path)},404)
    result=json.loads(path.read_text(encoding='utf-8'))
    run_root=path.parent
    state={}
    state_path=run_root/'state.json'
    if state_path.is_file():
        try: state=json.loads(state_path.read_text(encoding='utf-8'))
        except (OSError,ValueError): state={}
    with engine.connect() as c:
        classes=c.execute(text('''SELECT f.id class_id,f.food_name,
          SUM(s.split='TRAIN') train_count,SUM(s.split='VALIDATION') validation_count,
          SUM(s.split='TEST') test_count
          FROM dataset_snapshot_item s JOIN food_class f ON f.id=s.food_class_id
          WHERE s.snapshot_id=:sid GROUP BY f.id,f.food_name ORDER BY f.id'''),{'sid':job['snapshot_id']}).mappings().all()
    final_metrics=state.get('metrics') or {}
    for i,r in enumerate(classes):
        p=result.get('perClass',{}).get(str(i))
        if p is not None:
            p.update({'trainCount':int(r['train_count'] or 0),'validationCount':int(r['validation_count'] or 0),
                      'testCount':int(r['test_count'] or 0),'test_accuracy':float(p.get('accuracy',0)),
                      'finalLoss':final_metrics.get('loss'),'finalValAccuracy':final_metrics.get('val_accuracy'),
                      'completedEpochs':state.get('completedEpochs'),'epochs':state.get('epochs')})
    result['belowThreshold']=[{'classId':r['class_id'],'foodName':r['food_name'],
                               'accuracy':float(result.get('perClass',{}).get(str(i),{}).get('accuracy',0))}
                              for i,r in enumerate(classes)
                              if str(i) in result.get('perClass',{})]
    return result

@router.post('/admin/training-jobs/{job_id}/filtered-snapshot',status_code=201)
def filtered_snapshot(job_id:int,req:FilteredSnapshotCreate,authorization:str|None=Header(None)):
    """Create a new immutable snapshot excluding classes below the requested gate."""
    authorize(authorization)
    with engine.connect() as c:
        job=one(c,'SELECT snapshot_id FROM training_job WHERE id=:id',{'id':job_id})
        if not job:err('Training job not found',404)
        sid=int(job['snapshot_id'])
        class_rows=c.execute(text('''SELECT DISTINCT food_class_id FROM dataset_snapshot_item
          WHERE snapshot_id=:sid ORDER BY food_class_id'''),{'sid':sid}).scalars().all()
        item_rows=c.execute(text('''SELECT image_id,food_class_id,split,HEX(sha256) sha256,storage_key
          FROM dataset_snapshot_item WHERE snapshot_id=:sid ORDER BY image_id'''),{'sid':sid}).mappings().all()
    diag=quality_diagnostics(job_id,authorization)
    bad_indices={int(k) for k,v in diag.get('perClass',{}).items()
                 if float(v.get('accuracy',0)) < req.threshold}
    excluded_ids={int(cid) for idx,cid in enumerate(class_rows) if idx in bad_indices}
    if not excluded_ids:err({'code':'NO_CLASSES_BELOW_THRESHOLD','threshold':req.threshold},422)
    items=[dict(imageId=r['image_id'],classId=r['food_class_id'],split=r['split'],
                sha256=r['sha256'].lower(),storageKey=r['storage_key'])
           for r in item_rows if int(r['food_class_id']) not in excluded_ids]
    if not items:err('Filtering would remove every class',422)
    manifest={'schemaVersion':1,'sourceSnapshotId':sid,'sourceJobId':job_id,
              'excludedClassIds':sorted(excluded_ids),'threshold':req.threshold,
              'items':items}
    digest=sha(manifest)
    counts={s:sum(i['split']==s for i in items) for s in ('TRAIN','VALIDATION','TEST')}
    with engine.begin() as c:
        existing=one(c,'SELECT id FROM dataset_snapshot WHERE manifest_sha256=:h',{'h':digest})
        if existing:
            return {'snapshotId':int(existing['id']),'sourceSnapshotId':sid,'sourceJobId':job_id,
                    'threshold':req.threshold,'excludedClassIds':sorted(excluded_ids),
                    'counts':counts,'immutable':True,'reused':True}
        res=c.execute(text('''INSERT INTO dataset_snapshot
          (name,split_seed,manifest_sha256,manifest_json,image_count,train_count,validation_count,test_count,created_by)
          VALUES (:n,0,:hash,:manifest,:total,:tr,:val,:te,:actor)'''),
          dict(n=req.name,hash=digest,manifest=canon(manifest),total=len(items),
               tr=counts['TRAIN'],val=counts['VALIDATION'],te=counts['TEST'],actor=req.actor))
        new_sid=res.lastrowid
        c.execute(text('''INSERT INTO dataset_snapshot_item
          (snapshot_id,image_id,food_class_id,split,sha256,storage_key)
          VALUES (:sid,:imageId,:classId,:split,UNHEX(:sha256),:storageKey)'''),
          [dict(sid=new_sid,**i) for i in items])
        c.execute(text("UPDATE dataset_snapshot SET status='COMPLETED' WHERE id=:sid"),{'sid':new_sid})
        # Keep excluded classes visible in the admin UI as rejected data. The
        # immutable source snapshot remains unchanged, while future snapshots
        # cannot accidentally include these images again.
        c.execute(text('''UPDATE image_quality q JOIN class_assignment a ON a.image_id=q.image_id
          SET q.status='REJECT',q.reason_code='HOLDOUT_ACCURACY_BELOW_THRESHOLD',q.checked_at=UTC_TIMESTAMP(6)
          WHERE a.food_class_id IN :ids''').bindparams(bindparam('ids',expanding=True)),
          {'ids':sorted(excluded_ids)})
    return {'snapshotId':new_sid,'sourceSnapshotId':sid,'sourceJobId':job_id,
            'threshold':req.threshold,'excludedClassIds':sorted(excluded_ids),
            'counts':counts,'immutable':True}

class QualityUpdate(BaseModel):
    status:str
    reasonCode:str|None=None
@router.patch('/admin/images/{image_id}/quality')
def update_quality(image_id:int,req:QualityUpdate,authorization:str|None=Header(None)):
    authorize(authorization)
    if req.status not in ('PASS','REJECT','PENDING'):err('Invalid quality status',422)
    with engine.begin() as c:
        result=c.execute(text("""UPDATE image_quality SET status=:s,reason_code=:r,checked_at=UTC_TIMESTAMP(6)
            WHERE image_id=:id"""),dict(s=req.status,r=req.reasonCode,id=image_id))
        if not result.rowcount:err('Image not found',404)
    return {'imageId':image_id,'qualityStatus':req.status}

class Relabel(BaseModel):
    foodClassId:int
@router.put('/admin/images/{image_id}/class')
def relabel(image_id:int,req:Relabel,authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.begin() as c:
        if not one(c,'SELECT id FROM food_class WHERE id=:id',{'id':req.foodClassId}):err('Class not found',404)
        # Existing immutable snapshots retain their original class assignment.
        result=c.execute(text('DELETE FROM class_assignment WHERE image_id=:id'),{'id':image_id})
        if not result.rowcount:err('Assignment not found',404)
        c.execute(text("""INSERT INTO class_assignment(image_id,food_class_id,assignment_source)
            VALUES (:id,:c,'ADMIN')"""),{'id':image_id,'c':req.foodClassId})
    return {'imageId':image_id,'foodClassId':req.foodClassId}

@router.get('/admin/classes')
def classes(authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.connect() as c:
        rows=c.execute(text('SELECT id,class_code,food_name,status FROM food_class ORDER BY id')).mappings().all()
        return [{**dict(r),'trainingReadiness':snapshot(c,r['id'])} for r in rows]

class JobCreate(BaseModel):
    snapshotId:int
    modelFamily:str=os.getenv('DEFAULT_MODEL_FAMILY','efficientnet_lite0')
    baseReleaseId:int|None=None
    actor:str
    epochs:int=Field(default=30,ge=1,le=500)
    batchSize:int=Field(default=16,ge=1,le=128)
    imageSize:int|None=None
    maxAttempts:int=Field(default=3,ge=1,le=10)
@router.post('/admin/training-jobs',status_code=201)
def enqueue(req:JobCreate,authorization:str|None=Header(None)):
    authorize(authorization)
    if req.modelFamily not in ('mobilenet_v3_large','efficientnet_lite0'):
        err('Unsupported model family',422)
    image_size=req.imageSize if req.imageSize is not None else (224 if req.modelFamily=='efficientnet_lite0' else 192)
    if image_size not in (128,160,192,224):err('Unsupported image size',422)
    with engine.begin() as c:
        if not one(c,'SELECT id FROM dataset_snapshot WHERE id=:id',{'id':req.snapshotId}):err('Snapshot not found',404)
        if req.baseReleaseId and not one(c,"SELECT id FROM model_release WHERE id=:id AND status='APPROVED'",{'id':req.baseReleaseId}):err('Base release is not approved')
        if req.baseReleaseId:
            base=one(c,'''SELECT j.model_family FROM model_release r
                JOIN training_job j ON j.id=r.job_id WHERE r.id=:id''',{'id':req.baseReleaseId})
            if not base or base['model_family']!=req.modelFamily:
                err('Base release model family differs; initialize from ImageNet instead',422)
        result=c.execute(text("""INSERT INTO training_job
          (snapshot_id,model_family,base_release_id,config_json,requested_by,max_attempts)
          VALUES (:s,:m,:b,:cfg,:actor,:ma)"""),dict(s=req.snapshotId,m=req.modelFamily,b=req.baseReleaseId,
             cfg=canon({'epochs':req.epochs,'batchSize':req.batchSize,'imageSize':image_size}),actor=req.actor,ma=req.maxAttempts))
        return {'jobId':result.lastrowid,'status':'QUEUED','autoStarted':False}
@router.post('/admin/training-jobs/{job_id}/cancel')
def cancel(job_id:int,authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.begin() as c:
        r=c.execute(text("""UPDATE training_job SET cancel_requested=1,
           status=IF(status='QUEUED','CANCELLED',status)
           WHERE id=:id AND status IN ('QUEUED','RUNNING')"""),{'id':job_id})
        if not r.rowcount:err('Job not cancellable')
    return {'jobId':job_id,'cancelRequested':True}
@router.post('/admin/training-jobs/{job_id}/retry')
def retry(job_id:int,authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.begin() as c:
        r=c.execute(text("""UPDATE training_job SET status='QUEUED',cancel_requested=0,
           lease_owner=NULL,lease_until=NULL,error_message=NULL
           WHERE id=:id AND status IN ('FAILED','CANCELLED') AND attempt < max_attempts"""),{'id':job_id})
        if not r.rowcount:err('Job cannot be retried')
    return {'jobId':job_id,'status':'QUEUED'}
@router.get('/admin/training-jobs')
def jobs(authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.connect() as c:
        return [dict(r) for r in c.execute(text("""SELECT id,snapshot_id,model_family,status,attempt,
          max_attempts,heartbeat_at,cancel_requested,created_at FROM training_job ORDER BY id DESC LIMIT 200""")).mappings()]

class ReleaseApprove(BaseModel):
    actor:str
    approved:bool
@router.post('/admin/releases/{release_id}/review')
def review_release(release_id:int,req:ReleaseApprove,authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.begin() as c:
        r=c.execute(text("""UPDATE model_release SET status=:status, approved_by=:actor
            WHERE id=:id AND status='CANDIDATE' """),dict(id=release_id,actor=req.actor,status='APPROVED' if req.approved else 'REJECTED'))
        if not r.rowcount:err('Release not pending review')
    return {'releaseId':release_id,'status':'APPROVED' if req.approved else 'REJECTED'}
class Activate(BaseModel):
    releaseId:int
    actor:str
    expectedRevision:int=Field(ge=0)
@router.post('/admin/releases/activate')
def activate(req:Activate,authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.begin() as c:
        channel=one(c,"SELECT active_release_id,revision FROM release_channel WHERE channel_name='stable' FOR UPDATE",{})
        if channel['revision']!=req.expectedRevision:err('Channel revision conflict')
        if not one(c,"SELECT id FROM model_release WHERE id=:id AND status='APPROVED'",{'id':req.releaseId}):err('Release is not approved')
        c.execute(text("UPDATE release_channel SET active_release_id=:id,revision=revision+1,updated_by=:actor WHERE channel_name='stable'"),dict(id=req.releaseId,actor=req.actor))
        c.execute(text("""INSERT INTO release_activation_event(channel_name,from_release_id,to_release_id,actor)
          VALUES ('stable',:old,:new,:actor)"""),dict(old=channel['active_release_id'],new=req.releaseId,actor=req.actor))
        return {'activeReleaseId':req.releaseId,'revision':channel['revision']+1}
@router.get('/releases/latest')
def latest():
    with engine.connect() as c:
        r=one(c,"""SELECT c.revision,r.id,r.version_tag,r.manifest_json,HEX(r.manifest_sha256) digest
        FROM release_channel c JOIN model_release r ON r.id=c.active_release_id
        WHERE c.channel_name='stable' """,{})
    if not r:err('No active release',404)
    return {'releaseId':r['id'],'version':r['version_tag'],'revision':r['revision'],
            'manifest':json.loads(r['manifest_json']) if isinstance(r['manifest_json'],str) else r['manifest_json'],
            'manifestSha256':r['digest'].lower()}
@router.get('/releases/{release_id}/files/{filename}')
def download(release_id:int,filename:str):
    if filename not in ('model.tflite','class_index.json','nutrition.json','nutrition.sqlite','manifest.json'):
        err('File not allowed',404)
    with engine.connect() as c:
        r=one(c,"""SELECT r.manifest_json FROM model_release r
            JOIN release_channel c ON c.active_release_id=r.id AND c.channel_name='stable'
            WHERE r.id=:id AND r.status='APPROVED' """,{'id':release_id})
    if not r:err('Release not active',404)
    manifest=json.loads(r['manifest_json']) if isinstance(r['manifest_json'],str) else r['manifest_json']
    expected=manifest.get('files',{}).get(filename) if filename!='manifest.json' else {'sha256':hashlib.sha256(canon(manifest).encode()).hexdigest()}
    path=ARTIFACT_ROOT/str(release_id)/filename
    if not expected or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected['sha256']:
        err('Artifact missing or corrupt',503)
    return FileResponse(path,filename=filename)


class PublishCandidate(BaseModel):
    jobId:int
    versionTag:str=Field(min_length=1,max_length=100)

@router.post('/admin/releases/candidates',status_code=201)
def create_candidate(req:PublishCandidate, authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.connect() as c:
        job=one(c,"SELECT status,result_json FROM training_job WHERE id=:id",{'id':req.jobId})
    if not job or job['status']!='SUCCEEDED':err('Completed job required')
    result=job['result_json']
    if isinstance(result,str):result=json.loads(result)
    if not result or not result.get('trained') or not result.get('validation'):
        err({'code':'TRAINING_RESULT_MISSING','message':'Successful trained artifact and validation required'})
    validation=result['validation']
    minimum_classes=int(os.getenv('MIN_RELEASE_CLASSES','20'))
    if minimum_classes < 1:
        err('Invalid release policy configuration',500)
    with engine.connect() as c:
        class_count=c.execute(text('''SELECT COUNT(DISTINCT s.food_class_id)
            FROM dataset_snapshot_item s JOIN training_job j ON j.snapshot_id=s.snapshot_id
            WHERE j.id=:id'''),{'id':req.jobId}).scalar_one()
    if class_count < minimum_classes:
        err({'code':'INSUFFICIENT_CLASSES','required':minimum_classes,'actual':class_count})
    accuracy=float(validation.get('holdoutAccuracy',-1))
    if not validation.get('numericConversionPassed',False):
        err({'code':'TFLITE_NUMERIC_DIVERGENCE','actual':validation.get('maxAbsoluteError')})
    if float(validation.get('top1Agreement',0)) < float(os.getenv('MIN_TOP1_AGREEMENT','0.98')):
        err({'code':'MODEL_CONVERSION_VALIDATION_FAILED','message':'TFLite/Keras agreement or Top3 gate failed'})
    # Fail closed: conversion agreement is necessary but never proof of classification quality.
    # Historical jobs with disabled accuracy gates must be re-evaluated against their
    # untouched holdout set before a new release can be published.
    minimum_accuracy=float(os.getenv('MIN_RELEASE_HOLDOUT_ACCURACY','0.70'))
    if not 0.0 < minimum_accuracy <= 1.0:
        err('MIN_RELEASE_HOLDOUT_ACCURACY must be in (0,1]',500)
    if not 0.0 <= accuracy <= 1.0 or accuracy < minimum_accuracy:
        err({'code':'LOW_HOLDOUT_ACCURACY','required':minimum_accuracy,'actual':accuracy})
    validation=dict(validation,passed=True,minimumAccuracy=minimum_accuracy,
                    accuracyGateEnabled=True,policyReevaluated=True)

    path=Path(result['tfliteModel']).resolve()
    if not path.is_relative_to(Path(os.getenv('TRAIN_ROOT','./training-runs')).resolve()):
        err('Model path outside training workspace')
    from app.release_builder import publish
    try:
        return publish(req.jobId,req.versionTag,str(path),validation)
    except (ValueError,FileExistsError) as ex:
        err(str(ex))

@router.get('/admin/releases')
def list_releases(authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.connect() as c:
        return [dict(r) for r in c.execute(text('''SELECT id,job_id,version_tag,status,approved_by,created_at
            FROM model_release ORDER BY id DESC LIMIT 200''')).mappings()]

@router.post('/admin/classes/bulk-delete-images')
def bulk_delete_class_images(payload:dict|list,authorization:str|None=Header(None)):
    authorize(authorization)
    raw_ids=payload if isinstance(payload,list) else (payload.get('classIds') or payload.get('class_ids') or payload.get('ids') or [])
    ids=sorted(set(int(i) for i in raw_ids))
    if not ids: err('Select at least one class',422)
    if any(i<1 for i in ids): err('Invalid class id',422)
    removed=[]
    with engine.begin() as c:
        rows=list(c.execute(text('''SELECT DISTINCT i.id,i.storage_key FROM image_object i
          JOIN class_assignment a ON a.image_id=i.id
          WHERE a.food_class_id IN :class_ids''').bindparams(bindparam('class_ids',expanding=True)),{'class_ids':ids}).mappings())
        for row in rows:
            # Snapshot-bound images are immutable and must not be physically deleted.
            if one(c,'SELECT id FROM dataset_snapshot_item WHERE image_id=:id LIMIT 1',{'id':row['id']}):
                err('Cannot delete images already referenced by a snapshot',409)
        if rows:
            image_ids=[r['id'] for r in rows]
            c.execute(text('DELETE FROM class_assignment WHERE image_id IN :ids').bindparams(bindparam('ids',expanding=True)),{'ids':image_ids})
            c.execute(text('DELETE FROM image_quality WHERE image_id IN :ids').bindparams(bindparam('ids',expanding=True)),{'ids':image_ids})
            c.execute(text('DELETE FROM image_object WHERE id IN :ids').bindparams(bindparam('ids',expanding=True)),{'ids':image_ids})
            removed=[dict(r) for r in rows]
    for row in removed:
        path=(OBJECT_ROOT/row['storage_key']).resolve()
        if path.is_relative_to(OBJECT_ROOT) and path.is_file():
            try:path.unlink()
            except OSError:pass
    return {'classes':len(ids),'deleted':len(removed)}

@router.get('/admin/images')
def list_images(status:str='PENDING',limit:int=50,offset:int=0,class_id:int|None=None,authorization:str|None=Header(None)):
    authorize(authorization)
    if status not in ('PENDING','PASS','REJECT') or limit<1 or limit>200 or offset<0:
        err('Invalid pagination or status',422)
    with engine.connect() as c:
        return [dict(r) for r in c.execute(text('''SELECT i.id,i.storage_key,HEX(i.sha256) sha256,
           q.status,q.reason_code,a.food_class_id,f.food_name
           FROM image_object i JOIN image_quality q ON q.image_id=i.id
           LEFT JOIN class_assignment a ON a.image_id=i.id
           LEFT JOIN food_class f ON f.id=a.food_class_id
           WHERE q.status=:s AND (:class_id IS NULL OR a.food_class_id=:class_id)
           ORDER BY i.id DESC LIMIT :lim OFFSET :off'''),
           {'s':status,'class_id':class_id,'lim':limit,'off':offset}).mappings()]

@router.get('/admin/images/{image_id}/content')
def image_content(image_id:int,authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.connect() as c:
        row=one(c,'SELECT storage_key,mime_type FROM image_object WHERE id=:id',{'id':image_id})
    if not row: err('Image not found',404)
    path=(OBJECT_ROOT / row['storage_key']).resolve()
    if not path.is_relative_to(OBJECT_ROOT) or not path.is_file(): err('Image content not found',404)
    return FileResponse(path,media_type=row['mime_type'] or 'application/octet-stream')

@router.get('/admin/training-jobs/{job_id}')
def job_detail(job_id:int,authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.connect() as c:
        r=one(c,'SELECT * FROM training_job WHERE id=:id',{'id':job_id})
    if not r:err('Job not found',404)
    o=dict(r)
    for k in ('config_json','result_json'):
        if isinstance(o[k],str):o[k]=json.loads(o[k])
    return o

@router.get('/admin/training-jobs/{job_id}/classes')
def job_classes(job_id:int,authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.connect() as c:
        return [dict(r) for r in c.execute(text('''SELECT DISTINCT f.id,f.class_code,f.food_name FROM training_job j JOIN dataset_snapshot_item s ON s.snapshot_id=j.snapshot_id JOIN food_class f ON f.id=s.food_class_id WHERE j.id=:id ORDER BY f.food_name'''),{'id':job_id}).mappings()]

@router.post('/admin/training-jobs/{job_id}/quality-report')
def quality_report(job_id:int, authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.connect() as c:
        job=one(c,'SELECT * FROM training_job WHERE id=:id',{'id':job_id})
        if not job: err('Job not found',404)
        if job['status'] != 'SUCCEEDED': err('Completed job required',409)
        path=create_report(c, dict(job), Path(os.getenv('TRAIN_ROOT','./training-runs')).resolve(), Path(os.getenv('QUALITY_REPORT_ROOT','/data/reports')).resolve())
    return {'jobId':job_id,'downloadUrl':f'/api/v1/admin/training-jobs/{job_id}/quality-report','file':str(path.name)}

@router.get('/admin/training-jobs/{job_id}/quality-report')
def quality_report_download(job_id:int, authorization:str|None=Header(None)):
    authorize(authorization)
    path=Path(os.getenv('QUALITY_REPORT_ROOT','/data/reports')).resolve()/f'quality-report-job-{job_id}.csv'
    if not path.is_file(): err('Quality report not found',404)
    return FileResponse(path, media_type='text/csv', filename=path.name)

@router.post('/admin/training-jobs/{job_id}/local-quality-report')
async def local_quality_report(job_id:int, files:list[UploadFile]=File(...), class_ids:str=Form(...), relative_paths:str=Form(...), mode:str=Form('job_tflite'), release_id:int|None=Form(None), authorization:str|None=Header(None)):
    authorize(authorization)
    with engine.connect() as c: job=one(c,'SELECT * FROM training_job WHERE id=:id',{'id':job_id})
    if not job or job['status']!='SUCCEEDED': err('Completed job required',409)
    try:
        ids=json.loads(class_ids); paths=json.loads(relative_paths)
        if not isinstance(ids,list) or len(ids)!=len(files) or len(paths)!=len(files): raise ValueError('file metadata mismatch')
        result=job.get('result_json') or {}; result=json.loads(result) if isinstance(result,str) else result
        if mode not in ('job_tflite','keras','release_tflite'):
            raise ValueError('Invalid inference mode')
        model=Path(result['tfliteModel']).resolve()
        if mode=='keras':
            model=Path(result['kerasModel']).resolve()
        if mode=='release_tflite':
            if release_id is None:raise ValueError('release_id is required')
            with engine.connect() as c:
                release=one(c,'SELECT id,job_id FROM model_release WHERE id=:id',{'id':release_id})
            if not release or int(release['job_id'])!=job_id:
                raise ValueError('Release must belong to the tested job')
            model=ARTIFACT_ROOT/str(release_id)/'model.tflite'
        if not model.is_file():raise ValueError('model artifact not found')
        index=model.parent/'class_index.json'
        if mode=='keras' and not index.is_file():
            index=Path(result['tfliteModel']).resolve().parent/'class_index.json'
        from app.inference_contract import class_entries, predict_tflite, predict_keras
        entries=class_entries(index)
        with engine.connect() as c:
            names={int(r['id']):r['food_name'] for r in c.execute(text('SELECT id,food_name FROM food_class')).mappings()}
        labels=[x.get('name') or names.get(int(x.get('foodClassId')),x.get('classCode',str(x.get('foodClassId')))) for x in entries]
        if mode=='keras':
            import tensorflow as tf
            keras_model=tf.keras.models.load_model(str(model),compile=False)
            interpreter=None
        else:
            try:
                from tflite_runtime.interpreter import Interpreter
            except ImportError:
                from tensorflow.lite.python.interpreter import Interpreter
            interpreter=Interpreter(model_path=str(model)); interpreter.allocate_tensors()
        import csv, io, numpy as np
        rows=[]; failed=0
        for upload,class_id,rel in zip(files,ids,paths):
            data=await upload.read(MAX_UPLOAD_BYTES+1)
            try:
                scores=(predict_keras(keras_model,data,len(labels)) if mode=='keras' else predict_tflite(interpreter,data,len(labels)))
                cells=[rel,class_id]
                for i in list(np.argsort(scores)[::-1][:5]): cells += [labels[i] if i<len(labels) else str(i),round(float(scores[i])*100,2)]
                rows.append(cells)
            except Exception as ex:
                failed+=1
                rows.append([rel,class_id,'ERROR',str(ex)])
        buf=io.StringIO(); w=csv.writer(buf); w.writerow(['file','food_class_id','top1','top1_percent','top2','top2_percent','top3','top3_percent','top4','top4_percent','top5','top5_percent']); w.writerows(rows)
        if failed:
            raise HTTPException(422,{'code':'LOCAL_INFERENCE_FAILED','failed':failed,'total':len(files),'message':'At least one image inference failed; do not use partial CSV as a successful evaluation'})
        from fastapi.responses import StreamingResponse
        return StreamingResponse(iter([buf.getvalue().encode('utf-8-sig')]),media_type='text/csv',headers={'Content-Disposition':f'attachment; filename="local-quality-report-job-{job_id}-{mode}.csv"'})
    except (KeyError,ValueError,json.JSONDecodeError) as ex: raise HTTPException(400,f'Invalid local test request: {ex}')
