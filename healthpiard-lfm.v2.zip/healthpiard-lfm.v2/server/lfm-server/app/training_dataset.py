"""Read-only dataset iterator with SHA verification and bounded RAM.
Use in a custom PyTorch CPU trainer; avoid loading all decoded tensors into memory.
"""
import hashlib, json
from pathlib import Path
from PIL import Image
from sqlalchemy import text
from app.main import engine, OBJECT_ROOT

def batches(snapshot_id,split='TRAIN',batch_size=16):
    if split not in ('TRAIN','VALIDATION','TEST'):raise ValueError('Invalid split')
    with engine.connect() as c:
        rows=c.execute(text("""SELECT image_id,food_class_id,HEX(sha256) hash,storage_key
        FROM dataset_snapshot_item WHERE snapshot_id=:sid AND split=:sp ORDER BY image_id"""),
        dict(sid=snapshot_id,sp=split)).mappings()
        batch=[]
        for r in rows:
            path=OBJECT_ROOT/r['storage_key']
            data=path.read_bytes()
            if hashlib.sha256(data).hexdigest()!=r['hash'].lower():
                raise RuntimeError(f'Corrupted image {r["image_id"]}')
            batch.append((data,r['food_class_id']))
            if len(batch)>=batch_size:
                yield batch;batch=[]
        if batch:yield batch
