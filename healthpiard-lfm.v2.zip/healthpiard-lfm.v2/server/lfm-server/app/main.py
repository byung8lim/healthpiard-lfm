"""Healthpiard feeder ingestion for the additive V001/V002 MySQL 8 schema.

Single-host POSIX filesystem is assumed; SHA-based flock serializes publication.
Run as: uvicorn app.main:app --host 0.0.0.0 --port 8080
"""
from __future__ import annotations

import fcntl
import hashlib
import io
import json
import os
import re
import tempfile
from contextlib import contextmanager
from decimal import Decimal, InvalidOperation
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile, Header
from starlette.concurrency import run_in_threadpool
from PIL import Image, UnidentifiedImageError
from sqlalchemy import create_engine, text
from sqlalchemy.exc import IntegrityError, OperationalError

DATABASE_URL = os.environ.get("DATABASE_URL", "mysql+pymysql://healthpiard:password@127.0.0.1:3306/healthpiard?charset=utf8mb4")
OBJECT_ROOT = Path(os.environ.get("OBJECT_ROOT", "./food-objects")).resolve()
MAX_UPLOAD_BYTES = int(os.environ.get("MAX_UPLOAD_BYTES", str(15 * 1024 * 1024)))
MAX_PIXELS = int(os.environ.get("MAX_PIXELS", "30000000"))
engine = create_engine(DATABASE_URL, pool_pre_ping=True, pool_recycle=1800, future=True)
app = FastAPI(title="Healthpiard LFM feeder ingestion", version="0.2.0")
Image.MAX_IMAGE_PIXELS = MAX_PIXELS
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "")

def authorize(authorization: str | None):
    if not ADMIN_TOKEN or authorization != f"Bearer {ADMIN_TOKEN}":
        raise HTTPException(401, "Admin bearer token required")


def clean_string(value: str, name: str, limit: int) -> str:
    v = value.strip()
    if not v or len(v) > limit:
        raise HTTPException(422, f"Invalid {name}")
    return v


def parse_number(value: str | None, name: str, *, required=False) -> Decimal | None:
    if value is None or value.strip() == "":
        if required:
            raise HTTPException(422, f"Missing {name}")
        return None
    try:
        d = Decimal(value)
    except InvalidOperation:
        raise HTTPException(422, f"Invalid {name}") from None
    if not d.is_finite() or d < 0:
        raise HTTPException(422, f"Invalid {name}")
    return d


def one(conn, statement: str, params: dict):
    return conn.execute(text(statement), params).mappings().first()


@contextmanager
def sha_lock(sha: str):
    lock_dir = OBJECT_ROOT / ".locks"
    lock_dir.mkdir(parents=True, exist_ok=True)
    with open(lock_dir / (sha + ".lock"), "a+b") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def read_image(contents: bytes):
    try:
        with Image.open(io.BytesIO(contents)) as im:
            im.verify()
        with Image.open(io.BytesIO(contents)) as im:
            if im.format not in ("JPEG", "PNG", "WEBP"):
                raise HTTPException(415, "JPEG, PNG or WebP only")
            w, h = im.size
            if w <= 0 or h <= 0 or w * h > MAX_PIXELS:
                raise HTTPException(422, "Invalid image dimensions")
            mime = {"JPEG": "image/jpeg", "PNG": "image/png", "WEBP": "image/webp"}[im.format]
            return w, h, mime
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
        raise HTTPException(422, "Invalid image") from None


def valid_code(food_name: str, code: str | None) -> str:
    # Caller may specify stable class code. Default is hash of Unicode name.
    if code:
        code = clean_string(code, "classCode", 100)
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", code):
            raise HTTPException(422, "Invalid classCode")
        return code
    return "food-" + hashlib.sha256(food_name.encode("utf-8")).hexdigest()[:32]


def snapshot(conn, class_id: int) -> dict:
    n = one(conn, """SELECT COUNT(*) AS n FROM class_assignment a
        JOIN image_quality q ON q.image_id=a.image_id
        WHERE a.food_class_id=:c AND q.status='PASS'""", {"c": class_id})["n"]
    # Only quality-approved distinct images count toward training-readiness.
    level = 150 if n >= 150 else 100 if n >= 100 else 50 if n >= 50 else 0
    return {"approvedImageCount": n, "reachedThreshold": level,
            "milestones": {"50": n >= 50, "100": n >= 100, "150": n >= 150},
            "autoTrainingTriggered": False}


def ingest(payload: bytes, *, client_id: str, request_id: str, food_name: str,
           class_code: str | None, serving: str, calories: str | None,
           carbohydrates: str | None, protein: str | None, fat: str | None,
           source: str | None):
    client_id = clean_string(client_id, "clientId", 128)
    request_id = clean_string(request_id, "clientRequestId", 128)
    food_name = clean_string(food_name, "foodName", 255)
    code = valid_code(food_name, class_code)
    numbers = [parse_number(serving, "servingG", required=True),
               parse_number(calories, "caloriesKcal"),
               parse_number(carbohydrates, "carbohydratesG"),
               parse_number(protein, "proteinG"), parse_number(fat, "fatG")]
    if numbers[0] == 0:
        raise HTTPException(422, "servingG must be positive")
    if source is not None and len(source) > 255:
        raise HTTPException(422, "sourceName too long")
    if not payload or len(payload) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "Upload size outside allowed limit")
    width, height, mime = read_image(payload)
    image_sha = hashlib.sha256(payload).hexdigest()
    canonical = {"clientId": client_id, "clientRequestId": request_id,
                 "foodName": food_name, "classCode": code, "nutrition":
                 [str(n) if n is not None else None for n in numbers],
                 "sourceName": source, "imageSha256": image_sha}
    fingerprint = hashlib.sha256(json.dumps(canonical, ensure_ascii=False,
        sort_keys=True, separators=(",", ":")).encode()).digest()
    ext = {"image/jpeg": "jpg", "image/png": "png", "image/webp": "webp"}[mime]
    key = f"sha256/{image_sha[:2]}/{image_sha[2:4]}/{image_sha}.{ext}"
    dest = OBJECT_ROOT / key
    staged = None
    published_here = False
    try:
        OBJECT_ROOT.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=OBJECT_ROOT, prefix=".ingest-", delete=False) as f:
            staged = Path(f.name)
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        with sha_lock(image_sha):
            try:
                with engine.begin() as conn:
                    # Unique(client_id, client_request_id) plus insert/locking read makes
                    # requests serialized across MySQL nodes; losing insert waits for winner.
                    try:
                        conn.execute(text("""INSERT INTO ingestion_request
                          (client_id,client_request_id,request_sha256,status)
                          VALUES (:c,:r,:h,'PROCESSING')"""),
                          {"c": client_id, "r": request_id, "h": fingerprint})
                    except IntegrityError as exc:
                        # SAVEPOINT is required: failed INSERT must not poison outer txn.
                        # On MySQL duplicate key, transaction remains usable.
                        existing = one(conn, """SELECT request_sha256,status,response_json
                          FROM ingestion_request WHERE client_id=:c AND client_request_id=:r
                          FOR UPDATE""", {"c": client_id, "r": request_id})
                        if not existing:
                            raise exc
                        if bytes(existing["request_sha256"]) != fingerprint:
                            raise HTTPException(409, "clientRequestId reused with different payload")
                        if existing["status"] == "COMPLETED":
                            result = existing["response_json"]
                            if isinstance(result, str):
                                result = json.loads(result)
                            return {**result, "trainingJobId": 0, "idempotentReplay": True}
                        raise HTTPException(409, "Request in progress; retry later")
                    claim = one(conn, """SELECT id FROM ingestion_request
                       WHERE client_id=:c AND client_request_id=:r""",
                       {"c": client_id, "r": request_id})["id"]
                    cls = one(conn, "SELECT id,food_name FROM food_class WHERE class_code=:code FOR UPDATE", {"code": code})
                    if cls is None:
                        try:
                            conn.execute(text("""INSERT INTO food_class (class_code,food_name)
                                VALUES (:code,:name)"""), {"code": code, "name": food_name})
                        except IntegrityError:
                            pass
                        cls = one(conn, "SELECT id,food_name FROM food_class WHERE class_code=:code FOR UPDATE", {"code": code})
                    if cls["food_name"] != food_name:
                        raise HTTPException(409, "classCode maps to a different food name")
                    class_id = cls["id"]
                    # Refuse silent relabeling of already classified image.
                    conflicting = one(conn, """SELECT food_class_id FROM class_assignment a
                        JOIN image_object i ON i.id=a.image_id
                        WHERE i.sha256=UNHEX(:sha) AND a.food_class_id<>:cid LIMIT 1""",
                        {"sha": image_sha, "cid": class_id})
                    if conflicting:
                        raise HTTPException(409, "Image is already assigned to another class")
                    img = one(conn, "SELECT id,storage_key FROM image_object WHERE sha256=UNHEX(:sha) FOR UPDATE", {"sha": image_sha})
                    if img is None:
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        if not dest.exists():
                            os.replace(staged, dest)
                            staged = None
                            published_here = True
                        elif hashlib.sha256(dest.read_bytes()).hexdigest() != image_sha:
                            raise HTTPException(500, "Object path integrity error")
                        conn.execute(text("""INSERT INTO image_object
                         (sha256,storage_key,mime_type,width_px,height_px,byte_size)
                         VALUES (UNHEX(:sha),:key,:mime,:w,:h,:bytes)"""),
                         {"sha": image_sha, "key": key, "mime": mime, "w": width,
                          "h": height, "bytes": len(payload)})
                        img = one(conn, "SELECT id,storage_key FROM image_object WHERE sha256=UNHEX(:sha)", {"sha": image_sha})
                    elif not (OBJECT_ROOT / img["storage_key"]).is_file():
                        # Repair missing object on re-ingestion of identical bytes.
                        target = OBJECT_ROOT / img["storage_key"]
                        target.parent.mkdir(parents=True, exist_ok=True)
                        os.replace(staged, target)
                        staged = None
                        published_here = True
                        dest = target
                    image_id = img["id"]
                    conn.execute(text("""INSERT INTO class_assignment (image_id,food_class_id,assignment_source)
                         VALUES (:i,:c,'FEEDER') ON DUPLICATE KEY UPDATE id=id"""),
                         {"i": image_id, "c": class_id})
                    conn.execute(text("""INSERT INTO image_quality (image_id,status)
                         VALUES (:i,'PENDING') ON DUPLICATE KEY UPDATE image_id=image_id"""),
                         {"i": image_id})
                    # Nutrition versions: record a version only when nutrition differs.
                    previous = one(conn, """SELECT id,version_no,serving_g,calories_kcal,
                      carbohydrates_g,protein_g,fat_g,source_name FROM nutrition
                      WHERE food_class_id=:c ORDER BY version_no DESC LIMIT 1""", {"c": class_id})
                    def same(p):
                        fields = ["serving_g", "calories_kcal", "carbohydrates_g", "protein_g", "fat_g"]
                        return all(p[k] == numbers[j] for j,k in enumerate(fields)) and p["source_name"] == source
                    if previous is not None and same(previous):
                        nutrition_id, version = previous["id"], previous["version_no"]
                    else:
                        version = previous["version_no"] + 1 if previous else 1
                        res = conn.execute(text("""INSERT INTO nutrition
                          (food_class_id,serving_g,calories_kcal,carbohydrates_g,protein_g,
                           fat_g,source_name,version_no,request_id)
                          VALUES (:c,:serving,:cal,:carb,:protein,:fat,:source,:v,:req)"""),
                          {"c": class_id, "serving": numbers[0], "cal": numbers[1],
                           "carb": numbers[2], "protein": numbers[3], "fat": numbers[4],
                           "source": source, "v": version, "req": claim})
                        nutrition_id = res.lastrowid
                    state = snapshot(conn, class_id)
                    response = {"clientRequestId": request_id, "foodClassId": class_id,
                        "classCode": code, "imageId": image_id, "imageSha256": image_sha,
                        "nutritionId": nutrition_id, "nutritionVersion": version,
                        "qualityStatus": "PENDING", "trainingReadiness": state,
                        "autoTrainingTriggered": False, "trainingJobId": 0}
                    conn.execute(text("""UPDATE ingestion_request
                      SET image_id=:image,status='COMPLETED',response_json=:payload
                      WHERE id=:req"""), {"image": image_id, "req": claim,
                       "payload": json.dumps(response, ensure_ascii=False)})
                # Completed database transaction.
                return {**response, "idempotentReplay": False}
            except Exception:
                if published_here:
                    # Never remove an object referenced by a committed DB row.
                    with engine.connect() as check:
                        ref = one(check, "SELECT id FROM image_object WHERE sha256=UNHEX(:sha)", {"sha": image_sha})
                    if ref is None:
                        dest.unlink(missing_ok=True)
                raise
    finally:
        if staged:
            staged.unlink(missing_ok=True)


@app.post("/api/v1/feedFoodModel")
async def feed_food_model(
    image: UploadFile = File(...),
    clientRequestId: str = Form(...),
    clientId: str = Form(...),
    foodName: str = Form(...),
    classCode: str | None = Form(None),
    servingG: str = Form(...),
    caloriesKcal: str | None = Form(None),
    carbohydratesG: str | None = Form(None),
    proteinG: str | None = Form(None),
    fatG: str | None = Form(None),
    sourceName: str | None = Form(None),
    authorization: str | None = Header(None),
):
    authorize(authorization)
    # Limit size without unbounded read.
    data = await image.read(MAX_UPLOAD_BYTES + 1)
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "Image exceeds upload limit")
    return await run_in_threadpool(ingest, data, client_id=clientId, request_id=clientRequestId,
        food_name=foodName, class_code=classCode, serving=servingG,
        calories=caloriesKcal, carbohydrates=carbohydratesG, protein=proteinG,
        fat=fatG, source=sourceName)


@app.get("/api/v1/foodClasses/{class_id}/training-readiness")
def get_training_readiness(class_id: int):
    with engine.connect() as conn:
        if one(conn, "SELECT id FROM food_class WHERE id=:c", {"c": class_id}) is None:
            raise HTTPException(404, "Food class not found")
        return {"foodClassId": class_id, **snapshot(conn, class_id)}

@app.get("/api/v1/foodClasses")
def list_food_classes(q: str = "", authorization: str | None = Header(None)):
    authorize(authorization)
    term = q.strip()
    with engine.connect() as conn:
        rows = conn.execute(text("""SELECT fc.id,fc.class_code,fc.food_name,fc.status,
            n.serving_g,n.calories_kcal,n.carbohydrates_g,n.protein_g,n.fat_g,n.source_name
            FROM food_class fc LEFT JOIN nutrition n ON n.id=(SELECT n2.id FROM nutrition n2
            WHERE n2.food_class_id=fc.id ORDER BY n2.version_no DESC LIMIT 1)
            WHERE (:q='' OR fc.food_name LIKE :like OR fc.class_code LIKE :like)
            ORDER BY fc.food_name LIMIT 500"""), {"q": term, "like": f"%{term}%"}).mappings().all()
        return [dict(r) for r in rows]

from app.platform import router as platform_router
app.include_router(platform_router)
