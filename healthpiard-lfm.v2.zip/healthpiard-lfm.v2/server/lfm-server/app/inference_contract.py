"""Canonical training/inference image and probability contract (v3).
Inputs are EXIF-corrected RGB, thumbnail no upscale, centered black padded,
float32 [-1,1]. All inference callers MUST use this implementation.
"""
from __future__ import annotations
import io
import numpy as np
from PIL import Image, ImageOps

CONTRACT_VERSION = 3

def preprocess_image(source, size: int):
    if size <= 0: raise ValueError('invalid image size')
    if isinstance(source, (bytes, bytearray)):
        source = io.BytesIO(source)
    with Image.open(source) as im:
        rgb = ImageOps.exif_transpose(im).convert('RGB')
        rgb.thumbnail((size, size))
        canvas = Image.new('RGB', (size, size), (0,0,0))
        canvas.paste(rgb, ((size-rgb.width)//2,(size-rgb.height)//2))
        return np.asarray(canvas, dtype=np.float32) / 127.5 - 1.0

def batch_for_interpreter(source, input_detail):
    shape = input_detail['shape']
    if len(shape)!=4 or int(shape[1])!=int(shape[2]) or int(shape[3])!=3:
        raise ValueError('unsupported input shape')
    x = preprocess_image(source, int(shape[1]))[None,...]
    dtype = np.dtype(input_detail['dtype'])
    if np.issubdtype(dtype, np.integer):
        scale, zero = input_detail['quantization']
        if not scale: raise ValueError('missing input quantization scale')
        limits=np.iinfo(dtype)
        x=np.clip(np.rint(x/scale+zero),limits.min,limits.max).astype(dtype)
    elif dtype==np.dtype('float32'):
        x=x.astype(np.float32)
    else: raise ValueError('unsupported input type: '+str(dtype))
    return x

def output_probabilities(raw, output_detail=None):
    scores=np.asarray(raw, dtype=np.float32).reshape(-1)
    if output_detail is not None and np.issubdtype(np.dtype(output_detail['dtype']),np.integer):
        scale,zero=output_detail['quantization']
        if not scale:raise ValueError('missing output quantization scale')
        scores=(scores-zero)*scale
    if not len(scores) or not np.all(np.isfinite(scores)):
        raise ValueError('invalid model output')
    # For existing model families the output layer is already softmax.
    # Reject non-probabilities rather than silently applying a second softmax.
    if np.min(scores)<-1e-3 or np.max(scores)>1.001 or abs(float(scores.sum())-1)>0.02:
        raise ValueError('model output is not normalized probabilities; inspect model head')
    scores=np.maximum(scores,0)
    return scores/scores.sum()

def predict_tflite(interpreter, source, expected_classes=None):
    inp=interpreter.get_input_details()[0]; out=interpreter.get_output_details()[0]
    interpreter.set_tensor(inp['index'],batch_for_interpreter(source,inp))
    interpreter.invoke()
    scores=output_probabilities(interpreter.get_tensor(out['index']),out)
    if expected_classes is not None and len(scores)!=expected_classes:
        raise ValueError(f'class count mismatch: model={len(scores)}, index={expected_classes}')
    return scores

def predict_keras(model, source, expected_classes=None):
    shape=model.input_shape
    scores=output_probabilities(model.predict(preprocess_image(source,int(shape[1]))[None,...],verbose=0))
    if expected_classes is not None and len(scores)!=expected_classes:raise ValueError('class count mismatch')
    return scores

def class_entries(path):
    import json
    data=json.loads(path.read_text(encoding='utf-8'))
    rows=data if isinstance(data,list) else data['classes']
    ordered=sorted(rows,key=lambda x:int(x['index']))
    if [int(x['index']) for x in ordered]!=list(range(len(ordered))):
        raise ValueError('class index is not contiguous')
    if len({int(x['foodClassId']) for x in ordered})!=len(ordered):
        raise ValueError('duplicate food class ID')
    return ordered
