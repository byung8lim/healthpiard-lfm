"""Package a *validated* TFLite model (conversion performed by approved trainer).
Does not fabricate or convert an untrained network. Stores verified artifact metadata.
"""
import hashlib, json, os, shutil, tempfile
from pathlib import Path
from sqlalchemy import text
from app.main import engine, one
from app.platform import ARTIFACT_ROOT, canon
from app.trainer.nutrition_db import build as build_nutrition_db

def publish(job_id:int,version:str,model_path:str,validation:dict):
    model=Path(model_path)
    if not model.is_file() or model.stat().st_size<16:raise ValueError('Missing model')
    with model.open('rb') as f:
        if (f.read(8)[4:8])!=b'TFL3':raise ValueError('Invalid TFLite magic; conversion/validation required')
    if not validation.get('passed'):raise ValueError('Validation must pass before candidate creation')
    with engine.begin() as c:
        job=one(c,"SELECT id,snapshot_id,model_family,config_json FROM training_job WHERE id=:id AND status='SUCCEEDED'",{'id':job_id})
        if not job:raise ValueError('Successful job required')
        rows=c.execute(text("""SELECT DISTINCT fc.id,fc.class_code,fc.food_name FROM dataset_snapshot_item s
          JOIN food_class fc ON fc.id=s.food_class_id WHERE s.snapshot_id=:sid ORDER BY fc.id"""),
          {'sid':job['snapshot_id']}).mappings().all()
        class_index={'schemaVersion':1,'classes':[dict(index=i,foodClassId=r['id'],classCode=r['class_code'],name=r['food_name']) for i,r in enumerate(rows)]}
        # Training and packaging must use the same index ordering.
        trained_index=model.parent/'class_index.json'
        if not trained_index.is_file():raise ValueError('Missing training class index')
        trained_classes=json.loads(trained_index.read_text(encoding='utf-8'))
        if [(int(x['index']),int(x['foodClassId'])) for x in trained_classes] != [
            (x['index'],x['foodClassId']) for x in class_index['classes']]:
            raise ValueError('Train/release class index mismatch')
        nutrients=[]
        for r in rows:
            n=one(c,'SELECT * FROM nutrition WHERE food_class_id=:id ORDER BY version_no DESC LIMIT 1',{'id':r['id']})
            nutrients.append({'foodClassId':r['id'],'nutritionVersion':n['version_no'] if n else None,
              'servingG':str(n['serving_g']) if n else None,'caloriesKcal':str(n['calories_kcal']) if n and n['calories_kcal'] is not None else None})
        nutrition={'schemaVersion':1,'items':nutrients}
        # Allocate release ID inside DB transaction; candidate only after files are staged.
        result=c.execute(text("""INSERT INTO model_release(job_id,version_tag,status,manifest_sha256,manifest_json,validation_json)
             VALUES (:job,:version,'CANDIDATE',UNHEX(REPEAT('00',32)),'{}',:validation)"""),
             dict(job=job_id,version=version,validation=canon(validation)))
        release_id=result.lastrowid
        target=ARTIFACT_ROOT/str(release_id)
        target.mkdir(parents=True,exist_ok=False)
        try:
            shutil.copyfile(model,target/'model.tflite')
            (target/'class_index.json').write_text(canon(class_index),encoding='utf-8')
            (target/'nutrition.json').write_text(canon(nutrition),encoding='utf-8')
            build_nutrition_db(target/'nutrition.sqlite',nutrients)
            # Preserve the trainable model for later class expansion/fine-tuning.
            keras_checkpoint=model.parent/'best_validation.keras'
            if not keras_checkpoint.is_file():
                keras_checkpoint=model.parent/'checkpoint.keras'
            if keras_checkpoint.is_file():
                shutil.copyfile(keras_checkpoint,target/'training_model.keras')
            files={}
            for filename in ('model.tflite','class_index.json','nutrition.json','nutrition.sqlite',*(['training_model.keras'] if (target/'training_model.keras').is_file() else [])):
                p=target/filename
                files[filename]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size}
            config=job['config_json']
            if isinstance(config,str):config=json.loads(config)
            image_size=int(config.get('imageSize',224 if job['model_family']=='efficientnet_lite0' else 192))
            manifest={'schemaVersion':1,'releaseId':release_id,'jobId':job_id,'files':files,
                      'modelFamily':job['model_family'],
                      'input':{'shape':[1,image_size,image_size,3],'dtype':'float32',
                               'colorSpace':'RGB','normalization':{'scale':1/127.5,'offset':-1},
                               'resize':'fit_without_upscaling','padding':'center_black',
                               'exifTranspose':True,'contractVersion':3}}
            (target/'manifest.json').write_text(canon(manifest),encoding='utf-8')
            digest=hashlib.sha256(canon(manifest).encode()).digest()
            c.execute(text("""UPDATE model_release SET manifest_sha256=:hash,manifest_json=:manifest
                 WHERE id=:id"""),dict(hash=digest,manifest=canon(manifest),id=release_id))
        except BaseException:
            shutil.rmtree(target,ignore_errors=True)
            raise
        return {'releaseId':release_id,'manifestSha256':digest.hex(),'status':'CANDIDATE'}
