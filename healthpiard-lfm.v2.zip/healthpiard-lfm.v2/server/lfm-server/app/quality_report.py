"""Download/reuse food test images and create a Top-5 CSV quality report."""
from __future__ import annotations
import csv, hashlib, io, json, os, re, urllib.parse, urllib.request
from pathlib import Path
from PIL import Image

COUNT = 10
IMAGE_EXTS = {'.jpg', '.jpeg', '.png', '.webp'}

def _slug(value: str) -> str:
    return re.sub(r'[^a-zA-Z0-9가-힣_-]+', '_', value).strip('_')[:80] or 'food'

def _google_urls(name: str) -> list[str]:
    q = urllib.parse.quote(name + ' food')
    req = urllib.request.Request('https://www.google.com/search?tbm=isch&q='+q,
        headers={'User-Agent':'Mozilla/5.0'})
    html = urllib.request.urlopen(req, timeout=15).read().decode('utf-8', 'ignore')
    html = (html.replace('\\/', '/').replace('\\u003a', ':').replace('\\u003A', ':')
                .replace('\\u002f', '/').replace('\\u002F', '/')
                .replace('\\u003d', '=').replace('\\u0026', '&').replace('\\x3d', '='))
    urls = []
    for raw in re.findall(r'https?://[^"<> ]+', html):
        url = raw.rstrip('\\,)')
        if url not in urls:
            urls.append(url)
    return urls[:30]

def _download(url: str) -> bytes | None:
    try:
        req = urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0'})
        data = urllib.request.urlopen(req, timeout=15).read()
        with Image.open(io.BytesIO(data)) as im:
            im.verify()
        return data
    except Exception:
        return None

def _classes(conn, job_id: int):
    rows = conn.execute(__import__('sqlalchemy').text('''SELECT DISTINCT f.id,f.food_name
      FROM training_job j JOIN dataset_snapshot_item s ON s.snapshot_id=j.snapshot_id
      JOIN food_class f ON f.id=s.food_class_id WHERE j.id=:id ORDER BY f.id'''), {'id':job_id}).mappings()
    return list(rows)

def create_report(conn, job: dict, root: Path, report_root: Path):
    job_id = int(job['id'])
    test_root = Path(os.getenv('QUALITY_TEST_ROOT', str(root / 'quality-tests'))).resolve() / f'job-{job_id}'
    test_root.mkdir(parents=True, exist_ok=True)
    rows = []
    for food in _classes(conn, job_id):
        folder = test_root / _slug(food['food_name']); folder.mkdir(exist_ok=True)
        files = sorted(p for p in folder.iterdir() if p.suffix.lower() in IMAGE_EXTS and p.is_file())
        if len(files) < COUNT:
            for url in _google_urls(food['food_name']):
                if len(files) >= COUNT: break
                data = _download(url)
                if not data: continue
                target = folder / f'{len(files)+1:02d}.jpg'
                try:
                    with Image.open(io.BytesIO(data)) as im:
                        im.convert('RGB').save(target, 'JPEG', quality=92)
                    files.append(target)
                except Exception: pass
        if len(files) < COUNT:
            raise RuntimeError(f"{food['food_name']}: test images {len(files)}/{COUNT}; Google image download failed")
        rows.append({'food_class_id':food['id'], 'food_name':food['food_name'], 'images':files[:COUNT]})
    result = job.get('result_json') or {}
    if isinstance(result, str): result = json.loads(result)
    model = Path(result.get('tfliteModel','')).resolve()
    from app.inference_contract import class_entries, predict_tflite
    classes=class_entries(model.parent/'class_index.json')
    names=[x.get('name') or x.get('classCode') or str(x['foodClassId']) for x in classes]
    interpreter = None
    try:
        from tflite_runtime.interpreter import Interpreter
        interpreter = Interpreter(model_path=str(model))
    except ImportError:
        from tensorflow.lite.python.interpreter import Interpreter
        interpreter = Interpreter(model_path=str(model))
    interpreter.allocate_tensors(); inp=interpreter.get_input_details()[0]; out=interpreter.get_output_details()[0]
    report_root.mkdir(parents=True, exist_ok=True); report = report_root / f'quality-report-job-{job_id}.csv'
    # Each test IMAGE produces one row; aggregating the most common Top-N labels
    # by rank hides failures and cannot be used to compute Top-1 accuracy.
    per_class=[]
    with report.open('w', newline='', encoding='utf-8-sig') as f:
        w=csv.writer(f)
        w.writerow(['image','food_class_id','expected_name','top1','top1_percent',
                    'top2','top2_percent','top3','top3_percent','top4','top4_percent',
                    'top5','top5_percent','top1_correct','top5_correct','image_sha256'])
        for item in rows:
            correct1=correct5=0
            for path in item['images']:
                import numpy as np
                try:
                    scores=predict_tflite(interpreter,path,len(names))
                except Exception as ex:
                    raise RuntimeError(f"Quality test failed for {path}: {ex}") from ex
                top=list(np.argsort(scores)[::-1][:5])
                predicted=[names[i] for i in top]
                right1=bool(predicted and predicted[0]==item['food_name'])
                right5=item['food_name'] in predicted
                correct1+=right1;correct5+=right5
                cells=[str(path),item['food_class_id'],item['food_name']]
                for i in range(5):
                    cells.extend([names[top[i]],round(100*float(scores[top[i]]),2)] if i<len(top) else ['',0])
                cells.extend([int(right1),int(right5),hashlib.sha256(path.read_bytes()).hexdigest()])
                w.writerow(cells)
            per_class.append((item['food_name'],correct1,correct5,len(item['images'])))
    # Persist auditable summary separately; these test pictures are sourced from
    # web searches and MUST NOT be regarded as an independent holdout guarantee.
    summary={'jobId':job_id,'source':'web_search_or_existing_local_files',
             'independentHoldoutVerified':False,
             'top1Total':sum(x[1] for x in per_class),
             'imageTotal':sum(x[3] for x in per_class),
             'perClass':[{'name':n,'top1Correct':c1,'top5Correct':c5,'images':num}
                         for n,c1,c5,num in per_class]}
    report.with_suffix('.summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
