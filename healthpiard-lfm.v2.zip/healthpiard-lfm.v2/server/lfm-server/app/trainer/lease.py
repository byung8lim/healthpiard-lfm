"""Lease owner is explicitly inherited."""
import os
from sqlalchemy import text
from app.main import engine
OWNER=os.environ.get('HEALTHPIARD_LEASE_OWNER')
if not OWNER: raise RuntimeError('HEALTHPIARD_LEASE_OWNER missing')
def assert_lease(job_id, token):
    with engine.connect() as conn:
        row=conn.execute(text("SELECT 1 FROM training_job WHERE id=:id AND fencing_token=:token AND lease_owner=:owner AND status='RUNNING' AND cancel_requested=0 AND lease_until > UTC_TIMESTAMP(6)"),{'id':job_id,'token':token,'owner':OWNER}).first()
    if not row: raise RuntimeError('Lease expired, cancelled or fenced; stop training')
