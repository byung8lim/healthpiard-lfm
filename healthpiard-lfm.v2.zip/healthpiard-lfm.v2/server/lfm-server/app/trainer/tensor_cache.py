"""Crash-safe, snapshot-bound read-only NPY memory-mapped image tensors.
Does not eliminate page faults nor make TensorFlow batches zero-copy.
"""
import hashlib, json, os, shutil, tempfile, fcntl, time
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path

def key_for(snapshot_id, split, rows, image_size):
    payload=json.dumps({'snapshot':snapshot_id,'split':split,'size':image_size,
       'items':[(int(r['image_id']),int(r['food_class_id']),r['hash']) for r in rows]},
       sort_keys=True,separators=(',',':')).encode()
    return hashlib.sha256(payload).hexdigest()

@contextmanager
def cache_lock(root, key):
    with open(root / (key + '.lock'), 'a+b') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:yield
        finally:fcntl.flock(lock.fileno(), fcntl.LOCK_UN)

def build_tensor(snapshot_id, split, rows, class_indices, image_size, root, on_progress=None):
    import numpy as np
    from app.trainer.core import verified_images
    root=Path(root).resolve()
    root.mkdir(parents=True,exist_ok=True)
    key=key_for(snapshot_id,split,rows,image_size)
    target=root/key
    marker=target/'ready.json'
    with cache_lock(root,key):
        if marker.is_file():
            meta=json.loads(marker.read_text())
            if (meta.get('key')==key and meta.get('count')==len(rows)
                and (target/'images.npy').is_file() and (target/'labels.npy').is_file()):
                if on_progress:on_progress(len(rows),len(rows))
                return target
        if target.exists():
            raise RuntimeError('Invalid tensor cache: '+str(target))
        tmp=Path(tempfile.mkdtemp(prefix='.packing-',dir=root))
        try:
            x=np.lib.format.open_memmap(tmp/'images.npy',mode='w+',dtype='float32',
                                         shape=(len(rows),image_size,image_size,3))
            y=np.lib.format.open_memmap(tmp/'labels.npy',mode='w+',dtype='int32',shape=(len(rows),))
            # Bound pending decoded images to avoid OOM on large datasets.
            workers=max(1,min(16,int(os.getenv('CACHE_PREPROCESS_WORKERS','4'))))
            chunk_size=max(1,workers*2)
            started=time.monotonic()
            def decode_one(row):
                return next(verified_images([row],class_indices,image_size))
            with ThreadPoolExecutor(max_workers=workers) as pool:
                for offset in range(0,len(rows),chunk_size):
                    subset=rows[offset:offset+chunk_size]
                    for j,(arr,label) in enumerate(pool.map(decode_one,subset)):
                        x[offset+j]=arr; y[offset+j]=label
                    if on_progress:on_progress(min(offset+len(subset),len(rows)),len(rows))
                    if (offset//chunk_size)%max(1,1000//chunk_size)==0 or offset+len(subset)==len(rows):
                        print(f'CACHE | {split} | {min(offset+len(subset),len(rows))}/{len(rows)} | '
                              f'{time.monotonic()-started:.1f}s',flush=True)
            x.flush();y.flush();del x,y
            (tmp/'ready.json').write_text(json.dumps({'key':key,'size':image_size,'count':len(rows)}))
            os.rename(tmp,target)
            return target
        finally:
            if tmp.exists():shutil.rmtree(tmp)

def mmap_dataset(tf, target, batch_size, seed, training):
    import numpy as np
    x=np.load(Path(target)/'images.npy',mmap_mode='r')
    y=np.load(Path(target)/'labels.npy',mmap_mode='r')
    if len(x)!=len(y):raise RuntimeError('Tensor cache shape mismatch')
    order=np.arange(len(y))
    if training:np.random.default_rng(seed).shuffle(order)
    ds=tf.data.Dataset.from_tensor_slices(order).batch(batch_size)
    def fetch_batch(indices):
        def take(arr_indices):
            ids=np.asarray(arr_indices,dtype=np.int64)
            return np.asarray(x[ids],dtype=np.float32),np.asarray(y[ids],dtype=np.int32)
        images,labels=tf.numpy_function(take,[indices],[tf.float32,tf.int32])
        images.set_shape((None,*x.shape[1:]))
        labels.set_shape((None,))
        return images,labels
    ds=ds.map(fetch_batch,num_parallel_calls=max(1,min(4,int(os.getenv('DATASET_PARALLEL_BATCHES','2')))))
    return ds.prefetch(tf.data.AUTOTUNE)



def cached_samples(target, *, expected_count=None):
    """Read immutable TEST tensor cache, including labels, without touching source JPEGs."""
    import numpy as np
    target=Path(target)
    marker=target/'ready.json'
    if not marker.is_file():
        raise RuntimeError('TEST tensor cache missing; preflight was not completed')
    meta=json.loads(marker.read_text())
    x=np.load(target/'images.npy',mmap_mode='r',allow_pickle=False)
    y=np.load(target/'labels.npy',mmap_mode='r',allow_pickle=False)
    if len(x)!=len(y) or len(x)!=meta['count'] or (expected_count is not None and len(x)!=expected_count):
        raise RuntimeError('TEST cache count/manifest mismatch')
    if len(x)==0:raise RuntimeError('TEST cache empty')
    for idx in range(len(x)):
        yield np.asarray(x[idx],dtype=np.float32),int(y[idx])
