"""Worker entry point: python -m app.trainer.run JOB_ID FENCING_TOKEN"""
import json
import os
import sys
from pathlib import Path

def main():
    if len(sys.argv)!=3:raise SystemExit('Usage: python -m app.trainer.run JOB_ID TOKEN')
    job_id=int(sys.argv[1]); token=int(sys.argv[2])
    from app.trainer.core import train, get_rows
    from app.trainer.export import export_and_compare
    from app.trainer.lease import assert_lease
    from app.main import engine
    from app.platform import ARTIFACT_ROOT
    from sqlalchemy import text
    with engine.connect() as conn:
        sid=conn.execute(text('SELECT snapshot_id FROM training_job WHERE id=:id'), {'id':job_id}).scalar_one()
    result=train(job_id,token)
    test=get_rows(sid,'TEST')
    classes={x['foodClassId']:x['index'] for x in result['classes']}
    from app.trainer.tensor_cache import key_for, cached_samples
    cache_root=Path(os.getenv('TENSOR_CACHE_ROOT','./tensor-cache')).resolve()
    cache_dir=cache_root/key_for(sid,'TEST',test,result['imageSize'])
    samples=cached_samples(cache_dir,expected_count=len(test))
    if not test:
        raise RuntimeError('TEST split has no holdout images; cannot publish release')
    out=Path(result['model']).parent/'model.tflite'
    validated=export_and_compare(result['model'],out,image_size=result['imageSize'],samples=samples)
    if not validated['passed']:
        raise RuntimeError('HOLDOUT_QUALITY_GATE_FAILED: '+json.dumps(validated,ensure_ascii=False))
    assert_lease(job_id,token)
    print(json.dumps({'trained':True,'kerasModel':result['model'],'tfliteModel':str(out),
         'validation':validated,'metrics':result['metrics']},ensure_ascii=False),flush=True)
if __name__=='__main__': main()
