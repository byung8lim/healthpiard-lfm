"""Offline mobile SQLite nutrition payload, keyed by food class ID."""
import sqlite3
from pathlib import Path

def build(path, items):
    path=Path(path)
    if path.exists():raise FileExistsError(path)
    conn=sqlite3.connect(path)
    try:
        conn.execute('CREATE TABLE nutrition (food_class_id INTEGER PRIMARY KEY, version_no INTEGER, serving_g TEXT, calories_kcal TEXT)')
        conn.executemany('INSERT INTO nutrition VALUES (?,?,?,?)',[(int(i['foodClassId']),i['nutritionVersion'],i['servingG'],i['caloriesKcal']) for i in items])
        conn.commit()
    finally:conn.close()
