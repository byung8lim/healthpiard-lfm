"""Explicitly invoked, CPU-oriented trainer and TFLite exporter."""
