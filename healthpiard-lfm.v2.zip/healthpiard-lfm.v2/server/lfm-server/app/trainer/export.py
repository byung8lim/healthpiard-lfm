"""V022: compare a numerically faithful float32 TFLite artifact, not default weight quantization.
Quality gates return measured status, while genuine conversion/runtime errors remain fatal.
"""
import hashlib
import json
import os
from pathlib import Path

def export_and_compare(keras_path, output_path, *, image_size, samples, tolerance=None, min_accuracy=None):
    os.environ.setdefault('CUDA_VISIBLE_DEVICES','-1')
    # Enforce quality at export as well as the release endpoint.
    if min_accuracy is None: min_accuracy=float(os.getenv("MIN_RELEASE_HOLDOUT_ACCURACY", "0.70"))
    if not 0 < min_accuracy <= 1: raise ValueError("Invalid minimum holdout accuracy")
    if tolerance is None:tolerance=float(os.getenv('MAX_TFLITE_ABSOLUTE_ERROR','0.02'))
    min_agreement=float(os.getenv('MIN_TOP1_AGREEMENT','0.70'))
    min_top3=float(os.getenv('MIN_RELEASE_TOP3_ACCURACY','0.70'))
    for v in (min_agreement,min_top3):
        if not 0<=v<=1:raise ValueError('Invalid validation policy threshold')
    import numpy as np
    import tensorflow as tf
    model=tf.keras.models.load_model(keras_path,compile=False)
    converter=tf.lite.TFLiteConverter.from_keras_model(model)
    # Float32 is the primary reliable mobile release. Quantization requires a
    # separate representative dataset and independent accuracy certification.
    converter.target_spec.supported_types=[tf.float32]
    data=converter.convert()
    p=Path(output_path)
    p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_suffix('.tmp')
    temp.write_bytes(data)
    interpreter=tf.lite.Interpreter(model_path=str(temp),num_threads=2)
    interpreter.allocate_tensors()
    input_detail=interpreter.get_input_details()[0]
    output_detail=interpreter.get_output_details()[0]
    if tuple(input_detail['shape'][1:])!=(image_size,image_size,3):
        raise RuntimeError('Wrong TFLite input dimensions')
    if input_detail['dtype']!=np.float32 or output_detail['dtype']!=np.float32:
        raise RuntimeError('Expected float32 TFLite input/output')
    max_error=0.0
    count=agreement=correct=correct_top3=keras_correct=0
    disagreements=[]
    per_class={}
    for arr,label in samples:
        batch=np.expand_dims(arr,0).astype(np.float32)
        native=np.asarray(model(batch,training=False))
        interpreter.set_tensor(input_detail['index'],batch)
        interpreter.invoke()
        mobile=interpreter.get_tensor(output_detail['index'])
        if native.shape!=mobile.shape:raise RuntimeError('Output classes mismatch')
        delta=float(np.max(np.abs(native-mobile)))
        max_error=max(max_error,delta)
        keras_pred=int(np.argmax(native))
        mobile_pred=int(np.argmax(mobile))
        if keras_pred!=mobile_pred and len(disagreements)<100:
            disagreements.append({'ordinal':count,'expectedLabel':int(label),
                 'kerasClass':keras_pred,'tfliteClass':mobile_pred,
                 'kerasConfidence':float(native[0,keras_pred]),
                 'tfliteConfidence':float(mobile[0,mobile_pred]),'maxAbsoluteError':delta})
        stat=per_class.setdefault(int(label), {"total":0,"correct":0})
        stat["total"]+=1
        stat["correct"]+=int(mobile_pred==int(label))
        agreement+=int(keras_pred==mobile_pred)
        keras_correct+=int(keras_pred==int(label))
        correct+=int(mobile_pred==int(label))
        k=min(3,int(mobile.shape[-1]))
        correct_top3+=int(int(label) in np.argsort(mobile[0])[-k:])
        count+=1
    if not count:raise RuntimeError('At least one holdout test sample required')
    accuracy=correct/count
    top3_accuracy=correct_top3/count
    agreement_rate=agreement/count
    numeric_pass=max_error<=tolerance
    min_per_class=int(os.getenv('MIN_HOLDOUT_PER_CLASS','9'))
    min_class_accuracy=float(os.getenv('MIN_CLASS_HOLDOUT_ACCURACY','0.70'))
    if min_per_class < 1 or not 0 < min_class_accuracy <= 1:
        raise ValueError('Invalid per-class quality policy')
    by_class={str(k):dict(v,accuracy=v['correct']/v['total']) for k,v in sorted(per_class.items())}
    expected_classes=int(model.output_shape[-1])
    class_gate=(len(per_class)==expected_classes and all(
        v['total']>=min_per_class and v['correct']/v['total']>=min_class_accuracy
        for v in per_class.values()))
    passed=(agreement_rate>=min_agreement and numeric_pass and accuracy>=min_accuracy and top3_accuracy>=min_top3 and class_gate)
    diagnostics={'disagreements':disagreements,'kerasHoldoutAccuracy':keras_correct/count,
                 'float32Conversion':True,'maxAllowedAbsoluteError':tolerance,
                 'numericConversionPassed':numeric_pass,'holdoutAccuracy':accuracy,
                 'minimumAccuracy':min_accuracy,'top3Accuracy':top3_accuracy,'minimumTop3Accuracy':min_top3,'top1Agreement':agreement_rate,'passed':passed,'testSamples':count,
                 'classGatePassed':class_gate,'minimumHoldoutPerClass':min_per_class,
                 'minimumClassAccuracy':min_class_accuracy,'perClass':by_class}
    p.with_name('export_diagnostics.json').write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2))
    # Never emit a valid-looking release artifact on failed quality gates.
    if passed:
        os.replace(temp,p)
    else:
        temp.unlink(missing_ok=True)
        p.unlink(missing_ok=True)

    return {'passed':passed,'top3Accuracy':top3_accuracy,'minimumTop3Accuracy':min_top3,
      'minimumTop1Agreement':min_agreement,'holdoutAccuracy':accuracy,'accuracyGateEnabled':True,
      'kerasHoldoutAccuracy':keras_correct/count,'minimumAccuracy':min_accuracy,
      'testSamples':count,'classGatePassed':class_gate,'perClass':by_class,
      'minimumHoldoutPerClass':min_per_class,'minimumClassAccuracy':min_class_accuracy,'maxAbsoluteError':max_error,'maximumAllowedAbsoluteError':tolerance,
      'numericConversionPassed':numeric_pass,'top1Agreement':agreement_rate,
      'sha256':hashlib.sha256(data).hexdigest()}
