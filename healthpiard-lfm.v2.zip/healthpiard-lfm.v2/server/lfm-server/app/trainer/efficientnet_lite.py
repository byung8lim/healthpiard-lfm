"""Keras 3 EfficientNet-Lite0 with the official TensorFlow ImageNet checkpoint.

Architecture reference: tensorflow/tpu models/official/efficientnet/lite.
Uses only built-in Keras layers so saved checkpoints need no custom objects.
"""
import os
import tarfile
from pathlib import Path

WEIGHTS_URL = 'https://storage.googleapis.com/cloud-tpu-checkpoints/efficientnet/lite/efficientnet-lite0.tar.gz'
WEIGHTS_SHA256 = '9949101418ad69ec4639bfadd526e86793da6f59ae511bb01671f5b41c331374'


def checkpoint_path(tf):
    override = os.getenv('EFFICIENTNET_LITE0_CHECKPOINT')
    if override:
        if not Path(override + '.index').is_file():
            raise RuntimeError('EfficientNet-Lite0 checkpoint index missing')
        return override
    archive = Path(tf.keras.utils.get_file(
        'efficientnet-lite0-official.tar.gz', WEIGHTS_URL,
        file_hash=WEIGHTS_SHA256, hash_algorithm='sha256', cache_subdir='models'))
    root = archive.parent / 'efficientnet-lite0'
    root.mkdir(exist_ok=True)
    # Extract only known regular checkpoint members, never archive paths.
    with tarfile.open(archive) as source:
        for filename in ('model.ckpt.index', 'model.ckpt.data-00000-of-00001'):
            member = source.getmember('efficientnet-lite0/' + filename)
            if not member.isfile():
                raise RuntimeError('Invalid official checkpoint archive')
            target = root / filename
            temp = target.with_suffix(target.suffix + '.partial')
            temp.write_bytes(source.extractfile(member).read())
            os.replace(temp, target)
    return str(root / 'model.ckpt')


def build_backbone(tf, image_size=224, pretrained=True):
    layers = tf.keras.layers
    inputs = layers.Input((image_size, image_size, 3), name='images')
    # Public input remains pixel/127.5-1. Official weights use (pixel-127)/128.
    x = layers.Rescaling(127.5 / 128., .5 / 128., name='lite0_normalization')(inputs)
    bindings = []

    def conv(x, filters, kernel, stride, name, scope, depthwise=False):
        if depthwise:
            layer = layers.DepthwiseConv2D(kernel, strides=stride, padding='same',
                                          use_bias=False, name=name)
            variable = 'depthwise_kernel'
        else:
            layer = layers.Conv2D(filters, kernel, strides=stride, padding='same',
                                  use_bias=False, name=name)
            variable = 'kernel'
        bindings.append((layer, [scope + '/' + variable]))
        return layer(x)

    def bn(x, name, scope):
        layer = layers.BatchNormalization(momentum=.99, epsilon=1e-3, name=name)
        bindings.append((layer, [scope + '/' + v for v in
                                ('gamma', 'beta', 'moving_mean', 'moving_variance')]))
        return layer(x)

    def relu(x, name):
        return layers.ReLU(max_value=6., name=name)(x)

    prefix = 'efficientnet-lite0/'
    x = conv(x, 32, 3, 2, 'lite0_stem_conv', prefix + 'stem/conv2d')
    x = relu(bn(x, 'lite0_stem_bn', prefix + 'stem/tpu_batch_normalization'), 'lite0_stem_relu')
    block = 0
    # repeats, kernel, first stride, expansion, output channels
    for repeats, kernel, stride, expansion, channels in (
        (1, 3, 1, 1, 16), (2, 3, 2, 6, 24), (2, 5, 2, 6, 40),
        (3, 3, 2, 6, 80), (3, 5, 1, 6, 112), (4, 5, 2, 6, 192),
        (1, 3, 1, 6, 320),
    ):
        for repeat in range(repeats):
            step = stride if repeat == 0 else 1
            shortcut = x
            incoming = int(x.shape[-1])
            name = f'lite0_block{block}'
            scope = prefix + f'blocks_{block}/'
            if expansion != 1:
                x = conv(x, incoming * expansion, 1, 1, name + '_expand', scope + 'conv2d')
                x = relu(bn(x, name + '_expand_bn', scope + 'tpu_batch_normalization'), name + '_expand_relu')
            x = conv(x, None, kernel, step, name + '_depthwise', scope + 'depthwise_conv2d', True)
            bn_index = 1 if expansion != 1 else 0
            bn_scope = 'tpu_batch_normalization' + (f'_{bn_index}' if bn_index else '')
            x = relu(bn(x, name + '_depthwise_bn', scope + bn_scope), name + '_depthwise_relu')
            projection = 'conv2d_1' if expansion != 1 else 'conv2d'
            x = conv(x, channels, 1, 1, name + '_project', scope + projection)
            x = bn(x, name + '_project_bn', scope + f'tpu_batch_normalization_{bn_index + 1}')
            if step == 1 and incoming == channels:
                x = layers.Dropout(.2 * block / 16, noise_shape=(None, 1, 1, 1),
                                   name=name + '_drop_connect')(x)
                x = layers.Add(name=name + '_add')([shortcut, x])
            block += 1
    x = conv(x, 1280, 1, 1, 'lite0_head_conv', prefix + 'head/conv2d')
    x = relu(bn(x, 'lite0_head_bn', prefix + 'head/tpu_batch_normalization'), 'lite0_head_relu')
    x = layers.GlobalAveragePooling2D(name='lite0_pool')(x)
    model = tf.keras.Model(inputs, x, name='efficientnet_lite0_backbone')
    if pretrained:
        reader = tf.train.load_checkpoint(checkpoint_path(tf))
        for layer, names in bindings:
            values = []
            for name in names:
                # Official evaluation restores exponential-moving-average weights.
                ema = name + '/ExponentialMovingAverage'
                if not reader.has_tensor(ema):
                    raise RuntimeError('Official checkpoint tensor missing: ' + ema)
                values.append(reader.get_tensor(ema))
            layer.set_weights(values)  # Exact shape check; never silently skip weights.
    return model
