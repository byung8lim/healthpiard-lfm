"""Fail-closed split integrity checks; only identity hashes, no TF dependency."""
from collections import Counter, defaultdict


def validate_snapshot_splits(train, validation, test, classes, *, minimum_train=1):
    splits={'TRAIN':train,'VALIDATION':validation,'TEST':test}
    known={int(c['foodClassId']) for c in classes}
    if not known: raise ValueError('No classes configured')
    seen={}
    counts={}
    for name, rows in splits.items():
        counts[name]=Counter()
        if not rows: raise ValueError(f'{name} split is empty')
        for row in rows:
            image_id=int(row['image_id'])
            label=int(row['food_class_id'])
            sha=str(row['hash']).lower()
            if label not in known: raise ValueError(f'{name}: unknown class id {label}')
            if len(sha)!=64 or any(c not in '0123456789abcdef' for c in sha):
                raise ValueError(f'{name}: invalid SHA-256 for image {image_id}')
            for key in (('image',image_id),('sha',sha)):
                if key in seen:
                    raise ValueError(f'Dataset leakage/duplicate {key[0]} between {seen[key]} and {name}: {key[1]}')
                seen[key]=name
            counts[name][label]+=1
    for label in known:
        if counts['TRAIN'][label]<minimum_train: raise ValueError(f'Insufficient TRAIN images for class {label}')
        if counts['VALIDATION'][label]<1: raise ValueError(f'Missing VALIDATION images for class {label}')
        if counts['TEST'][label]<1: raise ValueError(f'Missing TEST images for class {label}')
    return {name:{str(k):v for k,v in sorted(counter.items())} for name,counter in counts.items()}
