"""TensorFlow/Keras CPU trainer for immutable MySQL dataset snapshots.

Executed ONLY by lease-owning worker. No training is coupled to feeder ingestion.
Optional dependency: tensorflow-cpu 2.18.x; Python 3.11 supported.
"""
from __future__ import annotations
import gc
import hashlib
import json
import os
import random
import time
from pathlib import Path

from sqlalchemy import text
from app.main import engine, OBJECT_ROOT, one
from app.platform import ARTIFACT_ROOT

TRAIN_ROOT = Path(os.getenv('TRAIN_ROOT', './training-runs')).resolve()


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def classes_for_snapshot(conn, snapshot_id):
    rows = conn.execute(text('''SELECT DISTINCT s.food_class_id AS id, f.class_code AS code
      FROM dataset_snapshot_item s JOIN food_class f ON f.id=s.food_class_id
      WHERE s.snapshot_id=:sid ORDER BY s.food_class_id'''), {'sid':snapshot_id}).mappings().all()
    if not rows:
        raise RuntimeError('Snapshot has no classes')
    return [{'index':i, 'foodClassId':r['id'], 'classCode':r['code']} for i,r in enumerate(rows)]


def load_job(job_id, token):
    with engine.connect() as conn:
        job = one(conn, '''SELECT id,snapshot_id,model_family,base_release_id,config_json,checkpoint_key
               FROM training_job WHERE id=:id AND fencing_token=:t AND status='RUNNING'
               AND cancel_requested=0 AND lease_until > UTC_TIMESTAMP(6)''', {'id':job_id,'t':token})
        if not job: raise RuntimeError('Worker lease/fencing token invalid')
        classes=classes_for_snapshot(conn,job['snapshot_id'])
        config=job['config_json']
        if isinstance(config,str): config=json.loads(config)
        return dict(job),classes,config


def get_rows(snapshot_id, split):
    with engine.connect() as conn:
        return [dict(r) for r in conn.execute(text('''SELECT image_id,food_class_id,
                HEX(sha256) AS hash,storage_key FROM dataset_snapshot_item
                WHERE snapshot_id=:sid AND split=:split ORDER BY image_id'''),
                {'sid':snapshot_id,'split':split}).mappings()]


def verified_images(rows, index_by_class, image_size):
    """Streaming generator, opens and closes at most one image at a time."""
    import numpy as np
    from PIL import Image, ImageOps
    for r in rows:
        path=(OBJECT_ROOT / r['storage_key']).resolve()
        if not path.is_relative_to(OBJECT_ROOT) or not path.is_file():
            raise RuntimeError(f'Missing/unsafe image {r["image_id"]}')
        content=path.read_bytes()
        if hashlib.sha256(content).hexdigest()!=r['hash'].lower():
            raise RuntimeError(f'SHA mismatch image {r["image_id"]}')
        from app.inference_contract import preprocess_image
        arr=preprocess_image(content,image_size)
        yield arr, index_by_class[r['food_class_id']]


def dataset(rows, index_by_class, image_size, batch_size, seed, training):
    import tensorflow as tf
    import numpy as np
    if training:
        rows=list(rows)
        random.Random(seed).shuffle(rows)
    signature=(tf.TensorSpec((image_size,image_size,3),tf.float32),tf.TensorSpec((),tf.int32))
    ds=tf.data.Dataset.from_generator(lambda:verified_images(rows,index_by_class,image_size),output_signature=signature)
    # Bounded memory; no unbounded in-memory dataset cache.
    options=tf.data.Options()
    options.threading.private_threadpool_size=2
    ds=ds.with_options(options)
    return ds.batch(batch_size).prefetch(1)


def build_model(tf, count, image_size, pretrained=True, model_family='mobilenet_v3_large'):
    if model_family == 'efficientnet_lite0':
        from app.trainer.efficientnet_lite import build_backbone
        backbone = build_backbone(tf, image_size, pretrained=pretrained)
        x = tf.keras.layers.Dropout(.2, name='lite0_classifier_dropout')(backbone.output)
        logits = tf.keras.layers.Dense(count, activation='softmax', name='food_logits')(x)
        return tf.keras.Model(backbone.input, logits, name='efficientnet_lite0')
    if model_family != 'mobilenet_v3_large':
        raise ValueError('Unsupported model family: ' + model_family)
    # Input is already normalized to [-1,1]; include_preprocessing=False avoids double scaling.
    backbone=tf.keras.applications.MobileNetV3Large(input_shape=(image_size,image_size,3),
             include_top=False,weights='imagenet' if pretrained else None,include_preprocessing=False,pooling='avg')
    x=tf.keras.layers.Dropout(.30,name='classifier_dropout')(backbone.output)
    logits=tf.keras.layers.Dense(count,activation='softmax',name='food_logits')(x)
    model=tf.keras.Model(backbone.input,logits)
    return model


def configure_phase(tf, model, phase, unfreeze_last=40):
    """Never freeze random features: call with a verified pretrained backbone."""
    candidates=[l for l in model.layers if l.name!='food_logits' and not isinstance(l,tf.keras.layers.BatchNormalization)]
    enabled=set(l.name for l in candidates[-max(1,unfreeze_last):]) if phase=='finetune' else set()
    for layer in model.layers:
        layer.trainable=(layer.name=='food_logits' or layer.name in enabled)
        if isinstance(layer,tf.keras.layers.BatchNormalization):layer.trainable=False

def augment_batches(tf, ds, seed):
    # Applied to TRAIN only, after loading cached floats [-1,1]; not to holdout.
    aug=tf.keras.Sequential([
        tf.keras.layers.RandomFlip('horizontal',seed=seed),
        tf.keras.layers.RandomRotation(.08,fill_mode='reflect',seed=seed+1),
        tf.keras.layers.RandomZoom(.10,fill_mode='reflect',seed=seed+2),
        tf.keras.layers.RandomContrast(.12,seed=seed+3),
    ])
    def transform(x,y):
        return tf.clip_by_value(aug(x,training=True),-1.,1.),y
    return ds.map(transform,num_parallel_calls=1).prefetch(1)


def transplant_head(tf, model, old_model, old_classes, new_classes):
    """Class-ID based transfer; new classes receive random head weights.

    Reuses backbone when shapes match, protecting existing class index semantics.
    """
    source={int(c['foodClassId']):int(c['index']) for c in old_classes}
    for layer in model.layers:
        if layer.name=='food_logits':continue
        try:
            prev=old_model.get_layer(layer.name)
            if [tuple(x.shape) for x in layer.get_weights()]==[tuple(x.shape) for x in prev.get_weights()]:
                layer.set_weights(prev.get_weights())
        except ValueError: pass
    new_head=model.get_layer('food_logits')
    old_head=old_model.get_layer('food_logits')
    new_w,new_b=new_head.get_weights()
    old_w,old_b=old_head.get_weights()
    for c in new_classes:
        old_index=source.get(int(c['foodClassId']))
        if old_index is not None and old_w.shape[0]==new_w.shape[0] and old_index<old_w.shape[1]:
            new_w[:,c['index']]=old_w[:,old_index]
            new_b[c['index']]=old_b[old_index]
    new_head.set_weights([new_w,new_b])


def train(job_id:int, token:int):
    # Avoid allocating TensorFlow runtime on feeder web server process.
    os.environ.setdefault('CUDA_VISIBLE_DEVICES','-1')
    os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','2')
    os.environ.setdefault('TF_NUM_INTEROP_THREADS','2')
    os.environ.setdefault('TF_NUM_INTRAOP_THREADS',str(max(1,int(os.getenv('LFM_CPU_CORES',os.cpu_count() or 2)))))
    import tensorflow as tf
    job,classes,config=load_job(job_id,token)
    if job['model_family'] not in ('mobilenet_v3_large','efficientnet_lite0'):
        raise RuntimeError(f'No verified trainer for {job["model_family"]}; refusing fake training')
    telemetry_path=TRAIN_ROOT / ('snapshot-'+str(job['snapshot_id'])) / ('job-'+str(job_id)) / 'progress.json'
    job_started=time.monotonic()
    def progress(phase,**attrs):
        telemetry_path.parent.mkdir(parents=True,exist_ok=True)
        data={'jobId':job_id,'snapshotId':job['snapshot_id'],'phase':phase,
              'elapsedSeconds':round(time.monotonic()-job_started,1),
              'updatedAt':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),**attrs}
        temp=telemetry_path.with_suffix('.partial')
        temp.write_text(canonical(data),encoding='utf8')
        os.replace(temp,telemetry_path)
    epochs=int(config.get('epochs',30))
    batch=int(config.get('batchSize',8))
    family=job['model_family']
    size=int(config.get('imageSize',224 if family=='efficientnet_lite0' else 192))
    lr=float(config.get('learningRate',0.001))
    finetune_lr=float(config.get('finetuneLearningRate',1e-4))
    if not 1e-7 <= finetune_lr <= 1e-3: raise ValueError('Invalid fine-tune learning rate')
    if not (1<=epochs<=500 and 1<=batch<=128 and size in (128,160,192,224) and 0<lr<=0.01):
        raise ValueError('Unsafe trainer configuration')
    tf.random.set_seed(42)
    root=TRAIN_ROOT / ('snapshot-'+str(job['snapshot_id'])) / ('job-'+str(job_id))
    root.mkdir(parents=True,exist_ok=True)
    state_path=root/'state.json'
    model_path=root/'checkpoint.keras'
    class_path=root/'class_index.json'
    if class_path.exists() and json.loads(class_path.read_text())!=classes:
        raise RuntimeError('Checkpoint class mapping differs from immutable snapshot')
    class_path.write_text(canonical(classes),encoding='utf8')
    by_id={c['foodClassId']:c['index'] for c in classes}
    tr=get_rows(job['snapshot_id'],'TRAIN')
    va=get_rows(job['snapshot_id'],'VALIDATION')
    if not tr:raise RuntimeError('Snapshot TRAIN empty')
    if not va:raise RuntimeError('Snapshot VALIDATION empty; required for model selection')
    # V023: validate and freeze TEST images *before* any CPU training.
    # Export must never depend on late re-reading of mutable original files.
    te=get_rows(job['snapshot_id'],'TEST')
    if not te:raise RuntimeError('TEST split empty: cannot verify mobile release')
    from app.trainer.data_integrity import validate_snapshot_splits
    split_diagnostics=validate_snapshot_splits(tr, va, te, classes)
    (root/'split_integrity.json').write_text(canonical(split_diagnostics),encoding='utf8')
    from app.trainer.tensor_cache import build_tensor
    cache_root=Path(os.getenv('TENSOR_CACHE_ROOT','./tensor-cache')).resolve()
    progress('PREFLIGHT_TEST',processed=0,total=len(te),epochs=epochs,completedEpochs=0)
    build_tensor(job['snapshot_id'],'TEST',te,by_id,size,cache_root,
                 on_progress=lambda processed,total:progress('PREFLIGHT_TEST',processed=processed,total=total,epochs=epochs,completedEpochs=0))

    # Fail fast on class imbalance and absent training/validation labels.
    from collections import Counter
    train_counts=Counter(r['food_class_id'] for r in tr)
    val_counts=Counter(r['food_class_id'] for r in va)
    missing=[c['foodClassId'] for c in classes if not train_counts[c['foodClassId']] or not val_counts[c['foodClassId']]]
    if missing:raise RuntimeError(f'Classes absent from TRAIN or VALIDATION: {missing[:30]}')
    (root/'dataset_diagnostics.json').write_text(canonical({
        'trainImages':len(tr),'validationImages':len(va),'classes':len(classes),
        'minimumTrainPerClass':min(train_counts.values()),
        'maximumTrainPerClass':max(train_counts.values()),
        'trainPerClass':{str(k):v for k,v in train_counts.items()},
        'validationPerClass':{str(k):v for k,v in val_counts.items()}}),encoding='utf8')
    start_epoch=0
    state={}
    if model_path.exists() != state_path.exists():
        raise RuntimeError('Incomplete checkpoint state; operator intervention required')
    if model_path.exists() and state_path.exists():
        state=json.loads(state_path.read_text())
        expected_mapping_hash=hashlib.sha256(canonical(classes).encode()).hexdigest()
        if state.get('classMappingHash') != expected_mapping_hash:
            raise RuntimeError('Checkpoint manifest/class mapping mismatch; refusing unsafe resume')
        start_epoch=int(state.get('completedEpochs',0))
        batch=int(state.get('batchSize',batch))
        model=tf.keras.models.load_model(model_path,compile=False)
        is_lite=any(layer.name=='lite0_stem_conv' for layer in model.layers)
        if is_lite != (family=='efficientnet_lite0') or tuple(model.input_shape[1:]) != (size,size,3):
            raise RuntimeError('Checkpoint model family/input size mismatch; create a new job')
        if (state.get('epochs',epochs)!=epochs or state.get('warmupEpochs',min(5,epochs))!=int(config.get('warmupEpochs',min(5,epochs)))
            or state.get('learningRate',lr)!=lr or state.get('finetuneLearningRate',finetune_lr)!=finetune_lr):
            raise RuntimeError('Resume hyperparameters differ from checkpoint; start a new training job')
        if state.get('modelFamily',family)!=family or state.get('imageSize',size)!=size:
            raise RuntimeError('Checkpoint training configuration mismatch')
    else:
        base=job['base_release_id']
        if base:
            with engine.connect() as conn:
                base_family=conn.execute(text('''SELECT j.model_family FROM model_release r
                    JOIN training_job j ON j.id=r.job_id WHERE r.id=:id'''),{'id':base}).scalar_one()
            if base_family!=family:
                raise RuntimeError('Base release model family differs; initialize from ImageNet instead')
        local_weights=os.getenv('IMAGENET_WEIGHTS_PATH') if family=='mobilenet_v3_large' else None
        if local_weights and not Path(local_weights).is_file():
            raise RuntimeError('Configured ImageNet weights file does not exist')
        # Fail-closed pretrained transfer; explicit local weights are loaded below.
        model=build_model(tf,len(classes),size,pretrained=(not base and not local_weights),model_family=family)
        if base:
            base_root=ARTIFACT_ROOT/str(base)
            old_path=base_root/'training_model.keras'
            old_index=base_root/'class_index.json'
            if not old_path.is_file() or not old_index.is_file():
                raise RuntimeError('Approved base release lacks reusable Keras model')
            old_model=tf.keras.models.load_model(old_path,compile=False)
            old_classes=json.loads(old_index.read_text())['classes']
            transplant_head(tf,model,old_model,old_classes,classes)
            del old_model
        # Train classifier head before unfreezing backbone. No fake pretrained weights.
        # For initial training, ImageNet weights MUST be provisioned locally or training from scratch is explicit.
        elif local_weights:
            pretrained=tf.keras.applications.MobileNetV3Large(input_shape=(size,size,3),
                     include_top=False,weights=None,include_preprocessing=False,pooling='avg')
            pretrained.load_weights(local_weights)
            copied=0
            for layer in model.layers:
                if not layer.weights: continue
                try:
                    old=pretrained.get_layer(layer.name)
                except ValueError:
                    if layer.name in ('food_logits','classifier_dropout'): continue
                    raise RuntimeError(f'Missing pretrained layer: {layer.name}')
                if [tuple(w.shape) for w in old.get_weights()] != [tuple(w.shape) for w in layer.get_weights()]:
                    raise RuntimeError(f'Pretrained shape mismatch: {layer.name}')
                layer.set_weights(old.get_weights()); copied+=1
            if copied < 100: raise RuntimeError(f'Insufficient pretrained layers loaded: {copied}')
            del pretrained
    # V021: ImageNet pretrained on fresh jobs; never train an uninitialized frozen backbone.
    warmup=int(config.get('warmupEpochs',min(5,epochs)))
    unfreeze_last=int(config.get('unfreezeLastLayers',40))
    if not (1<=warmup<epochs and 1<=unfreeze_last<=200):raise ValueError('Invalid training phase configuration')
    def compile_phase(phase, remaining):
        configure_phase(tf,model,phase,unfreeze_last)
        phase_lr=lr if phase=='warmup' else finetune_lr
        steps=max(1,((len(tr)+batch-1)//batch)*max(1,remaining))
        schedule=tf.keras.optimizers.schedules.CosineDecay(phase_lr,steps,alpha=.1)
        model.compile(optimizer=tf.keras.optimizers.AdamW(learning_rate=schedule,weight_decay=1e-5),
                      loss='sparse_categorical_crossentropy',metrics=['accuracy'])
    current_phase=None
    best_accuracy=float(state.get('bestValidationAccuracy',-1))
    best_path=root/'best_validation.keras'

    # Pre-pack validated data once per snapshot/split to avoid JPEG decoding per epoch.
    # Cache is disk-backed: 25k x 224 x 224 x 3 float32 ~ 14 GiB per split.
    from app.trainer.tensor_cache import build_tensor, mmap_dataset
    cache_root=Path(os.getenv('TENSOR_CACHE_ROOT','./tensor-cache')).resolve()
    progress('CACHE_TRAIN',processed=0,total=len(tr),epochs=epochs,completedEpochs=0,
             note='Image hashing and tensor preprocessing')
    train_cache=build_tensor(job['snapshot_id'],'TRAIN',tr,by_id,size,cache_root,
                             on_progress=lambda processed,total:progress('CACHE_TRAIN',processed=processed,total=total,epochs=epochs,completedEpochs=0))
    progress('CACHE_VALIDATION',processed=0,total=len(va),epochs=epochs,completedEpochs=0)
    validation_cache=build_tensor(job['snapshot_id'],'VALIDATION',va,by_id,size,cache_root,
                                  on_progress=lambda processed,total:progress('CACHE_VALIDATION',processed=processed,total=total,epochs=epochs,completedEpochs=0)) if va else None
    metrics={}
    epoch_durations=[]
    progress('TRAINING',epochs=epochs,completedEpochs=start_epoch,etaSeconds=None)
    for epoch in range(start_epoch,epochs):
        epoch_started=time.monotonic()
        from app.trainer.lease import assert_lease
        assert_lease(job_id,token)
        # Incomplete epoch is repeated on restart. A smaller batch is retried on TF ResourceExhaustedError.
        phase='warmup' if epoch<warmup else 'finetune'
        if phase!=current_phase:
            compile_phase(phase,(warmup-epoch if phase=='warmup' else epochs-epoch))
            current_phase=phase
        while True:
            try:
                train_ds=augment_batches(tf,mmap_dataset(tf,train_cache,batch,42+epoch,True),42+epoch)
                valid_ds=mmap_dataset(tf,validation_cache,batch,42+epoch,False) if va else None
                history=model.fit(train_ds,validation_data=valid_ds,epochs=1,verbose=2)
                metrics={k:float(v[-1]) for k,v in history.history.items()}
                break
            except tf.errors.ResourceExhaustedError:
                gc.collect()
                if batch<=1:raise
                batch=max(1,batch//2)
                # TensorFlow may retain allocated memory after a failed step;
                # restart from last checkpoint is the fully safe OOM recovery path.
                if model_path.exists():
                    model=tf.keras.models.load_model(model_path,compile=False)
                    compile_phase(phase, epochs-epoch)
        # Keep the best held-out validation model; final epoch is not necessarily best.
        val_accuracy=float(metrics.get('val_accuracy',-1))
        if val_accuracy > best_accuracy:
            best_accuracy=val_accuracy
            best_tmp=root/'best_validation.partial.keras'
            model.save(best_tmp)
            os.replace(best_tmp,best_path)
        tmp=root/'checkpoint.partial.keras'
        model.save(tmp)
        os.replace(tmp,model_path)
        state={'completedEpochs':epoch+1,'batchSize':batch,'metrics':metrics,
               'modelFamily':family,'imageSize':size,'epochs':epochs,'warmupEpochs':warmup,
               'learningRate':lr,'finetuneLearningRate':finetune_lr,
               'classMappingHash':hashlib.sha256(canonical(classes).encode()).hexdigest(), 'phase':phase, 'bestValidationAccuracy':best_accuracy}
        tmp_state=root/'state.partial.json'
        tmp_state.write_text(canonical(state),encoding='utf8')
        os.replace(tmp_state,state_path)
        epoch_durations.append(time.monotonic()-epoch_started)
        avg=sum(epoch_durations[-5:])/len(epoch_durations[-5:])
        progress('TRAINING',epochs=epochs,completedEpochs=epoch+1,
                 percent=round((epoch+1)/epochs*100,1),
                 epochSeconds=round(epoch_durations[-1],1),
                 etaSeconds=round((epochs-epoch-1)*avg),metrics=metrics)
        assert_lease(job_id,token)
    progress('EXPORT',epochs=epochs,completedEpochs=epochs,percent=100,note='Converting and validating mobile model')
    selected=best_path if best_path.is_file() else model_path
    return {'model':str(selected),'classes':classes,'metrics':metrics,
            'bestValidationAccuracy':best_accuracy,'imageSize':size}
