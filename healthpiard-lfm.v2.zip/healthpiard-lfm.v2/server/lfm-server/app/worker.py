"""DB lease worker; runs the packaged trainer only for admin-queued jobs."""
import json, os, socket, subprocess, sys, time, signal
from sqlalchemy import text
from app.main import engine, one
OWNER=f'{socket.gethostname()}:{os.getpid()}'
LEASE_SECONDS=int(os.getenv('LEASE_SECONDS','120'))
STOP_REQUESTED=False
def request_stop(signum, frame):
    global STOP_REQUESTED
    STOP_REQUESTED=True
signal.signal(signal.SIGTERM, request_stop)
signal.signal(signal.SIGINT, request_stop)

def claim():
    with engine.begin() as c:
        # Exhausted leases are terminally quarantined, not reclaimed forever.
        c.execute(text("""UPDATE training_job SET status='FAILED',lease_owner=NULL,lease_until=NULL,
             error_message='QUARANTINED: lease expired after max attempts; inspect OOM and logs'
             WHERE status='RUNNING' AND lease_until < UTC_TIMESTAMP(6)
             AND attempt >= max_attempts"""))
        # Exponential cool-down after dead worker, using updated_at as a DB-backed clock.
        row=one(c,"""SELECT id FROM training_job
          WHERE (status='QUEUED' OR (status='RUNNING' AND lease_until < UTC_TIMESTAMP(6)
            AND updated_at < DATE_SUB(UTC_TIMESTAMP(6), INTERVAL LEAST(3600,30*POW(2,attempt)) SECOND)))
          AND cancel_requested=0 AND attempt < max_attempts
          ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED""",{})
        if not row:return None
        c.execute(text("""UPDATE training_job SET status='RUNNING',lease_owner=:owner,
            lease_until=DATE_ADD(UTC_TIMESTAMP(6),INTERVAL :ttl SECOND),
            heartbeat_at=UTC_TIMESTAMP(6),attempt=attempt+1,fencing_token=fencing_token+1
            WHERE id=:id"""),dict(id=row['id'],owner=OWNER,ttl=LEASE_SECONDS))
        r=one(c,'SELECT id,fencing_token,snapshot_id,config_json,base_release_id FROM training_job WHERE id=:id',{'id':row['id']})
        return dict(r)

def heartbeat(job,checkpoint=None):
    with engine.begin() as c:
        r=c.execute(text("""UPDATE training_job SET heartbeat_at=UTC_TIMESTAMP(6),
           lease_until=DATE_ADD(UTC_TIMESTAMP(6),INTERVAL :ttl SECOND),
           checkpoint_key=COALESCE(:ck,checkpoint_key)
           WHERE id=:id AND fencing_token=:token AND lease_owner=:owner
           AND status='RUNNING' AND cancel_requested=0 AND lease_until > UTC_TIMESTAMP(6)"""),
           dict(ttl=LEASE_SECONDS,ck=checkpoint,id=job['id'],token=job['fencing_token'],owner=OWNER))
        return r.rowcount==1

def finish(job,success,result=None,error=None):
    with engine.begin() as c:
        r=c.execute(text("""UPDATE training_job SET status=:status,result_json=:result,
            error_message=:error,lease_until=NULL,lease_owner=NULL
            WHERE id=:id AND fencing_token=:token AND lease_owner=:owner
            AND status='RUNNING' AND cancel_requested=0 AND lease_until > UTC_TIMESTAMP(6)"""),
            dict(status='SUCCEEDED' if success else 'FAILED',result=json.dumps(result) if result else None,
                 error=error,id=job['id'],token=job['fencing_token'],owner=OWNER))
        return r.rowcount==1

def run_one(job):
    # Explicit separate process, NO automatic model training upon ingestion.
    # The packaged trainer is explicit: only admin-queued jobs are executed.
    # Spawn python executable with arguments, not user-controlled shell command.
    log_dir=os.path.abspath(os.getenv('WORKER_LOG_DIR','./worker-logs'))
    os.makedirs(log_dir,exist_ok=True)
    log_path=os.path.join(log_dir,f"job-{job['id']}-token-{job['fencing_token']}.log")
    log=open(log_path,'w+',encoding='utf-8')
    trainer_env=os.environ.copy()
    trainer_env['HEALTHPIARD_LEASE_OWNER']=OWNER
    p=subprocess.Popen([sys.executable,'-m','app.trainer.run',str(job['id']),str(job['fencing_token'])],stdout=log,stderr=subprocess.STDOUT,text=True,env=trainer_env)
    try:
        while p.poll() is None:
            if STOP_REQUESTED:
                p.terminate()
                try: p.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    p.kill(); p.wait()
                # Leave DB lease to expire; another worker may safely retry using fencing.
                return
            time.sleep(max(1,min(5,LEASE_SECONDS//4)))
            if not heartbeat(job):
                p.terminate()
                try:p.wait(timeout=10)
                except subprocess.TimeoutExpired:p.kill()
                return
        log.flush();log.seek(0)
        lines=log.readlines()
        result=None
        success=p.returncode==0
        if success:
            try: result=json.loads(lines[-1].strip())
            except (ValueError,IndexError):success=False
        finish(job,success,result=result if success else None,
               error=None if success else f"Trainer exit {p.returncode}; log: {log_path}; tail: {''.join(lines[-5:])[-1000:]}")
    finally:
        if p.poll() is None:p.kill()
        log.close()

def serve():
    while not STOP_REQUESTED:
        job=claim()
        if job:run_one(job)
        elif not STOP_REQUESTED:time.sleep(2)
if __name__=='__main__':serve()
