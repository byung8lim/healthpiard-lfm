# Healthpiard LFM V003 — development implementation

Scope: additive MySQL 8 schema, immutable dataset snapshots, admin quality/labels, job queue and lease worker, verified TFLite candidate packaging, release activation/rollback by selecting a previously approved release, release download API, static admin prototype.

## Files
- `db/migration/V001...V003...`: apply once, in ascending order, to a **backed-up staging MySQL 8** database. V003 uses MySQL DELIMITER syntax (mysql CLI). No DROP statements.
- `app/main.py`: V002 Feeder contract preserved; adds V003 router.
- `app/platform.py`: administrative and public APIs. Admin requires environment `ADMIN_TOKEN` and bearer header; deployment must add TLS, production authentication, rate limiting and audit.
- `app/worker.py`: MySQL SKIP LOCKED, expiring lease, heartbeat and fencing. No training without operator-enqueued job and configured TRAIN_COMMAND. Worker executes custom trainer subprocess, but **no real neural network training code** is supplied.
- `app/training_dataset.py`: streaming integrity-checked batches of bytes for downstream CPU trainer (not tensor packing yet).
- `app/release_builder.py`: validates TFLite header and requires explicit passed validation metadata, creates candidate release; does **not implement real TFLite conversion, inference accuracy checking or nutrition.sqlite**. nutrition.json is temporary dev format.
- `admin-web/index.html`: navigable static prototype; not a React production admin app.

## Development setup (not yet integration-tested)
`pip install -r requirements.txt` ; set DATABASE_URL, OBJECT_ROOT, ADMIN_TOKEN, ARTIFACT_ROOT; then `uvicorn app.main:app --host 127.0.0.1 --port 8080`.

## Caveats / outstanding correctness work
1. GitHub repository unavailable from current sandbox (DNS). V003 extends locally retained V002 package, **not** confirmed compatible with repository code.
2. No MySQL integration tests run. V003 snapshot built with transaction isolation, but concurrent image reviews need additional coordination/explicit isolation check. Current split permits empty validation/test for tiny classes. Make minimum per-split policy before training.
3. Cross-host file object storage is not supported (V002 flock is host-local). Crashes can leave filesystem orphans; add reconciler.
4. Snapshot rows are immutable via triggers, but referenced image_object content needs retention protections and offline backup. File replacement/deletion is out of scope.
5. `class_assignment` V001 pair-unique permits multiple classes per image. Snapshot rejects ambiguities, but DB needs stronger single-label rule if desired.
6. Worker fencing protects DB state. External side effects from stale trainer process also require fencing in trainer artifact publishing. Lease renewal starts from parent; OOM restart and packed tensor pipeline are unfinished.
7. Release candidate builder checks TFLite magic only; formal signature/inference/mobile-device validation is outstanding. Candidate must be manually approved.
8. Static admin prototype does not yet expose full image gallery, review/retry/rollback workflows; APIs for these are present in part.
9. V001 original API multipart field contract was not checked against original repository. Integrate against its actual spec before rollout.
10. File download uses local disk and SHA-256 verification per request; production should stream hash verification/cached immutable objects for large TFLite files.

## Security
Never expose admin routes without ADMIN_TOKEN and TLS. Do not commit credentials. Admin identity (`actor`) is client-supplied and not reliable auditing until SSO/RBAC integrates.
