from app.trainer.run import main
if __name__=='__main__':main()
