# Healthpiard-LFM V004 — source implementation (NOT deployment-validated)

V004 extends the existing V001–V003 source (no destructive DB changes).

## Added
- TensorFlow CPU MobileNetV3-Large trainer (`app/trainer/core.py`).
- On-demand execution only through the V003 DB-lease worker (`train_worker.py`). No trigger from ingestion or image thresholds.
- Dataset streaming from immutable snapshot; SHA-256 verification per image; no preloading decoded tensors.
- Epoch checkpoint written with atomic filesystem rename; restore with identical fencing token. On newly acquired fencing token an isolated run directory is used to prevent stale-worker overwrite. Cross-token checkpoint reuse is NOT implemented.
- OOM ResourceExhaustedError handling reduces batch size. Process-kill OOM requires external worker restart; no guarantee of seamless recovery.
- Class-ID based output-head transfer when using an approved base release with `training_model.keras`.
- Float32-input TFLite export and top-1/numerical comparison on held-out TEST images.
- Mobile nutrition SQLite file, plus JSON and per-file SHA-256 manifest.

## Limitations / important prerequisites
- Only `mobilenet_v3_large` has a real trainer. The V003 admin endpoint still advertises `efficientnet_lite0` and `mobilevit_xxs`, but V004 worker rejects them explicitly.
- The initial model defaults to **random weights**. For useful production accuracy provide compatible MobileNetV3 pretrained backbone weights using `IMAGENET_WEIGHTS_PATH`, then evaluate real-world accuracy. Architectural/shape compatibility of provided weights must be verified.
- TFLite conversion checks numerical parity, NOT ≥90% classification accuracy. A separate holdout accuracy gate is required before production approval.
- A TEST split with at least one image is mandatory for publishing.
- Worker lease-ownership checks occur between epochs, not continuously within long epochs; lease heartbeat runs in the supervisor.
- Release publishing remains an explicit separate `app.release_builder.publish` call after successful training; there is no automatic publishing/activation.
- A CPU worker will be memory intensive. TensorFlow dependencies are segregated in requirements-training.txt.
- This ZIP did not run TensorFlow/MySQL integration tests or exercise a real mobile device. It is an implementation package, not a verified production release.
- Existing Feeder schema, current GitHub repository contents, and authentication integration must be reconciled before a production merge.

## Installation outline
```
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements-training.txt
# Configure DATABASE_URL, OBJECT_ROOT, TRAIN_ROOT and ARTIFACT_ROOT first.
python -m app.worker
```
Only jobs created explicitly through the Admin API are claimed by the worker.
