"""Behavioral API checks for model selection; no running database required."""
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).parent / 'lfm-server'))
from app.main import engine  # Initialize router imports in application order.
from app import platform
from fastapi import HTTPException
from pydantic import ValidationError


class ModelSelectionTests(unittest.TestCase):
    def setUp(self):
        self.engine = MagicMock()
        self.connection = self.engine.begin.return_value.__enter__.return_value
        self.connection.execute.return_value.lastrowid = 99
        self.auth = patch.object(platform, 'authorize').start()
        patch.object(platform, 'engine', self.engine).start()
        self.lookup = patch.object(platform, 'one', return_value={'id': 1}).start()
        self.addCleanup(patch.stopall)

    def enqueue(self, **kwargs):
        return platform.enqueue(platform.JobCreate(snapshotId=2, actor='test', **kwargs))

    def test_default_is_lite0_with_224_input(self):
        self.assertEqual(self.enqueue()['jobId'], 99)
        args = self.connection.execute.call_args.args[1]
        self.assertEqual(args['m'], 'efficientnet_lite0')
        self.assertEqual(json.loads(args['cfg'])['imageSize'], 224)

    def test_legacy_model_remains_192(self):
        self.enqueue(modelFamily='mobilenet_v3_large')
        args = self.connection.execute.call_args.args[1]
        self.assertEqual(json.loads(args['cfg'])['imageSize'], 192)

    def test_different_base_architecture_cannot_be_queued(self):
        self.lookup.side_effect = [{'id': 2}, {'id': 1}, {'model_family': 'mobilenet_v3_large'}]
        with self.assertRaises(HTTPException) as error:
            self.enqueue(baseReleaseId=1)
        self.assertEqual(error.exception.status_code, 422)
        self.connection.execute.assert_not_called()

    def test_matching_base_can_be_queued(self):
        self.lookup.side_effect = [{'id': 2}, {'id': 1}, {'model_family': 'efficientnet_lite0'}]
        self.assertEqual(self.enqueue(baseReleaseId=1)['status'], 'QUEUED')

    def test_invalid_size_and_family_rejected_before_insert(self):
        for kwargs in ({'imageSize': 0}, {'imageSize': 200}, {'modelFamily': 'efficientnet_b0'}):
            with self.assertRaises(HTTPException) as error:
                self.enqueue(**kwargs)
            self.assertEqual(error.exception.status_code, 422)
        self.connection.execute.assert_not_called()

    def test_oversized_batch_rejected(self):
        with self.assertRaises(ValidationError):
            platform.JobCreate(snapshotId=2, actor='test', batchSize=129)


if __name__ == '__main__':
    unittest.main()
