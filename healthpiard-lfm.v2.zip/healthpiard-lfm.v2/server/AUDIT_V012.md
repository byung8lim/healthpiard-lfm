# Healthpiard 110-class 감리 검토 및 V012 반영표

기준: 사용자가 제공한 `Healthpiard_LFM_110클래스_파이프라인_감리_및_개선리포트.docx`와 V011 원본 소스의 대조 결과.

| 감리 항목 | 기존 확인 | V012 처리 | 남은 조건 / 주의사항 |
|---|---|---|---|
| Feeding 이미지 I/O 집중 | 업로드 시 해시·PIL·DB 수행 | 기존 멱등성/무결성 계약 유지 | 비동기 사전 썸네일은 **미구현**. 80% 감소는 미측정 가설. 별도 부하 시험 필요 |
| Feeder 응답 trainingJobId 0 | 기존 Feeder 호환성 우려 제기 | 기존 Feeder 응답 스키마 변경 안 함 | 앱 원본 계약테스트를 수행해야 함. 무조건 0 강제는 기존 서버 클라이언트 계약을 변경할 수 있음 |
| Snapshot 클래스 불균형 | 샘플 수 1~2개라도 수용 | 기본 최소 30개 클래스, VALIDATION/TEST 각각 최소 5개 보장. 미달은 HTTP 422로 차단 | 소수 클래스 자동 제외 대신 명시적으로 운영자가 데이터 보완하도록 함. 합리적인 정책 변경이며 기본값은 .env로 수정 가능 |
| Snapshot 대량 INSERT 잠금 | 대량 insert 단일 트랜잭션 | 기존 원자성 유지 | 감사서의 Next-Key-Lock 병목은 측정 자료 없음. 분할 커밋 시 불변성 위반 가능하여 미적용 |
| Tensor NPY 생성 직렬화 | Python generator 순차 | ThreadPoolExecutor 1~16, 기본 4 병렬 디코딩, bounded chunk, 단계별 로그 | CPU·디스크에 따라 실제 향상률 달라짐. multiprocessing 대신 안전한 스레드 방식 |
| CPU 4코어 제한 | core.py `min(4,cpu_count)` | `LFM_CPU_CORES` / Compose `TF_INTRAOP_THREADS` 지정, 기본 8 | 무조건 전체 코어가 최적은 아님. OOM 및 과도한 경쟁 방지를 위해 조정 가능 |
| Epoch 배치 공급 | Python generator로 이미지 단위 전달 | mmap 인덱스 배치를 `tf.numpy_function`으로 전달, `AUTOTUNE` prefetch | 메모리 매핑은 zero-copy가 아님, TensorFlow 실측 검증 필요 |
| Data augmentation / cosine decay | 미구현 | **보류** | 사전학습 가중치 유무·기존 체크포인트 호환성·학습 재현성에 영향, 별도 실험 플래그/성능 검증 후 도입 |
| TFLite dynamic range quantization | 이미 `Optimize.DEFAULT` 존재 | 기존 설정 유지; 추가 양자화 중복 적용 안 함 | INT8 모델 크기 75% 감소·4MB 미만 보장 불가; 실제 기종/변환 결과 측정 |
| 90% Top-1 배포 게이트 | `min_accuracy=0.90` | Top-3 정확도 기록, 선택적 Top-3 / Top-1 일치율 정책 env 추가; 기존 90% 정책 유지 | 감사 권고 75%/92% 임의 변경은 승인정책 완화이므로 사용자 승인 전 미적용 |
| 체크포인트 충돌 | V011 Snapshot/Job 폴더 격리 존재 | 기존 격리 유지, checkpoint 상태 classMappingHash 추가 확인 | 이전 호스트 학습폴더 자동 마이그레이션 안 함 |
| Web Admin 대량 승인 | V011 선택/클래스별 승인 | 그대로 유지 | 실 서버에서 HTTP·브라우저 e2e 미검증 |
| Feeder 개수 제한 | V011 `--count` / `all` | 그대로 유지 | 음식명 폴더당 최대 N개, 30 미만이면 보유 개수만 |

## 배포 승인 조건
1. 신규 볼륨 MySQL 초기 설치, API 로그인·업로드, 클래스별 30장 승인 및 Snapshot의 분할 규칙 확인.
2. 실제 TensorFlow 2.18 환경에서 110 클래스 메모리·처리시간·체크포인트 복구·양자화 변환·모바일 출력 검증.
3. 별도 테스트 DB/볼륨을 대상으로 CPU Job 실행 및 release quality gate 테스트.
4. 운영 DB 이전은 별도 dump/restore 및 원본 이미지 파일 검증 후 수행. `docker compose down -v`는 데이터 삭제이므로 금지.

이 ZIP은 개선 소스 및 Compose **배포 후보**이며 Rocky Docker의 전체 E2E 성공을 주장하지 않습니다.
