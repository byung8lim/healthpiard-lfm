# Healthpiard v016 — 결함 보고서 반영 및 개선 기록

기준: v015.4 전체 소스 + Gemini 결함 분석 문서.

## 확인한 결함과 조치

- DEF-01 Manifest 실제 파일 불일치: 작업 즉시 종료 대신 경고, 유효 항목 처리. 누락이 있으면 종료 코드를 2로 기록하여 완전 성공 오판 방지.
- DEF-02 하위 폴더 깊이: v015.4의 `files_by_class()`와 `file_list()`는 **둘 다 재귀 탐색**하고 있어 보고서의 깊이 불일치 주장은 현재 코드와 일치하지 않음. 재귀 동작은 유지.
- DEF-03 클래스 다중 승인: UI의 과거 `expectedCount`와 현재 PENDING 수 차이에 따른 전체 409 중단 제거. 현재 PENDING만 조건부 UPDATE하고 실수정 건수 응답. 단일 클래스 승인은 기존 동시성 보호 유지.
- DEF-04 컨테이너 권한: 쓰기 전용 마운트(objects/releases/training/cache/logs/import-state)만 재귀 소유권 복구. `/imports` 원본은 건드리지 않음. **기존 데이터가 많으면 최초 구동 시간이 길어질 수 있음.**

## 추가 수정

- API 409 `Image is already assigned to another class`는 데이터 충돌로 별도 집계하고 다음 이미지로 진행. 기존 클래스 자동 변경 금지.
- 429/5xx/네트워크 장애의 연속 발생만 전체 작업 중단 조건 적용.
- 정상 등록과 실패가 혼재한 작업은 `PARTIAL_FAILED`, 비정상 중단은 `FAILED`, 충돌만 있고 요청 범위를 끝낸 작업은 `SUCCEEDED`이며 `conflicts` 별도 표시.
- 충돌 SHA 이력도 동일 경로에서 반복 요청되지 않도록 journal에 기록. 내용이 달라지면 재수집 대상.
- `/scan`은 파일 내용의 SHA를 읽지 않음. POST 시에만 클래스별 요청 수량에 이를 때까지 후보 읽기.

## 운영 안전

기존 MySQL / PASS 승인 데이터 / 이미지 / 작업 이력은 삭제하지 않습니다.
`docker compose --env-file config.env -f compose.yml build importer admin` 와
`docker compose --env-file config.env -f compose.yml up -d --no-deps importer admin` 으로 앱만 교체할 수 있지만,
`init-permissions` 변경까지 적용하려면 해당 서비스를 별도로 실행해야 합니다.

주의: 기존 `.jsonl` 중복 판단은 성공/충돌 이력에 의존하며 다른 클래스의 동일 SHA는 LFM API가 최종 판정합니다.
실제 MySQL/Docker 운영 통합 테스트는 별도 환경에서 수행해야 합니다.
