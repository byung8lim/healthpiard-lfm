from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parent
class PackagingTests(unittest.TestCase):
 def test_worker_copies_deps(self):
  f=(ROOT/'lfm-server/Dockerfile.worker').read_text()
  self.assertIn('COPY requirements.txt requirements-training.txt ./',f)
  self.assertIn('-r requirements.txt',(ROOT/'lfm-server/requirements-training.txt').read_text())
 def test_config_included(self):
  env=(ROOT/'config.env.example').read_text()
  for k in ('MYSQL_ROOT_PASSWORD','MYSQL_USER','MYSQL_PASSWORD','HP_IMPORT_SOURCE','HP_IMPORT_STATE','WEB_ADMIN_PASSWORD'):
   self.assertIn(k+'=',env)
 def test_compose(self):
  y=(ROOT/'compose.yml').read_text()
  self.assertNotIn('MYSQL_PASSWORD_URL',y)
  self.assertIn('init-permissions:',y)
  self.assertIn('service_completed_successfully',y)
  for key in ('lfm-api:','lfm-worker:','admin:','importer:','mysql:'):
   self.assertIn(key,y)
if __name__=='__main__': unittest.main()
