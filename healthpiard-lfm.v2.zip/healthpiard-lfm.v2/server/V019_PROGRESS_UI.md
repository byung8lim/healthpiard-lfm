# v019 — 학습 진행률 자동 갱신

- CPU 학습 상세 화면에서 5초마다 학습 작업 및 진행률 API 자동 조회
- 중복 요청 방지, 컴포넌트 이탈 시 타이머 정리, 브라우저 비활성 탭 요청 생략
- 단계별 이미지 처리 진행률 막대, Epoch, 경과시간, ETA, 정확도/검증 정확도/Loss 표시
- 조회 실패 시 오류 표시 및 다음 주기에 자동 재시도
- 이미지 처리율을 전체 학습 완료율로 오인하지 않도록 명시
- 백엔드/Worker 및 데이터 저장소 변경 없음

## 배포
기존 config.env 및 데이터 볼륨 보존. frontend 변경이 포함되므로 admin 이미지를 재빌드 후 admin만 재생성하세요.
`docker compose --env-file config.env up -d --build --no-deps admin`
