# V020.1 음식 클래스 목록 사라짐 수정

## 현상
음식 클래스 메뉴 클릭 시 목록이 잠시 보였다가 사라질 수 있음.

## 확인한 코드 결함
`admin-server/frontend/src/main.jsx`의 `refresh()`가 조회할 때마다 `D({[page]:res[0],channel:res[1]})`로 전체 페이지 데이터를 덮어썼음. 페이지 전환 직전의 비동기 조회가 나중에 끝날 경우 새로운 페이지의 `classes` 데이터가 삭제될 수 있음. 클래스 화면에는 `data.classes`가 배열이 아닐 때 빈 배열로 처리되어 오류 대신 빈 목록이 표시됨.

## 수정
- 응답을 페이지별로 병합해 다른 페이지 데이터를 제거하지 않도록 변경.
- 요청 순서(sequence)와 현재 페이지를 검사해 오래된 응답 폐기.
- 클래스 목록 응답이 배열이 아니면 오류 표시.
- 학습 진행률 5초 자동 갱신은 유지.

## 적용
`docker compose --env-file config.env build admin` 다음 `docker compose --env-file config.env up -d admin` (서비스 이름이 `admin`이 아닌 경우 compose.yml의 서비스명 참조). 브라우저 강력 새로고침.

## 검증 범위
소스의 비동기 상태 갱신 구조와 수정은 확인했으나, 사용자 운영 환경에서 재현 및 브라우저 E2E 테스트는 수행하지 않았음.
