"""Regression for post-training missing-image failure. No TF/MySQL required."""
import ast
import importlib.util
from pathlib import Path
import tempfile
import json
import numpy as np
import pytest

ROOT=Path(__file__).parent

def test_test_cache_before_training():
    core=(ROOT/'lfm-server/app/trainer/core.py').read_text()
    run=(ROOT/'lfm-server/app/trainer/run.py').read_text()
    assert core.index("build_tensor(job['snapshot_id'],'TEST'") < core.index("for epoch in range(start_epoch,epochs)")
    assert 'cached_samples(cache_dir' in run
    assert 'verified_images(test' not in run
    ast.parse(core);ast.parse(run)

def test_cache_survives_deleted_source():
    path=ROOT/'lfm-server/app/trainer/tensor_cache.py'
    spec=importlib.util.spec_from_file_location('tested_tensor_cache',path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)
        np.save(p/'images.npy',np.ones((2,4,4,3),np.float32))
        np.save(p/'labels.npy',np.array([1,0],np.int32))
        (p/'ready.json').write_text(json.dumps({'count':2,'key':'sample'}))
        src=p/'original.jpg';src.write_bytes(b'fake');src.unlink()
        data=list(mod.cached_samples(p,expected_count=2))
        assert len(data)==2 and [x[1] for x in data]==[1,0]
        with pytest.raises(RuntimeError,match='count/manifest'):
            list(mod.cached_samples(p,expected_count=3))
