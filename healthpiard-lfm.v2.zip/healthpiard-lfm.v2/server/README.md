# Healthpiard Compose V023

**Read V023_RELEASE_NOTES.md first.**

# Healthpiard v017

Read V017_RELEASE_NOTES.md for patch scope and deployment.

# Healthpiard Docker Compose V013 — 운영자 관제 개선 통합본

MySQL 8, LFM API(8080), CPU Worker, Spring Boot + React Admin(8081), 관리자 내부 이미지 로딩 서비스(importer)로 구성됩니다. **독립 Feeder CLI는 Compose에 포함하지 않으며 별도 ZIP입니다.**

## 최초 설치

```bash
cp .env.example .env
chmod 600 .env
# .env의 비밀번호/토큰과 HP_* 호스트 절대경로 수정
sudo ./prepare-rocky-dirs.sh
./verify-source.sh
docker compose -f compose.yml build
docker compose -f compose.yml up -d
docker compose -f compose.yml ps
```

관리자 웹은 `http://Rocky_IP:8081/` 입니다. 원본 이미지 경로 `${HP_IMPORT_SOURCE}`는 `/imports:ro`로 읽기 전용, 내부 importer의 작업기록은 `${HP_IMPORT_STATE}`에 보존됩니다. 메뉴에서 음식 폴더별 N장 또는 all을 지정할 수 있습니다. 학습 화면에서는 캐시 단계·Epoch 완료수·경과시간·실측 Epoch 기반 ETA·오류 로그를 확인합니다. 일괄 승인은 선택/페이지/클래스 단위로 지원합니다.

## Rocky 호스트 영구저장 경로

`.env.example`의 `HP_MYSQL_DATA`, `HP_IMAGE_DATA`, `HP_TRAIN_DATA`, `HP_CACHE_DATA`, `HP_RELEASE_DATA`, `HP_LOG_DATA`, `HP_IMPORT_SOURCE`, `HP_IMPORT_STATE`를 사용합니다. MySQL 스키마는 빈 data dir의 **최초 부팅에만** `mysql-init/01-schema.sql`이 실행됩니다. 기존 운영 DB와 이미지·모델을 자동 마이그레이션하지 않습니다. 기존 경로를 삭제하거나 `docker compose down -v`를 실행하지 마세요.

## 주의 및 검증 범위

학습 체크포인트 경로는 Snapshot/Job 단위로 분리합니다. 컨테이너 재시작은 호스트에서만 수행하며 관리자 웹에는 Docker Socket 권한을 제공하지 않습니다. `./verify-source.sh`는 정적 검사입니다. **실제 Docker 빌드, 전체 E2E 및 110클래스 학습은 아직 검증되지 않았습니다.** 기존 시스템과 8080/8081 포트 중복에 주의하세요.

## V014 (2026-10-20) – replacement for v013

See `V014_DEFECTS_AND_ACCEPTANCE.md` before deployment. `v013` must not be used as a deployment baseline.
For existing servers: preserve `config.env` and all `HP_*` data directories; do **not** run `down -v` or delete MySQL/image data. Set `MYSQL_PASSWORD_URL` (percent-encoded database password) and `HP_UID`/`HP_GID` to the host data owner (normally 1000:1000). Run `./healthpiard.sh prepare` with suitable directory ownership privileges, `./healthpiard.sh check`, then `./healthpiard.sh up`. Import progress is per-food-class **new successful images**, not first N files on every invocation. Imported successes are tracked in persisted JSONL journals under `HP_IMPORT_STATE`; back up that directory along with MySQL for resumable selection.
