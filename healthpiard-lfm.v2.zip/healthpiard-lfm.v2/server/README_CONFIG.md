# Healthpiard V013 – single configuration file

Configure **only `config.env`**. `compose.yml` references it via `docker compose --env-file config.env`, called by `healthpiard.sh`.

```bash
cp config.env.example config.env
chmod 600 config.env
# Edit passwords, tokens, absolute Rocky paths in config.env
./healthpiard.sh prepare  # May require sudo for /srv directories
./healthpiard.sh check
./healthpiard.sh up       # Build + start all services
./healthpiard.sh ps
./healthpiard.sh logs lfm-worker
```

- API: `http://server:8080`
- Admin: `http://server:8081`
- MySQL: 127.0.0.1:3307
- Internal importer is for Admin-controlled folder import. Separate Feeder ZIP is not bundled.
- `LFM_ADMIN_TOKEN` authorizes LFM administrative APIs; `IMPORTER_TOKEN` authorizes the importer API. They must differ.
- `config.env` is **host-only**, not copied into images; protect it with mode 600, never commit it.
- Use URL-safe alphanumeric characters for `MYSQL_PASSWORD`: the app uses it in a MySQL connection URI. Password changes are not automatically applied to an existing MySQL data directory.
- MySQL schema initialization only runs against a **new, empty** host data directory. `down` does not erase any host data.
- No fresh full E2E verification has been executed on Rocky Linux; this package change only centralizes configuration.
