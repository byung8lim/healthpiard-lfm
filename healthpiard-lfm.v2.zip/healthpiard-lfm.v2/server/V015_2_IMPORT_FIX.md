# Healthpiard v015.2 - ZIP 교체 후 이미지 재로딩 개선

## 병합 소스
- 사용자 제공 `healthpiard-compose-v015(1).zip` 전체 소스
- 사용자 제공 `healthpiard-v015-admin-bulk-ui-patch(1).zip`의 Admin React 및 Spring Boot 파일 3종

## 변경
- `importer/importer_service.py`: 기존 성공 이력을 `상대경로 -> 마지막 SHA`에서 `상대경로 -> 성공 SHA 집합`으로 변경. 같은 파일명이지만 내용이 바뀌면 새 이미지로 인식. 이전 성공 이미지가 다시 나타나도 중복 제외.
- GET `/scan`: `diagnostics.total`, `eligibleTotal`, `alreadyUploaded`, `unreadable`, `selected`, `duplicateInSource`, `deferredByLimit` 및 예시 경로 반환.
- POST `/jobs` 신규 대상 0건: `NO_NEW_IMAGES` 응답에 검사 통계 포함.
- `admin-server/frontend/src/main.jsx`: 원본/신규/기처리/읽기 실패 표시 및 신규 대상 0건 안내 개선.

## 운영 확인
1. `config.env`의 `HP_IMPORT_SOURCE` 호스트 경로가 실제 압축 해제 위치인지 확인하십시오. 컨테이너 내부 `/imports`에 마운트된 폴더만 스캔합니다.
2. 한 묶음의 이미지 등록 완료 및 승인 후, **호스트 원본 폴더만** 교체하고 다음 ZIP을 풀어 주세요. `/data/objects`, MySQL DB, `/state`는 삭제하지 마세요.
3. Admin > 이미지 로딩 > 새로고침에서 `신규 후보` 수를 먼저 확인하십시오. 0인 경우 `이미 처리`가 전부인지 또는 현재 마운트에 원본이 없거나 다른 ZIP인지 확인하십시오.
4. 현재 구현은 클래스마다 `--count` 개씩 신규 이미지를 업로드합니다. 파일명과 내용이 동일하면 기처리로 제외되며, 실제 DB의 SHA-256 고유 제약이 최종 중복 방지 기준입니다.

## 검증 한계
- Python py_compile 통과.
- 임시 폴더에서 첫 수집 -> 동일 바이트 제외 -> 동일 경로 새 바이트 선택 -> 기존 바이트 재등장 시 제외 테스트 통과.
- 실제 Rocky 서버 Docker Compose 빌드, Spring Boot 컴파일, MySQL 연결, ZIP 원본 데이터는 이 환경에서 재현하지 못했습니다.
- 중요: 이전에 `NO_NEW_IMAGES`가 발생한 실제 원인은 서버 마운트 경로 또는 원본 파일의 SHA를 확인하지 않아 미확정입니다. 이 변경은 그 상태를 확인 가능하게 합니다.
