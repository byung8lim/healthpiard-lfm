# Healthpiard v018 — source audit and reliability patch

## Observed by operator
- v017 imported images with approximately 100 failures; image approval, snapshot creation and training initiation succeeded.
- Docker Compose was stopped **after** training was started. No evidence that shutdown caused the earlier image failures.
- Exact failed HTTP codes and per-image error reasons were not supplied; their root cause is **not established**.

## Confirmed code defects fixed
1. **409 class conflicts permanently skipped:** `completed_images()` previously treated a conflict as successful upload and excluded that image from future scans. v018 only marks `ok=true` uploads as complete.
2. **Conflict-only import marked successful:** feeder returned exit code 0 for class conflicts. v018 returns partial-failure code 1, preserving conflict counts and journal.
3. **Unbounded preview hashing memory:** eligibility scan read every candidate entirely into RAM; v018 hashes in 1 MiB chunks.
4. **Worker shutdown:** SIGTERM now requests graceful trainer termination and prevents claiming another job. The DB lease/fencing token remains authoritative for retry.
5. **Missing manifest paths:** feeder now prints every missing source path rather than just aggregate count.
6. **Stale nested v013 deployment:** removed nested duplicate source tree to avoid installing the wrong compose stack.

## Intentionally not changed
- No existing MySQL schema or persistent data, image approvals, snapshots, or model releases are changed.
- A SHA-256 image already assigned to another food class is **not silently relabeled or duplicated**. Conflict is surfaced for operator review.
- Training started before `docker compose down` may have been interrupted. Inspect job status and lease before retry; do not enqueue duplicates blindly.

## Acceptance/limitations
- Local syntax and regression tests can be run without server access.
- Docker build, real DB integration, 14,435 image integrity and end-to-end training/export have not been verified in this environment.
- The ~100 import failures require journal analysis for actual reasons.

## Safe deployment
Keep existing `config.env` and all `HP_*` storage paths unchanged. Run `docker compose --env-file config.env -f compose.yml config --quiet`, then rebuild services only after reviewing active training jobs. Never run `down -v`.

## Diagnose import failures (read only)
Find journal paths from `/state` mapped by `HP_IMPORT_STATE`; examine records with `ok:false`, `httpStatus`, `error`, and `response.detail`. A conflict may represent identical image content under different food names, not corrupt bytes.
