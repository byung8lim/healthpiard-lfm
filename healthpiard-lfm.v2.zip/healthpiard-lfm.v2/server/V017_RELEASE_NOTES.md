# Healthpiard v017 — audit-driven patch

## Confirmed source defects and corrections
- Snapshot reused global 30 PASS/class readiness as a hard rejection gate, blocking datasets with 3..29 images per class. V017 requires 3 per represented class, permitting independent TRAIN/VALIDATION/TEST samples; the former training readiness policy is unchanged.
- Snapshot silently omitted approved images lacking class assignment. V017 rejects before mutation with structured `SNAPSHOT_UNASSIGNED_IMAGES` and count.
- LFM 422 response body was lost by Spring Boot default error handling. V017 passes through the original JSON and HTTP status; transport failures return 503.
- LFM host port 8080 was unnecessarily published for internal Admin calls and caused deployment port collisions. V017 exposes 8080 internally. Optional override provided for external feeders.
- Admin UI shows structured `detail` from upstream errors.

## Gemini report assessment
- 30-image hard gate: confirmed; replaced by a 3-image minimum for disjoint splits.
- TRAIN exhaustion: guarded, with adaptive minimum 1 validation and 1 test image.
- No approved images: preflight retained, now structured error.
- UI detail hidden: confirmed and patched.
- Suggested disabling classes or lowering environment thresholds: NOT applied; these can silently alter the dataset and do not repair the design.

## Limitations and operational acceptance
- No production MySQL data was available here; 298-class/14,435-image distribution cannot be asserted.
- Snapshot still returns a detailed 422 if a class has fewer than 3 approved images or PASS images have no class assignment. This is deliberate: no class is silently dropped.
- Duplicate snapshot manifest remains HTTP 409 by design.
- Validate in a staging clone before deployment. Do not use `down -v` or replace DB volumes.
- After deployment check: Docker DNS `getent hosts lfm-api`, image list, snapshot preflight, 201 success, immutable manifest and idempotent duplicate 409.

## Deployment commands
```bash
# Keep your existing server-side config.env; this ZIP intentionally excludes secrets.
# On the server, back up the existing config.env and compose.yml before replacing files.
docker compose --env-file config.env -f compose.yml config --quiet
docker compose --env-file config.env -f compose.yml up -d --build --no-deps lfm-api admin
# If an external feeder uses :8080, add -f compose.lfm-public.example.yml
```

**Important:** Do not replace the server's existing `config.env` or DB/image volumes. The source archive excludes `config.env` because it may contain credentials. Existing `config.env.example` is a template only.
