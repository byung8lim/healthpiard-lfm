"""V022 source regression tests without GPU/database/TensorFlow imports."""
from pathlib import Path
R=Path(__file__).resolve().parent

def test_accuracy_first_defaults():
    trainer=(R/'lfm-server/app/trainer/core.py').read_text()
    assert "config.get('epochs',10)" in trainer
    assert "config.get('imageSize',224 if family=='efficientnet_lite0' else 192)" in trainer
    assert "best_validation.keras" in trainer
    assert "Classes absent from TRAIN or VALIDATION" in trainer
    assert "RandomRotation" in trainer
    assert "weights='imagenet' if pretrained else None" in trainer

def test_float_export_diagnostics_and_policy():
    export=(R/'lfm-server/app/trainer/export.py').read_text()
    assert 'converter.optimizations=[tf.lite.Optimize.DEFAULT]' not in export
    assert 'converter.target_spec.supported_types=[tf.float32]' in export
    assert "export_diagnostics.json" in export
    assert "'kerasHoldoutAccuracy'" in export
    assert 'max_error<=tolerance' in export
    assert "'accuracyGateEnabled':False" in export

def test_release_policy_and_admin():
    platform=(R/'lfm-server/app/platform.py').read_text()
    assert 'TFLITE_NUMERIC_DIVERGENCE' in platform
    assert 'Field(default=30' in platform
    assert 'defaultValue="30"' in (R/'admin-server/frontend/src/main.jsx').read_text()
