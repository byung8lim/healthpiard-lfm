# Healthpiard LFM V015 — two-command deployment

Run from the extracted `healthpiard-compose-v015` directory:

```bash
docker compose --env-file config.env -f compose.yml build
docker compose --env-file config.env -f compose.yml up -d
```

`config.env` **is included** with fresh random alphanumeric credentials. Protect it (`chmod 600 config.env`). For a **fresh** installation, these work with a new empty `./data/mysql` directory. The directory is initialized on first MySQL startup using `mysql-init/01-schema.sql`. Do not overwrite an existing DB's credentials/storage paths with this new configuration: MySQL initialization variables apply only to a fresh data directory.

The optional `init-permissions` one-shot service prepares the writable bind mount directory *roots* for UID/GID 1000 before LFM API and Importer start. It does not delete data or recursively chown existing image files. MySQL continues as its image's native mysql account. The Admin image continues with its dedicated JVM service account. LFM API, Worker and Importer run with `user: 1000:1000`.

Add the food-name directories (e.g. `imports/가리비/*.jpg`) **before using image import**. Without them the services start, but no images are available. For existing external image trees, set `HP_IMPORT_SOURCE` to the correct absolute host path in `config.env` before running the two commands.

Each `count=30` import requests **up to 30 new images per food class**, iterating over all food-name folders. Successful SHA/path pairs are tracked via the importer state journals; later jobs skip those same successful images, and failed ones remain eligible to retry. Never run a new import while a previous job is active.

The Worker Dockerfile now copies both `requirements.txt` and `requirements-training.txt` before pip install, resolving the v014 build error.

**Validation scope:** static checks and importer selection tests were executed in this artifact environment. Docker is not installed in this environment; a real `docker compose build` / `up -d` run was **not possible**, so production success must be checked on the target Rocky server.
