"""Run inside the worker: python /tmp/verify_efficientnet_lite0.py.

Checks the real pretrained model, head training, Keras reload, TFLite conversion,
and optional numerical parity with the upstream ImageNet TFLite artifact.
Uses a temporary directory; does not enqueue jobs or modify existing releases.
"""
import json
import os
import tempfile
from pathlib import Path

os.environ.setdefault('TF_NUM_INTEROP_THREADS', '1')
os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '1')
import numpy as np
import tensorflow as tf
from app.trainer.core import build_model, configure_phase
from app.trainer.efficientnet_lite import build_backbone, checkpoint_path
from app.trainer.export import export_and_compare


def main():
    rng = np.random.default_rng(42)
    pixels = rng.uniform(0, 255, (2, 224, 224, 3)).astype('float32')
    x = pixels / 127.5 - 1
    official = os.getenv('LITE0_OFFICIAL_TFLITE')
    if official:
        backbone = build_backbone(tf)
        head = tf.keras.layers.Dense(1000, activation='softmax')
        model = tf.keras.Model(backbone.input, head(backbone.output))
        reader = tf.train.load_checkpoint(checkpoint_path(tf))
        head.set_weights([reader.get_tensor('efficientnet-lite0/head/dense/' + v +
                         '/ExponentialMovingAverage') for v in ('kernel', 'bias')])
        interpreter = tf.lite.Interpreter(model_path=official, num_threads=1)
        interpreter.allocate_tensors()
        for ordinal in range(2):
            interpreter.set_tensor(interpreter.get_input_details()[0]['index'],
                                   (pixels[ordinal:ordinal + 1] - 127) / 128)
            interpreter.invoke()
            expected = interpreter.get_tensor(interpreter.get_output_details()[0]['index'])
            actual = np.asarray(model(x[ordinal:ordinal + 1], training=False))
            np.testing.assert_allclose(actual, expected, atol=1e-5, rtol=1e-4)
        print('Official pretrained TFLite parity: PASS', flush=True)
        del model, backbone, interpreter
        tf.keras.backend.clear_session()
    model = build_model(tf, 4, 224, pretrained=True, model_family='efficientnet_lite0')
    assert model.input_shape == (None, 224, 224, 3)
    assert model.output_shape == (None, 4)
    assert not any('_se_' in layer.name for layer in model.layers)
    configure_phase(tf, model, 'warmup')
    before = model.get_layer('food_logits').get_weights()[0].copy()
    backbone_before = model.get_layer('lite0_stem_conv').get_weights()[0].copy()
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss='sparse_categorical_crossentropy')
    model.train_on_batch(x, np.array([0, 1]))
    assert not np.array_equal(before, model.get_layer('food_logits').get_weights()[0])
    np.testing.assert_array_equal(backbone_before, model.get_layer('lite0_stem_conv').get_weights()[0])
    configure_phase(tf, model, 'finetune')
    assert any(layer.trainable and layer.weights and layer.name != 'food_logits' for layer in model.layers)
    assert all(not layer.trainable for layer in model.layers if isinstance(layer, tf.keras.layers.BatchNormalization))
    with tempfile.TemporaryDirectory(prefix='verify-lite0-') as directory:
        path = Path(directory) / 'checkpoint.keras'
        model.save(path)
        reloaded = tf.keras.models.load_model(path, compile=False)
        np.testing.assert_allclose(model(x, training=False), reloaded(x, training=False), atol=1e-6)
        samples = [(arr, 0) for arr in x]
        result = export_and_compare(path, Path(directory) / 'model.tflite', image_size=224, samples=samples)
        assert result['passed'], result
        print('Train/save/reload/export: PASS ' + json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
