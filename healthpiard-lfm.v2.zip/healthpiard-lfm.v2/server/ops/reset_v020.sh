#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
MODE="${1:-}"
if [[ "$MODE" != "--dry-run" && "$MODE" != "--execute" ]]; then echo 'Usage: bash ops/reset_v020.sh --dry-run|--execute'; exit 2; fi
[[ -f config.env ]] || { echo 'config.env missing'; exit 2; }
set -a; source ./config.env; set +a
keys=(HP_MYSQL_DATA HP_IMAGE_DATA HP_TRAIN_DATA HP_CACHE_DATA HP_RELEASE_DATA HP_LOG_DATA HP_IMPORT_STATE)
for key in "${keys[@]}"; do
  path="${!key:-}"
  [[ -n "$path" && "$path" = /* && "$path" != / && "$path" != /srv && "$path" != /home && "$path" != /mnt && "$path" != /var && "$path" != /tmp ]] || { echo "Unsafe path: $key=$path"; exit 3; }
  [[ ! -L "$path" ]] || { echo "Symlink rejected: $path"; exit 3; }
  printf '%s = %s\n' "$key" "$path"
done
if [[ "$MODE" == "--dry-run" ]]; then echo 'DRY RUN: no data removed. Source imports remain untouched.'; exit 0; fi
[[ "${V020_CONFIRM_RESET:-}" == 'DELETE_ALL_HEALTHPIARD_DATA' ]] || { echo 'Set V020_CONFIRM_RESET=DELETE_ALL_HEALTHPIARD_DATA'; exit 4; }
read -r -p 'Type RESET-V020 to erase ALL database, images, jobs, models and import state: ' confirm
[[ "$confirm" == 'RESET-V020' ]] || exit 5
docker compose --env-file config.env -f compose.yml down
for key in "${keys[@]}"; do path="${!key}"; if [[ -d "$path" ]]; then find "$path" -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +; fi; done
echo 'Reset completed. Original HP_IMPORT_SOURCE is preserved. Run docker compose up -d.'
