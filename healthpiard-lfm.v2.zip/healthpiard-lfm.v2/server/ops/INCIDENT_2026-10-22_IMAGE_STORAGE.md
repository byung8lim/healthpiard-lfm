# 2026-10-22: missing images during additional training

## Confirmed on the server

- Job 2 / snapshot 2 failed with `RuntimeError: Missing/unsafe image 12`.
- All 22,062 database image objects were absent from their recorded `sha256/...` paths.
- `HP_IMAGE_DATA` and `HP_IMPORT_SOURCE` both pointed to `/home/wbl/learning/images`.
- Source folders were being replaced during inspection. The user paused that work.
- Existing source files and retained ZIP archives contained all 22,062 original byte sequences.

## Repair

Recovered images by matching their SHA-256 against `image_object`, preserving the
recorded storage keys, into `/home/wbl/learning/objects`. No snapshot rows or labels
were changed. Recovery reported 22,062 recovered and zero missing.

Changed only `HP_IMAGE_DATA` in the server's `config.env`:

```dotenv
HP_IMAGE_DATA=/home/wbl/learning/objects
HP_IMPORT_SOURCE=/home/wbl/learning/images
```

The previous configuration was backed up beside `config.env`. Recreated API,
worker and admin containers to apply their new image mount. Import source folders
can be managed separately; retain the entire `objects` directory across imports.

Server recovery evidence is in `/home/wbl/learning/logs/`:

- `object-recovery-db.json`
- `recover_objects_20261022.py`
- `object-recovery-progress.log`
- `object-recovery-result.json`

Post-restart verification read all 22,062 mounted files again and compared their
SHA-256 values: zero missing or mismatched files. Retried job 2 using the existing
admin retry endpoint; it entered `RUNNING`, attempt 3, with no error. TEST preflight
completed and TRAIN tensor packing began. This is evidence of recovery past the
original failure, not confirmation that the full 30-epoch training has finished.

## Accuracy evidence and limits

Job 1 trained on 34 classes. Final training accuracy was 99.01%, final validation
accuracy 70.31%, and the selected model's TEST top-1 accuracy was 69.38%
(1,300 images). TEST top-3 accuracy was 89.85%. Keras/TFLite top-1 agreement was
100%, with maximum absolute output difference about 0.0000135. Conversion checks
passed; the configured accuracy gate was disabled. A successful release therefore
did not certify high recognition accuracy.

The app source is not present in this workspace, so app preprocessing and class
mapping have not been verified. Training uses EXIF orientation, RGB, proportional
resize without upscaling, centered black padding to 192 x 192, and float32
`pixel / 127.5 - 1`. Map the output index through the release's `class_index.json`.
Only the 34 classes in release 1 can be recognized by that release. These are
checks to perform on the app, not confirmed explanations for its lower accuracy.
