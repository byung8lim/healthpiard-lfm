import os,sys,tempfile,json,hashlib,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).parent/'importer'))
os.environ.setdefault('IMPORTER_TOKEN','test-token')
import importer_service as imp
class V014(unittest.TestCase):
 def test_next_batch_per_food(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d)/'images'; root.mkdir(); state=Path(d)/'state';state.mkdir()
   for food in ('가리비','김치'):
    (root/food).mkdir()
    for i in range(5): (root/food/f'{i}.jpg').write_bytes(f'{food}-{i}'.encode())
   with patch.object(imp,'ROOT',root), patch.object(imp,'STATE',state):
    a,c=imp.eligible_files(2)
    self.assertEqual(len(a),4)
    for rel in a:
     p=root/rel
     with (state/'previous.jsonl').open('a') as f:f.write(json.dumps({'path':rel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'ok':True})+'\n')
    b,_=imp.eligible_files(2)
    self.assertEqual(len(b),4)
    self.assertFalse(set(a)&set(b))
    x,_=imp.eligible_files('all')
    self.assertEqual(len(x),6)
    self.assertEqual(len(imp.completed_images()),4)
    (root/a[0]).write_bytes(b'changed')
    c,_=imp.eligible_files('all')
    self.assertIn(a[0],c)
 def test_failed_not_skipped(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d)/'images';root.mkdir();(root/'A').mkdir();(root/'A'/'a.jpg').write_bytes(b'1')
   state=Path(d)/'state';state.mkdir()
   (state/'fail.jsonl').write_text(json.dumps({'path':'A/a.jpg','ok':False,'sha256':hashlib.sha256(b'1').hexdigest()})+'\n')
   with patch.object(imp,'ROOT',root), patch.object(imp,'STATE',state):
    chosen,_=imp.eligible_files(1)
    self.assertEqual(chosen,['A/a.jpg'])
if __name__=='__main__': unittest.main()
