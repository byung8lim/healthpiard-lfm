#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
python3 -m compileall -q lfm-server/app importer
python3 -c "import ast,pathlib,yaml; [ast.parse(p.read_text()) for d in ('lfm-server/app','importer') for p in pathlib.Path(d).rglob('*.py')]; s=yaml.safe_load(pathlib.Path('compose.yml').read_text())['services']; assert_test = {'mysql','lfm-api','lfm-worker','admin','importer'} <= set(s) and 'feeder' not in s; assert assert_test; print('Python+Compose PASS')"
echo 'STATIC PASS (runtime and full E2E not verified)'
