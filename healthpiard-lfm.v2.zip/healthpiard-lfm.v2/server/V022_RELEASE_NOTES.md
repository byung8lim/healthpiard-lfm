# V022 — Accuracy-first CPU trainer + safe float32 export

## Root cause (confirmed by source)

- V021 defaults to **10 epochs**, which is often insufficient for a 2-phase transfer-learning run.
- V021 optimizes the TFLite converter by default and requires **100% top-1 agreement**, while its own result shows 330/386 agreement and maximum discrepancy 0.19761. This exception marks the whole training job failed and prevents diagnostics/publishing.
- The audited report's 91–94% prediction is **not measured or guaranteed**. V021 already has pretrained weights, 2-phase training and train-only augmentation, contradicting claims those features are wholly absent. V021 explicitly normalizes [-1,1] and disables MobileNetV3 internal preprocessing, so the report's claimed [0,1] normalization defect does not apply to this source.

## Changes

- CPU trainer default 30 epochs, 5-epoch warmup (for 30), image size 192, stage-specific cosine AdamW with safer fine-tune LR, train-only augmentation as already present.
- Abort snapshots missing per-class TRAIN/VALIDATION data; output dataset diagnostics and preserve best validation checkpoint for export.
- Float32 TFLite without default post-training quantization; independently record accuracy, model agreement and absolute differences, including per-image disagreement metadata. Conversion quality failure does not erase converted file or crash the job; release gating blocks unsuitable models.
- Release target now 90% holdout Top1 and conversion thresholds: 98% Top1 agreement and max abs difference 0.02. **These values are targets, not claimed performance.**
- Admin defaults to 30 epochs; API defaults to 30. Existing DB/snapshots/volumes are preserved.

## Re-run

1. Backup `config.env`, and keep every persistent data directory as-is. Extract V022 to a NEW deployment directory.
2. Ensure ImageNet pretrained weights exist in persisted `KERAS_HOME` or network access is available for the initial download.
3. `docker compose --env-file config.env -f compose.yml build lfm-worker lfm-api admin`
4. `docker compose --env-file config.env -f compose.yml up -d lfm-worker lfm-api admin`
5. Submit a **NEW training job** for the existing snapshot. Retrying V021's failed job may resume old checkpoint weights and old optimizer state and will not use new defaults.
6. Review `/data/training/snapshot-*/job-*/dataset_diagnostics.json`, `progress.json`, `export_diagnostics.json` and returned `validation`.
7. Keep 90% release gate intact; if holdout Top1 remains lower, curate mislabeled/ambiguous images, add diverse per-class samples and retrain.

## Verification limit

Static syntax/source tests only in this environment. No user's MySQL, image dataset, Docker runtime or real TensorFlow training available here; **90% accuracy is not verified**.
