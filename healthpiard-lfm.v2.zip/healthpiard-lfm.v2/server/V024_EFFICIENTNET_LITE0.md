# EfficientNet-Lite0 training

New training requests default to `efficientnet_lite0`, 224 x 224 RGB float32 input,
30 epochs and batch size 16. The admin training form offers this model and the
previous `mobilenet_v3_large` model. Existing jobs retain their recorded family;
change architecture by creating a new job, never by editing an old job row.

EfficientNet-Lite0 uses 16 MBConv blocks, ReLU6 and no squeeze/excitation. Its
ImageNet initialization restores every backbone variable, including batch norm,
from the official TensorFlow checkpoint's exponential moving averages. Missing
weights or incompatible shapes stop training. It does not silently fall back to
random weights or substitute EfficientNet-B0.

References:

- https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet/lite
- https://github.com/tensorflow/tpu/blob/master/models/official/efficientnet/lite/efficientnet_lite_builder.py

The official archive is pinned by SHA-256 in `app/trainer/efficientnet_lite.py`.
It is downloaded using Keras' persistent cache under `KERAS_HOME`. For offline
operation, prepopulate `models/efficientnet-lite0-official.tar.gz` with that exact
archive, or set `EFFICIENTNET_LITE0_CHECKPOINT` to a complete official checkpoint
prefix in the worker environment. No additional Python dependencies are required.

The public input stays `pixel / 127.5 - 1`; a serialized Rescaling layer inside
the model converts to the pretrained backbone's `(pixel - 127) / 128` convention.
Preprocessing still uses EXIF orientation, RGB, proportional resize without
upscaling and centered black padding. Read the actual TFLite input dimensions;
old MobileNet releases default to 192 x 192, new Lite0 jobs to 224 x 224.
New release manifests include the model family and full input contract.

Cross-family base releases are rejected both at enqueue and by the worker. Start
Lite0 from ImageNet rather than trying to transfer a MobileNet checkpoint. Resume
also checks the saved architecture and input dimensions. Checkpoints, class-index
ordering, validation model selection and numerical TFLite verification remain in
the existing training/export pipeline.

Verification inside the worker:

```sh
python /checks/verify_efficientnet_lite0.py
```

`ops/verify_efficientnet_lite0.py` checks real pretrained initialization, classifier
training with a frozen backbone, fine-tuning flags, Keras serialization and actual
float32 TFLite export/inference. If `LITE0_OFFICIAL_TFLITE` points to the official
FP32 ImageNet artifact from the archive, it also checks numerical parity with the
upstream model. Synthetic tests verify implementation, not food recognition
accuracy; evaluate the new trained model on TEST and app images before release.

Deployment uses the existing Compose configuration and retains all data:

```sh
docker compose --env-file config.env build lfm-api lfm-worker admin
docker compose --env-file config.env up -d
```

The Compose API, worker and admin services use explicit `:efficientnet-lite0`
image tags and `pull_policy: build`, so `up -d` builds current source using the
Docker layer cache even when an older image already exists. Compose explicitly
sets `DEFAULT_MODEL_FAMILY=efficientnet_lite0` for the API and worker.

On the deployment server, `.env` links to `config.env`, so the following also
loads the same persistent configuration without specifying `--env-file`:

```sh
cd /home/wbl/healthpiard-compose-v023
docker compose up -d
```

For an existing database, application requests always specify the model family.
The new-install schema default is updated; no existing job rows are rewritten.

## Verification on 2026-10-22

- Official ImageNet FP32 TFLite comparison passed; measured maximum absolute
  difference in the initial parity check was approximately `5.07e-7`.
- Classifier training, frozen-backbone behavior, fine-tuning flags, Keras
  save/reload and float32 TFLite conversion/inference passed. Conversion test
  top-1 agreement was 100%, maximum absolute difference approximately `4.77e-7`.
- Six API behavior tests passed. V022 source regression checks and Python syntax
  checks passed. Admin frontend and all three production images built successfully.
- Official pretrained weights loaded successfully with network disabled and
  worker UID 1000 using the default persistent Keras cache.

The server was configured for a fresh start under
`/home/wbl/learning/efficientnet-lite0/`, with separate `dbdata`, `training`,
`cache`, `releases`, `logs` and `import-jobs` directories. Import source remains
`/home/wbl/learning/images`; persistent image objects remain
`/home/wbl/learning/objects`. Earlier state directories were retained, and source
plus configuration backups were saved in `ops/before-efficientnet-lite0-*`.
