#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$(realpath "$0")")"
CONF="${HP_CONFIG_FILE:-config.env}"
if [[ ! -f "$CONF" ]]; then
  echo "Missing $CONF. Create it: cp config.env.example config.env; chmod 600 config.env" >&2
  exit 2
fi
if ! command -v docker >/dev/null; then echo 'Docker required' >&2; exit 2; fi
compose=(docker compose --env-file "$CONF" -f compose.yml)
case "${1:-}" in
  up)
    "${compose[@]}" config --quiet
    "${compose[@]}" up -d --build
    "${compose[@]}" ps
    ;;
  build) "${compose[@]}" build ;;
  down) "${compose[@]}" down ;; # NEVER delete host data
  ps|status) "${compose[@]}" ps ;;
  logs) shift; "${compose[@]}" logs --tail 100 -f "$@" ;;
  check|config) "${compose[@]}" config --quiet && echo 'CONFIG PASS' ;;
  prepare)
    HP_CONFIG_FILE="$CONF" ./prepare-rocky-dirs.sh
    ;;
  *)
    echo 'Usage: ./healthpiard.sh {prepare|check|build|up|ps|logs [service]|down}' >&2
    exit 2
    ;;
esac
